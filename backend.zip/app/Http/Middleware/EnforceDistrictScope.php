<?php
namespace App\Http\Middleware;
use Closure;
use Illuminate\Http\Request;
class EnforceDistrictScope {
    public function handle(Request $request, Closure $next) {
        $user = $request->user();
        if ($user && !$user->isStateLevel()) {
            $request->merge(['district_id' => $user->district_id]);
        }
        return $next($request);
    }
}
