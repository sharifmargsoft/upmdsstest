<?php
namespace App\Http\Middleware;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
class LogApiRequest {
    private array $skip = ['api.v1.dashboard.kpi','api.v1.master.districts','api.v1.master.checkgates'];
    public function handle(Request $request, Closure $next) {
        $response = $next($request);
        if (!in_array($request->route()?->getName(),$this->skip)) {
            $user = $request->user();
            Log::channel('daily')->info('API',[
                'user'     => $user?->username,
                'method'   => $request->method(),
                'path'     => $request->path(),
                'status'   => $response->status(),
                'ip'       => $request->ip(),
                'ms'       => round((microtime(true)-LARAVEL_START)*1000),
            ]);
        }
        return $response;
    }
}
