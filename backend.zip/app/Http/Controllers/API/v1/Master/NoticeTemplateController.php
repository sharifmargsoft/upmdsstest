<?php
namespace App\Http\Controllers\API\v1\Master;
use App\Http\Controllers\Controller;
use App\Models\NoticeTemplate;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
class NoticeTemplateController extends Controller {
    public function index(): JsonResponse { return response()->json(['data'=>NoticeTemplate::active()->orderBy('name')->get()]); }
    public function store(Request $request): JsonResponse {
        $request->validate(['name'=>'required|string|max:150|unique:notice_templates,name','template_type'=>'required|in:general,weighment,overload,mcheck','subject'=>'nullable|string|max:300','body_html'=>'required|string']);
        $t = NoticeTemplate::create([...$request->only(['name','template_type','subject','body_html']),'created_by'=>$request->user()->id]);
        return response()->json(['data'=>$t,'message'=>'Template created.'],201);
    }
    public function update(Request $request, int $id): JsonResponse {
        $t = NoticeTemplate::findOrFail($id);
        $request->validate(['name'=>"sometimes|string|max:150|unique:notice_templates,name,{$id}",'subject'=>'nullable|string|max:300','body_html'=>'sometimes|string','is_active'=>'boolean']);
        $t->update($request->only(['name','subject','body_html','is_active']));
        return response()->json(['data'=>$t,'message'=>'Template updated.']);
    }
    public function destroy(int $id): JsonResponse {
        $t = NoticeTemplate::withCount('notices')->findOrFail($id);
        if ($t->notices_count > 0) return response()->json(['message'=>'Cannot delete template with existing notices.'],422);
        $t->update(['is_active'=>false]);
        return response()->json(['message'=>'Template deactivated.']);
    }
}
