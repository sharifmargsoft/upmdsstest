<?php
namespace App\Http\Controllers\API\v1\Master;
use App\Http\Controllers\Controller;
use App\Models\Mineral;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Cache;
class MineralController extends Controller {
    public function index(): JsonResponse {
        $data = Cache::remember('master_minerals',86400,fn()=>Mineral::active()->orderBy('name')->get(['id','name','code','unit']));
        return response()->json(['data'=>$data]);
    }
}
