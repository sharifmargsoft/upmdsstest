<?php
namespace App\Http\Controllers\API\v1\Master;
use App\Http\Controllers\Controller;
use App\Models\District;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Cache;
class DistrictController extends Controller {
    public function index(): JsonResponse {
        $data = Cache::remember('master_districts',3600,fn()=>District::active()->orderBy('name')->get(['id','name','code','state','is_active']));
        return response()->json(['data'=>$data]);
    }
}
