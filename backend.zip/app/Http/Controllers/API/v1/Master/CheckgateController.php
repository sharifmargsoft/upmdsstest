<?php
namespace App\Http\Controllers\API\v1\Master;
use App\Http\Controllers\Controller;
use App\Models\Checkgate;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
class CheckgateController extends Controller {
    public function index(Request $request): JsonResponse {
        $d = $request->integer('district_id') ?: null;
        $data = Cache::remember("master_checkgates_{$d}",3600,fn()=>Checkgate::active()->when($d,fn($q,$d)=>$q->where('district_id',$d))->with('district:id,name')->orderBy('name')->get(['id','district_id','name','code','status','latitude','longitude']));
        return response()->json(['data'=>$data]);
    }
}
