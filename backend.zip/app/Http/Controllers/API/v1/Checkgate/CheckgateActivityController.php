<?php

namespace App\Http\Controllers\API\v1\Checkgate;

use App\Http\Controllers\Controller;
use App\Http\Resources\CheckgateActivityCollection;
use App\Http\Resources\CheckgateActivityResource;
use App\Services\Checkgate\CheckgateActivityService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class CheckgateActivityController extends Controller
{
    public function __construct(
        private readonly CheckgateActivityService $service
    ) {
    }

    /**
     * GET /api/v1/checkgate/activities
     *
     * Cursor-paginated list for large datasets.
     * Filters: date_from, date_to, district_id, checkgate_id, status,
     *          flag_type, vehicle_number, mineral_id
     */
    public function index(Request $request): JsonResponse
    {
        $user    = $request->user();
        $filters = array_merge(
            $request->only([
                'date_from', 'date_to', 'district_id', 'checkgate_id',
                'status', 'flag_type', 'vehicle_number', 'mineral_id', 'per_page',
            ]),
            ['_district_scope' => $user->districtScope()] // row-level security
        );

        $activities = $this->service->list($filters);

        return response()->json([
            'data'       => CheckgateActivityResource::collection($activities),
            'meta'       => [
                'total'        => $activities->total(),
                'current_page' => $activities->currentPage(),
                'last_page'    => $activities->lastPage(),
                'per_page'     => $activities->perPage(),
            ],
            'links' => [
                'prev' => $activities->previousPageUrl(),
                'next' => $activities->nextPageUrl(),
            ],
        ]);
    }

    /**
     * GET /api/v1/checkgate/activities/{id}
     */
    public function show(Request $request, int $id): JsonResponse
    {
        $activity = $this->service->findOrFail($id, $request->user()->districtScope());

        return response()->json([
            'data' => new CheckgateActivityResource($activity),
        ]);
    }

    /**
     * GET /api/v1/checkgate/activities/stats/summary
     * Aggregate stats card for the list view header
     */
    public function stats(Request $request): JsonResponse
    {
        $filters = array_merge(
            $request->only(['date_from', 'date_to', 'district_id', 'checkgate_id']),
            ['_district_scope' => $request->user()->districtScope()]
        );

        return response()->json([
            'data' => $this->service->getStats($filters),
        ]);
    }

    /**
     * PUT /api/v1/checkgate/activities/{id}/review
     * TSE reviews and updates case status
     */
    public function review(Request $request, int $id): JsonResponse
    {
        $request->validate([
            'status'  => 'required|in:pending_notice,ignored',
            'remarks' => 'required|string|max:500',
        ]);

        $activity = $this->service->review(
            id: $id,
            status: $request->input('status'),
            remarks: $request->input('remarks'),
            reviewer: $request->user(),
        );

        return response()->json([
            'data'    => new CheckgateActivityResource($activity),
            'message' => 'Case reviewed successfully.',
        ]);
    }

    /**
     * PUT /api/v1/checkgate/activities/{id}/correct-vehicle
     * TSE corrects vehicle number (ANPR misread)
     */
    public function correctVehicle(Request $request, int $id): JsonResponse
    {
        $request->validate([
            'vehicle_number' => 'required|string|min:6|max:20',
            'remarks'        => 'required|string|max:500',
        ]);

        $activity = $this->service->correctVehicleNumber(
            id: $id,
            vehicleNumber: $request->input('vehicle_number'),
            remarks: $request->input('remarks'),
            reviewer: $request->user(),
        );

        return response()->json([
            'data'    => new CheckgateActivityResource($activity),
            'message' => 'Vehicle number corrected and APIs re-fetched.',
        ]);
    }

    /**
     * PUT /api/v1/checkgate/activities/{id}/ignore
     */
    public function ignore(Request $request, int $id): JsonResponse
    {
        $request->validate([
            'reason' => 'required|string|min:10|max:500',
        ]);

        $activity = $this->service->ignore(
            id: $id,
            reason: $request->input('reason'),
            user: $request->user(),
        );

        return response()->json([
            'data'    => new CheckgateActivityResource($activity),
            'message' => 'Case marked as ignored.',
        ]);
    }

    /**
     * GET /api/v1/checkgate/ignored
     * List of ignored cases for re-scrutiny
     */
    public function ignored(Request $request): JsonResponse
    {
        $filters = array_merge(
            $request->only(['date_from', 'date_to', 'district_id', 'checkgate_id']),
            ['_district_scope' => $request->user()->districtScope(), 'status' => 'ignored']
        );

        $activities = $this->service->list($filters);

        return response()->json([
            'data' => CheckgateActivityResource::collection($activities),
            'meta' => ['total' => $activities->total()],
        ]);
    }

    /**
     * POST /api/v1/checkgate/activities/{id}/notice
     * Generate e-Notice from checkgate case
     */
    public function generateNotice(Request $request, int $id): JsonResponse
    {
        $request->validate([
            'template_id'    => 'required|integer|exists:notice_templates,id',
            'penalty_amount' => 'required|numeric|min:1',
            'due_days'       => 'nullable|integer|min:7|max:90',
            'remarks'        => 'nullable|string|max:500',
        ]);

        $notice = $this->service->generateNotice(
            activityId: $id,
            templateId: $request->integer('template_id'),
            penaltyAmount: $request->float('penalty_amount'),
            dueDays: $request->integer('due_days', 30),
            issuedBy: $request->user(),
        );

        return response()->json([
            'data'    => ['notice_id' => $notice->id, 'notice_number' => $notice->notice_number],
            'message' => 'e-Notice generated successfully.',
        ], 201);
    }
}
