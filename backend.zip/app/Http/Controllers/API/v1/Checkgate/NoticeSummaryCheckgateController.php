<?php
namespace App\Http\Controllers\API\v1\Checkgate;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class NoticeSummaryCheckgateController extends Controller {
    public function index(Request $request): JsonResponse {
        $data = DB::table('e_notices as n')->join('districts as d','n.district_id','=','d.id')
            ->select('d.id as district_id','d.name as district_name',DB::raw('COUNT(n.id) as notice_count'),DB::raw('COALESCE(SUM(n.penalty_amount),0) as penalty_total'),DB::raw('COALESCE(SUM(n.paid_amount),0) as recovered'),DB::raw('COALESCE(SUM(n.penalty_amount-n.paid_amount),0) as pending'),DB::raw("COUNT(n.id) FILTER (WHERE n.status='paid') as paid_count"),DB::raw("COUNT(n.id) FILTER (WHERE n.status='cancelled') as cancelled_count"),DB::raw('ROUND(COALESCE(SUM(n.paid_amount),0)::numeric/NULLIF(COALESCE(SUM(n.penalty_amount),0),0)*100,1) as recovery_pct'))
            ->where('n.source_type','checkgate')
            ->when($request->user()->districtScope(),fn($q,$d)=>$q->where('n.district_id',$d))
            ->when($request->date_from,fn($q,$d)=>$q->where('n.issued_at','>=',$d))
            ->when($request->date_to,  fn($q,$d)=>$q->where('n.issued_at','<=',$d))
            ->groupBy('d.id','d.name')->orderByDesc('penalty_total')->get();
        return response()->json(['data'=>$data]);
    }
}
