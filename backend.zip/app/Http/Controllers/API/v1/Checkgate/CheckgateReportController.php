<?php
namespace App\Http\Controllers\API\v1\Checkgate;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class CheckgateReportController extends Controller {
    public function progress(Request $request): JsonResponse {
        $data = DB::table('checkgate_activities as ca')->join('checkgates as cg','ca.checkgate_id','=','cg.id')->join('districts as d','ca.district_id','=','d.id')
            ->select('d.name as district_name','cg.name as gate_name','cg.code',DB::raw('COUNT(*) as total'),DB::raw("COUNT(*) FILTER (WHERE ca.flag_type != 'valid') as violations"),DB::raw("COUNT(*) FILTER (WHERE ca.status = 'pending_notice') as pending_notice"),DB::raw("COUNT(*) FILTER (WHERE ca.status = 'notice_sent') as notice_sent"),DB::raw("COUNT(*) FILTER (WHERE ca.status = 'ignored') as ignored"),DB::raw("COUNT(*) FILTER (WHERE ca.status = 'closed') as closed"))
            ->when($request->user()->districtScope(),fn($q,$d)=>$q->where('ca.district_id',$d))
            ->when($request->date_from,fn($q,$d)=>$q->where('ca.crossing_at','>=',$d))
            ->when($request->date_to,  fn($q,$d)=>$q->where('ca.crossing_at','<=',$d))
            ->when($request->checkgate_id,fn($q,$c)=>$q->where('ca.checkgate_id',$c))
            ->groupBy('d.name','cg.name','cg.code')->orderByDesc('violations')->get();
        return response()->json(['data'=>$data]);
    }
    public function smudge(Request $request): JsonResponse {
        $data = DB::table('checkgate_activities')
            ->select('vehicle_number_minetag','vehicle_number_anpr','vehicle_number_norm','mine_tag_id','crossing_at','checkgate_id')
            ->where('flag_type','obscured_plate')->whereNotNull('mine_tag_id')
            ->when($request->user()->districtScope(),fn($q,$d)=>$q->where('district_id',$d))
            ->orderByDesc('crossing_at')->limit(500)->get();
        return response()->json(['data'=>$data]);
    }
    public function ignoreStats(Request $request): JsonResponse {
        $data = DB::table('checkgate_activities as ca')->join('users as u','ca.tse_reviewed_by','=','u.id')->join('districts as d','ca.district_id','=','d.id')
            ->select('d.name as district_name','u.name as officer_name',DB::raw('COUNT(*) as ignored_count'))
            ->where('ca.status','ignored')
            ->when($request->user()->districtScope(),fn($q,$d)=>$q->where('ca.district_id',$d))
            ->groupBy('d.name','u.name')->orderByDesc('ignored_count')->get();
        return response()->json(['data'=>$data]);
    }
}
