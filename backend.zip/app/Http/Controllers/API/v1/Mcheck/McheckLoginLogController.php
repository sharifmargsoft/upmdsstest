<?php

namespace App\Http\Controllers\API\v1\Mcheck;

use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class McheckLoginLogController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $perPage = min((int)($request->per_page ?? 25), 100);
        $logs = DB::table('mcheck_login_logs as ml')
            ->join('users as u','ml.user_id','=','u.id')
            ->select('ml.id','u.name as user_name','ml.device_id','ml.app_version',
                'ml.login_at','ml.logout_at','ml.session_duration','ml.ip_address')
            ->when($request->user()->districtScope(), fn($q,$d) =>
                $q->join('users as u2','ml.user_id','=','u2.id')->where('u2.district_id',$d))
            ->when($request->date_from, fn($q,$d) => $q->where('ml.login_at','>=',$d))
            ->when($request->date_to,   fn($q,$d) => $q->where('ml.login_at','<=',$d))
            ->orderByDesc('ml.login_at')
            ->paginate($perPage);

        return response()->json([
            'data' => $logs->items(),
            'meta' => ['total'=>$logs->total(),'current_page'=>$logs->currentPage(),'last_page'=>$logs->lastPage(),'per_page'=>$logs->perPage()],
        ]);
    }
}
