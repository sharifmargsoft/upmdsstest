<?php

namespace App\Http\Controllers\API\v1\Mcheck;

use App\Http\Controllers\Controller;
use App\Models\McheckActivity;
use App\Services\Notice\ENoticeService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class McheckActivityController extends Controller
{
    public function __construct(private readonly ENoticeService $noticeService) {}

    public function index(Request $request): JsonResponse
    {
        $perPage = min((int)($request->per_page ?? 25), 100);
        $activities = McheckActivity::query()
            ->with(['inspector:id,name,designation', 'district:id,name', 'mineral:id,name'])
            ->forDistrict($request->user()->districtScope())
            ->when($request->district_id,    fn($q,$d) => $q->where('district_id',$d))
            ->when($request->status,         fn($q,$s) => $q->where('status',$s))
            ->when($request->vehicle_number, fn($q,$v) => $q->where('vehicle_number_norm', strtoupper(preg_replace('/\s+/','',$v))))
            ->when($request->date_from,      fn($q,$d) => $q->where('inspected_at','>=',$d))
            ->when($request->date_to,        fn($q,$d) => $q->where('inspected_at','<=',$d))
            ->orderByDesc('inspected_at')
            ->paginate($perPage);

        return response()->json([
            'data' => $activities->items(),
            'meta' => ['total'=>$activities->total(),'current_page'=>$activities->currentPage(),'last_page'=>$activities->lastPage(),'per_page'=>$activities->perPage()],
        ]);
    }

    public function show(Request $request, int $id): JsonResponse
    {
        $activity = McheckActivity::with(['inspector','district','mineral','notice'])
            ->forDistrict($request->user()->districtScope())
            ->findOrFail($id);
        return response()->json(['data' => $activity]);
    }

    public function generateNotice(Request $request, int $id): JsonResponse
    {
        $request->validate([
            'template_id'    => 'required|integer|exists:notice_templates,id',
            'penalty_amount' => 'required|numeric|min:1',
            'due_days'       => 'nullable|integer|min:7|max:90',
        ]);

        $activity = McheckActivity::forDistrict($request->user()->districtScope())->findOrFail($id);
        if ($activity->notice_id) {
            return response()->json(['message' => 'Notice already generated.'], 422);
        }

        $notice = DB::transaction(function () use ($activity, $request) {
            $n = $this->noticeService->create(
                sourceType: 'mcheck', sourceId: $activity->id,
                districtId: $activity->district_id,
                vehicleNumber: $activity->vehicle_number_norm ?? $activity->vehicle_number,
                offenseType: $activity->offense_type ?? 'unknown',
                offenseDate: $activity->inspected_at->toDateString(),
                offenseLocation: $activity->inspection_address ?? "GPS: {$activity->inspection_lat},{$activity->inspection_lng}",
                mineralName: $activity->mineral_name, etpNumber: $activity->etp_number,
                templateId: $request->integer('template_id'),
                penaltyAmount: $request->float('penalty_amount'),
                dueDays: $request->integer('due_days', 30),
                issuedBy: $request->user(),
                evidenceUrls: $activity->evidence_photos ?? [],
            );
            $activity->update(['status' => 'notice_sent', 'notice_id' => $n->id]);
            return $n;
        });

        return response()->json(['data' => ['notice_id' => $notice->id, 'notice_number' => $notice->notice_number], 'message' => 'Notice generated.'], 201);
    }

    public function noticeSummary(Request $request): JsonResponse
    {
        $data = DB::table('e_notices as n')
            ->join('districts as d','n.district_id','=','d.id')
            ->select('d.id as district_id','d.name as district_name',
                DB::raw('COUNT(*) as notice_count'),
                DB::raw('SUM(n.penalty_amount) as penalty_total'),
                DB::raw('SUM(n.paid_amount) as recovered'),
                DB::raw('SUM(n.penalty_amount-n.paid_amount) as pending'),
                DB::raw('ROUND(SUM(n.paid_amount)::numeric/NULLIF(SUM(n.penalty_amount),0)*100,1) as recovery_pct'))
            ->where('n.source_type','mcheck')
            ->when($request->user()->districtScope(), fn($q,$d) => $q->where('n.district_id',$d))
            ->groupBy('d.id','d.name')->orderByDesc('penalty_total')->get();
        return response()->json(['data' => $data]);
    }

    public function activityLog(Request $request): JsonResponse
    {
        $data = DB::table('mcheck_activities as ma')
            ->join('users as u','ma.inspector_id','=','u.id')
            ->select('ma.id','ma.vehicle_number','ma.offense_type','ma.status','ma.inspected_at','u.name as inspector_name')
            ->when($request->user()->districtScope(), fn($q,$d) => $q->where('ma.district_id',$d))
            ->orderByDesc('ma.inspected_at')->limit(500)->get();
        return response()->json(['data' => $data]);
    }
}
