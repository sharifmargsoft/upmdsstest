<?php

namespace App\Http\Controllers\API\v1\Weighbridge;

use App\Http\Controllers\Controller;
use App\Models\WeighbridgeActivity;
use App\Services\Notice\ENoticeService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class WeighbridgeActivityController extends Controller
{
    public function __construct(private readonly ENoticeService $noticeService) {}

    private function baseQuery(Request $request)
    {
        return WeighbridgeActivity::query()
            ->with(['weighbridge:id,name,code','district:id,name'])
            ->forDistrict($request->user()->districtScope())
            ->when($request->district_id, fn($q,$d) => $q->where('district_id',$d))
            ->when($request->date_from,   fn($q,$d) => $q->where('weighed_at','>=',$d))
            ->when($request->date_to,     fn($q,$d) => $q->where('weighed_at','<=',$d))
            ->orderByDesc('weighed_at');
    }

    private function paginate($query, Request $request): JsonResponse
    {
        $perPage = min((int)($request->per_page ?? 25), 100);
        $result  = $query->paginate($perPage);
        return response()->json([
            'data' => $result->items(),
            'meta' => ['total'=>$result->total(),'current_page'=>$result->currentPage(),'last_page'=>$result->lastPage(),'per_page'=>$result->perPage()],
        ]);
    }

    public function valid(Request $request): JsonResponse          { return $this->paginate($this->baseQuery($request)->where('anomaly_type','none'), $request); }
    public function overloaded(Request $request): JsonResponse     { return $this->paginate($this->baseQuery($request)->where('is_overloaded',true), $request); }
    public function volumeMismatch(Request $request): JsonResponse  { return $this->paginate($this->baseQuery($request)->where('anomaly_type','volume_mismatch'), $request); }
    public function noEmm11(Request $request): JsonResponse        { return $this->paginate($this->baseQuery($request)->where('has_emm11',false), $request); }
    public function anomalyNotices(Request $request): JsonResponse { return $this->paginate($this->baseQuery($request)->anomalies()->whereNotNull('notice_id'), $request); }

    public function generateNotice(Request $request, int $id): JsonResponse
    {
        $request->validate(['template_id'=>'required|integer|exists:notice_templates,id','penalty_amount'=>'required|numeric|min:1','due_days'=>'nullable|integer|min:7|max:90']);
        $activity = WeighbridgeActivity::forDistrict($request->user()->districtScope())->findOrFail($id);
        if ($activity->notice_id) return response()->json(['message'=>'Notice already issued.'],422);

        $notice = DB::transaction(function () use ($activity,$request) {
            $n = $this->noticeService->create('weighbridge',$activity->id,$activity->district_id,
                $activity->vehicle_number_norm??$activity->vehicle_number,$activity->anomaly_type,
                $activity->weighed_at->toDateString(),$activity->weighbridge?->name,$activity->mineral_name,
                $activity->etp_number,$request->integer('template_id'),$request->float('penalty_amount'),
                $request->integer('due_days',30),$request->user());
            $activity->update(['status'=>'notice_sent','notice_id'=>$n->id]);
            return $n;
        });

        return response()->json(['data'=>['notice_id'=>$notice->id,'notice_number'=>$notice->notice_number],'message'=>'Notice generated.'],201);
    }
}
