<?php
namespace App\Http\Controllers\API\v1\Auth;
use App\Http\Controllers\Controller;
use App\Http\Resources\UserResource;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules\Password;
class ProfileController extends Controller {
    public function show(Request $request): JsonResponse {
        return response()->json(['data'=>new UserResource($request->user()->load(['role','district']))]);
    }
    public function update(Request $request): JsonResponse {
        $user = $request->user();
        $request->validate(['name'=>'sometimes|string|max:150',"email"=>"nullable|email|unique:users,email,{$user->id}",'mobile'=>'nullable|string|size:10','designation'=>'nullable|string|max:150']);
        $user->update($request->only(['name','email','mobile','designation']));
        return response()->json(['data'=>new UserResource($user->fresh(['role','district'])),'message'=>'Profile updated.']);
    }
    public function changePassword(Request $request): JsonResponse {
        $request->validate(['current_password'=>'required|string','password'=>['required','confirmed',Password::min(8)->letters()->numbers()],'password_confirmation'=>'required']);
        $user = $request->user();
        if (!Hash::check($request->current_password,$user->password)) {
            return response()->json(['message'=>'Current password is incorrect.','code'=>'WRONG_PASSWORD'],422);
        }
        $user->update(['password'=>Hash::make($request->password)]);
        $user->tokens()->where('id','!=',$user->currentAccessToken()->id)->delete();
        return response()->json(['message'=>'Password changed successfully.']);
    }
}
