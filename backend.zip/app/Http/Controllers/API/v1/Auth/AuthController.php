<?php

namespace App\Http\Controllers\API\v1\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\LoginRequest;
use App\Http\Resources\UserResource;
use App\Models\LoginLog;
use App\Models\User;
use App\Services\Auth\AuthService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;

class AuthController extends Controller
{
    public function __construct(private readonly AuthService $authService)
    {
    }

    /**
     * POST /api/v1/auth/login
     *
     * Returns: { user, token, permissions, expires_at }
     */
    public function login(LoginRequest $request): JsonResponse
    {
        $result = $this->authService->login(
            username: $request->input('username'),
            password: $request->input('password'),
            ip: $request->ip(),
            userAgent: $request->userAgent(),
        );

        if (! $result['success']) {
            return response()->json([
                'message' => $result['message'],
                'code'    => 'INVALID_CREDENTIALS',
            ], 401);
        }

        return response()->json([
            'data' => [
                'user'        => new UserResource($result['user']),
                'token'       => $result['token'],
                'token_type'  => 'Bearer',
                'expires_at'  => $result['expires_at'],
                'permissions' => $result['permissions'],
            ],
            'message' => 'Login successful',
        ]);
    }

    /**
     * POST /api/v1/auth/logout
     */
    public function logout(Request $request): JsonResponse
    {
        // Revoke current token
        $request->user()->currentAccessToken()->delete();

        // Flush cached permissions for this user
        Cache::forget("user_permissions_{$request->user()->id}");

        // Log the logout
        LoginLog::where('user_id', $request->user()->id)
            ->whereNull('logged_out_at')
            ->latest('logged_in_at')
            ->first()
            ?->update(['logged_out_at' => now()]);

        return response()->json(['message' => 'Logged out successfully']);
    }

    /**
     * GET /api/v1/auth/permissions
     *
     * Returns user's flat permission list — cached per user for 15 min.
     */
    public function permissions(Request $request): JsonResponse
    {
        $user = $request->user();
        $cacheKey = "user_permissions_{$user->id}";

        $permissions = Cache::remember($cacheKey, 900, function () use ($user) {
            return $user->getAllPermissions()->pluck('name')->toArray();
        });

        return response()->json([
            'data' => [
                'role'        => $user->role?->name,
                'permissions' => $permissions,
                'district_id' => $user->district_id,
                'is_state_level' => $user->isStateLevel(),
            ],
        ]);
    }

    /**
     * POST /api/v1/auth/forgot-password
     */
    public function forgotPassword(Request $request): JsonResponse
    {
        $request->validate(['username' => 'required|string']);

        $this->authService->sendPasswordResetOtp($request->input('username'));

        return response()->json([
            'message' => 'If an account exists, a reset OTP has been sent to registered mobile.',
        ]);
    }

    /**
     * POST /api/v1/auth/reset-password
     */
    public function resetPassword(Request $request): JsonResponse
    {
        $request->validate([
            'username'             => 'required|string',
            'otp'                  => 'required|string|size:6',
            'password'             => 'required|string|min:8|confirmed',
            'password_confirmation' => 'required|string',
        ]);

        $result = $this->authService->resetPassword(
            username: $request->input('username'),
            otp: $request->input('otp'),
            password: $request->input('password'),
        );

        if (! $result['success']) {
            return response()->json(['message' => $result['message'], 'code' => 'INVALID_OTP'], 422);
        }

        return response()->json(['message' => 'Password reset successfully.']);
    }
}
