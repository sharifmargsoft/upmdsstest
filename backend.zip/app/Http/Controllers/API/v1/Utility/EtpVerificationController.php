<?php
namespace App\Http\Controllers\API\v1\Utility;
use App\Http\Controllers\Controller;
use App\Services\External\UpMinesApiService;
use Illuminate\Http\JsonResponse;
class EtpVerificationController extends Controller {
    public function __construct(private readonly UpMinesApiService $upMinesApi) {}
    public function verify(string $etpNumber): JsonResponse {
        $data = $this->upMinesApi->verifyEtp($etpNumber);
        if (!($data['success'] ?? false)) return response()->json(['message'=>'eTP not found or verification failed.'],404);
        return response()->json(['data'=>$data]);
    }
}
