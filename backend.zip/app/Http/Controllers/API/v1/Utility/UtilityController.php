<?php
namespace App\Http\Controllers\API\v1\Utility;
use App\Http\Controllers\Controller;
use App\Models\ENotice;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class UtilityController extends Controller {
    public function loginLogs(Request $request): JsonResponse {
        $perPage = min((int)($request->per_page ?? 25),100);
        $logs = DB::table('login_logs')
            ->join('users as u','login_logs.user_id','=','u.id')
            ->join('roles as r','u.role_id','=','r.id')
            ->select('login_logs.*','u.name as user_name','u.username','r.name as role_name')
            ->when($request->date_from,fn($q,$d)=>$q->where('login_logs.logged_in_at','>=',$d))
            ->when($request->date_to,  fn($q,$d)=>$q->where('login_logs.logged_in_at','<=',$d))
            ->when($request->status,   fn($q,$s)=>$q->where('login_logs.status',$s))
            ->orderByDesc('login_logs.logged_in_at')->paginate($perPage);
        return response()->json(['data'=>$logs->items(),'meta'=>['total'=>$logs->total(),'current_page'=>$logs->currentPage(),'last_page'=>$logs->lastPage(),'per_page'=>$logs->perPage()]]);
    }
    public function searchTransporter(Request $request): JsonResponse {
        $q = $request->get('q');
        if (empty($q)||strlen($q)<3) return response()->json(['data'=>[]]);
        $notices = ENotice::query()
            ->select(['id','notice_number','vehicle_number','vehicle_owner_name','vehicle_owner_mobile','penalty_amount','paid_amount','status','issued_at'])
            ->where(fn($query)=>$query->where('notice_number','ilike',"%{$q}%")->orWhere('vehicle_number_norm','ilike',"%".strtoupper(preg_replace('/\s+/','',$q))."%")->orWhere('vehicle_owner_name','ilike',"%{$q}%")->orWhere('vehicle_owner_mobile','like',"%{$q}%"))
            ->when($request->user()->districtScope(),fn($query,$d)=>$query->where('district_id',$d))
            ->orderByDesc('issued_at')->limit(20)->get();
        return response()->json(['data'=>$notices]);
    }
    public function geoInspection(Request $request): JsonResponse {
        $data = DB::table('mcheck_activities as ma')->join('users as u','ma.inspector_id','=','u.id')
            ->select('ma.id','ma.vehicle_number','ma.offense_type','ma.inspection_lat','ma.inspection_lng','ma.inspection_address','ma.inspected_at','u.name as inspector_name')
            ->whereNotNull('ma.inspection_lat')
            ->when($request->user()->districtScope(),fn($q,$d)=>$q->where('ma.district_id',$d))
            ->when($request->date_from,fn($q,$d)=>$q->where('ma.inspected_at','>=',$d))
            ->orderByDesc('ma.inspected_at')->limit(500)->get();
        return response()->json(['data'=>$data]);
    }
}
