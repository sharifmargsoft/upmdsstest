<?php

namespace App\Http\Controllers\API\v1\Assign;

use App\Http\Controllers\Controller;
use App\Models\CaseAssignment;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CaseAssignmentController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $assignments = CaseAssignment::query()
            ->with(['assignedTo:id,name','assignedBy:id,name'])
            ->when($request->status,      fn($q,$s) => $q->where('status',$s))
            ->when($request->district_id, fn($q,$d) => $q->where('district_id',$d))
            ->when($request->user()->districtScope(), fn($q,$d) => $q->where('district_id',$d))
            ->orderByDesc('created_at')
            ->paginate(min((int)($request->per_page ?? 25), 100));

        return response()->json([
            'data' => $assignments->items(),
            'meta' => ['total'=>$assignments->total(),'current_page'=>$assignments->currentPage(),'last_page'=>$assignments->lastPage(),'per_page'=>$assignments->perPage()],
        ]);
    }

    public function summary(Request $request): JsonResponse
    {
        $scope = $request->user()->districtScope();
        $summary = DB::table('case_assignments')
            ->select(
                DB::raw('COUNT(*) as total'),
                DB::raw("COUNT(*) FILTER (WHERE status IN ('open','in_progress')) as open"),
                DB::raw("COUNT(*) FILTER (WHERE status = 'completed') as completed"),
                DB::raw("COUNT(*) FILTER (WHERE status = 'overdue') as overdue")
            )
            ->when($scope, fn($q,$d) => $q->where('district_id',$d))
            ->first();
        return response()->json(['data' => $summary]);
    }

    public function show(int $id): JsonResponse
    {
        $a = CaseAssignment::with(['assignedTo','assignedBy'])->findOrFail($id);
        return response()->json(['data' => $a]);
    }

    public function store(Request $request): JsonResponse
    {
        $request->validate([
            'source_type' => 'required|in:checkgate,mcheck,weighbridge',
            'source_id'   => 'required|integer',
            'assigned_to' => 'required|integer|exists:users,id',
            'due_date'    => 'nullable|date|after:today',
            'priority'    => 'nullable|in:low,normal,high,urgent',
            'remarks'     => 'nullable|string|max:500',
        ]);

        $a = CaseAssignment::create([
            ...$request->only(['source_type','source_id','assigned_to','due_date','priority','remarks']),
            'assigned_by' => $request->user()->id,
            'district_id' => $request->user()->district_id,
            'status'      => 'open',
        ]);

        return response()->json(['data' => $a->load('assignedTo','assignedBy'), 'message' => 'Case assigned.'], 201);
    }

    public function complete(Request $request, int $id): JsonResponse
    {
        $request->validate(['completion_note'=>'required|string|min:5|max:500']);
        $a = CaseAssignment::findOrFail($id);
        $a->update(['status'=>'completed','completion_note'=>$request->completion_note,'completed_at'=>now()]);
        return response()->json(['message' => 'Assignment marked as completed.']);
    }
}
