<?php
namespace App\Http\Controllers\API\v1\Report;
use App\Http\Controllers\Controller;
use App\Exports\GenericReportExport;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Facades\Excel;
class ReportController extends Controller {
    public function mcheckActivity(Request $request): JsonResponse {
        $data = DB::table('mcheck_activities as ma')->join('users as u','ma.inspector_id','=','u.id')->join('districts as d','ma.district_id','=','d.id')
            ->select('u.name as inspector_name','d.name as district_name',DB::raw('COUNT(*) as total_inspections'),DB::raw('COUNT(*) FILTER (WHERE ma.offense_type IS NOT NULL) as offenses_detected'),DB::raw('COUNT(ma.notice_id) as notices_issued'),DB::raw('ROUND(COUNT(ma.notice_id)::numeric/NULLIF(COUNT(*),0)*100,1) as notice_yield_pct'))
            ->when($request->user()->districtScope(),fn($q,$d)=>$q->where('ma.district_id',$d))
            ->when($request->date_from,fn($q,$d)=>$q->where('ma.inspected_at','>=',$d))
            ->when($request->date_to,  fn($q,$d)=>$q->where('ma.inspected_at','<=',$d))
            ->groupBy('u.name','d.name')->orderByDesc('total_inspections')->get();
        return response()->json(['data'=>$data]);
    }
    public function checkgateMcheckAnalysis(Request $request): JsonResponse {
        $d = $request->user()->districtScope();
        $cg = DB::selectOne("SELECT 'checkgate' as source,COUNT(*) as total,COUNT(*) FILTER (WHERE flag_type!='valid') as violations,COUNT(notice_id) as notices FROM checkgate_activities".($d?" WHERE district_id=$d":""));
        $mc = DB::selectOne("SELECT 'mcheck' as source,COUNT(*) as total,COUNT(*) FILTER (WHERE offense_type IS NOT NULL) as offenses,COUNT(notice_id) as notices FROM mcheck_activities".($d?" WHERE district_id=$d":""));
        return response()->json(['data'=>[$cg,$mc]]);
    }
    public function weighmentVolumeMismatch(Request $request): JsonResponse {
        $data = DB::table('weighbridge_activities as wa')->join('weighbridges as wb','wa.weighbridge_id','=','wb.id')->join('districts as d','wa.district_id','=','d.id')
            ->select('d.name as district_name','wb.name as weighbridge_name','wa.vehicle_number','wa.etp_number','wa.weight_declared','wa.weight_actual','wa.volume_mismatch_pct','wa.notice_id','wa.weighed_at')
            ->where('wa.anomaly_type','volume_mismatch')
            ->when($request->user()->districtScope(),fn($q,$d)=>$q->where('wa.district_id',$d))
            ->orderByDesc('wa.volume_mismatch_pct')->limit(500)->get();
        return response()->json(['data'=>$data]);
    }
    public function weighmentEmm11(Request $request): JsonResponse {
        $data = DB::table('weighbridge_activities as wa')->join('districts as d','wa.district_id','=','d.id')
            ->select('d.name as district_name','wa.vehicle_number','wa.etp_number','wa.emm11_number','wa.weight_actual','wa.mineral_name','wa.weighed_at')
            ->where('wa.has_emm11',false)
            ->when($request->user()->districtScope(),fn($q,$d)=>$q->where('wa.district_id',$d))
            ->orderByDesc('wa.weighed_at')->limit(500)->get();
        return response()->json(['data'=>$data]);
    }
    public function defaulterVehicles(Request $request): JsonResponse {
        $data = DB::table('e_notices as n')->join('districts as d','n.district_id','=','d.id')->leftJoin('vehicles as v','n.vehicle_number_norm','=','v.vehicle_number_norm')
            ->select('n.vehicle_number',DB::raw('MAX(v.owner_name) as owner_name'),'d.name as district_name',DB::raw('COUNT(*) as offense_count'),DB::raw('COALESCE(SUM(n.penalty_amount-n.paid_amount),0) as pending_amount'),DB::raw('BOOL_OR(COALESCE(v.is_blacklisted,false)) as is_blacklisted'),DB::raw('MAX(n.issued_at) as last_offense'))
            ->when($request->user()->districtScope(),fn($q,$d)=>$q->where('n.district_id',$d))
            ->groupBy('n.vehicle_number','d.name')->having(DB::raw('COUNT(*)'),'>', 1)->orderByDesc('pending_amount')->limit(200)->get();
        return response()->json(['data'=>$data]);
    }
    public function export(Request $request): \Symfony\Component\HttpFoundation\BinaryFileResponse {
        $request->validate(['report_type'=>'required|string']);
        $filename = "upmdss_{$request->report_type}_".now()->format('Ymd_His').".xlsx";
        return Excel::download(new GenericReportExport($request->report_type,$request->all()),$filename);
    }
}
