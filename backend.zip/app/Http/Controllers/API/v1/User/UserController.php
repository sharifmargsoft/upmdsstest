<?php

namespace App\Http\Controllers\API\v1\User;

use App\Http\Controllers\Controller;
use App\Http\Resources\UserResource;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules\Password;

class UserController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $perPage = min((int)($request->per_page ?? 25), 100);
        $users = User::with(['role:id,name,display_name','district:id,name,code'])
            ->when($request->search, fn($q,$s) => $q->where(fn($q)=>$q->where('name','ilike',"%$s%")->orWhere('username','ilike',"%$s%")))
            ->when($request->role,        fn($q,$r) => $q->byRole($r))
            ->when($request->district_id, fn($q,$d) => $q->inDistrict($d))
            ->when(isset($request->is_active), fn($q) => $q->where('is_active',(bool)$request->is_active))
            ->withoutTrashed()->orderBy('name')->paginate($perPage);

        return response()->json([
            'data' => UserResource::collection($users),
            'meta' => ['total'=>$users->total(),'current_page'=>$users->currentPage(),'last_page'=>$users->lastPage(),'per_page'=>$users->perPage()],
        ]);
    }

    public function show(int $id): JsonResponse
    {
        $user = User::with(['role','district','assignedCheckgates'])->findOrFail($id);
        return response()->json(['data' => new UserResource($user)]);
    }

    public function store(Request $request): JsonResponse
    {
        $request->validate([
            'name'          => 'required|string|max:150',
            'username'      => 'required|string|max:80|unique:users,username|regex:/^[a-z0-9_]+$/',
            'email'         => 'nullable|email|unique:users,email',
            'mobile'        => 'nullable|string|size:10',
            'password'      => ['required', Password::min(8)->letters()->numbers()],
            'designation'   => 'nullable|string|max:150',
            'employee_id'   => 'nullable|string|max:50',
            'role_id'       => 'required|integer|exists:roles,id',
            'district_id'   => 'nullable|integer|exists:districts,id',
            'is_mcheck_user'=> 'boolean',
        ]);

        $user = User::create([
            ...$request->only(['name','username','email','mobile','designation','employee_id','role_id','district_id','is_mcheck_user']),
            'password'   => Hash::make($request->password),
            'created_by' => $request->user()->id,
        ]);

        $roleName = \App\Models\Role::find($request->role_id)?->name;
        if ($roleName) $user->assignRole($roleName);

        return response()->json(['data' => new UserResource($user->load('role','district')), 'message' => 'User created.'], 201);
    }

    public function update(Request $request, int $id): JsonResponse
    {
        $user = User::findOrFail($id);
        $request->validate([
            'name'          => 'sometimes|string|max:150',
            'email'         => "nullable|email|unique:users,email,{$id}",
            'mobile'        => 'nullable|string|size:10',
            'designation'   => 'nullable|string|max:150',
            'employee_id'   => 'nullable|string|max:50',
            'role_id'       => 'sometimes|integer|exists:roles,id',
            'district_id'   => 'nullable|integer|exists:districts,id',
            'is_mcheck_user'=> 'boolean',
        ]);

        $user->update($request->only(['name','email','mobile','designation','employee_id','role_id','district_id','is_mcheck_user']));

        if ($request->has('role_id')) {
            $roleName = \App\Models\Role::find($request->role_id)?->name;
            if ($roleName) $user->syncRoles([$roleName]);
        }

        return response()->json(['data' => new UserResource($user->load('role','district')), 'message' => 'User updated.']);
    }

    public function toggleStatus(int $id): JsonResponse
    {
        $user = User::findOrFail($id);
        $user->update(['is_active' => !$user->is_active]);
        if (!$user->is_active) $user->tokens()->delete();
        return response()->json(['message' => "User " . ($user->is_active ? 'activated' : 'deactivated') . "."]);
    }

    public function resetPassword(int $id): JsonResponse
    {
        $user = User::findOrFail($id);
        $temp = 'UPMDSS@' . rand(1000,9999);
        $user->update(['password' => Hash::make($temp)]);
        $user->tokens()->delete();
        return response()->json(['message' => 'Password reset. User must use temporary credentials to login.']);
    }
}
