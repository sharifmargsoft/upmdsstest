<?php

namespace App\Http\Controllers\API\v1\Blacklist;

use App\Http\Controllers\Controller;
use App\Models\Vehicle;
use App\Models\VehicleBlacklist;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BlacklistController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $items = VehicleBlacklist::query()
            ->with(['district:id,name','blacklistedBy:id,name','removedBy:id,name'])
            ->when($request->status,      fn($q,$s) => $q->where('status',$s))
            ->when($request->district_id, fn($q,$d) => $q->where('district_id',$d))
            ->when($request->user()->districtScope(), fn($q,$d) => $q->where('district_id',$d))
            ->orderByDesc('blacklisted_at')
            ->paginate(min((int)($request->per_page ?? 25), 100));

        return response()->json([
            'data' => $items->items(),
            'meta' => ['total'=>$items->total(),'current_page'=>$items->currentPage(),'last_page'=>$items->lastPage(),'per_page'=>$items->perPage()],
        ]);
    }

    public function history(Request $request): JsonResponse
    {
        $items = VehicleBlacklist::query()
            ->with(['district:id,name','blacklistedBy:id,name','removedBy:id,name'])
            ->when($request->user()->districtScope(), fn($q,$d) => $q->where('district_id',$d))
            ->orderByDesc('created_at')
            ->paginate(min((int)($request->per_page ?? 25), 100));

        return response()->json([
            'data' => $items->items(),
            'meta' => ['total'=>$items->total(),'current_page'=>$items->currentPage(),'last_page'=>$items->lastPage(),'per_page'=>$items->perPage()],
        ]);
    }

    public function show(int $id): JsonResponse
    {
        $bl = VehicleBlacklist::with(['district','blacklistedBy','removedBy'])->findOrFail($id);
        return response()->json(['data' => $bl]);
    }

    public function store(Request $request): JsonResponse
    {
        $request->validate([
            'vehicle_number' => 'required|string|min:6|max:20',
            'reason'         => 'required|string|min:10|max:1000',
            'valid_from'     => 'required|date',
            'valid_to'       => 'nullable|date|after:valid_from',
        ]);

        $normalized = strtoupper(preg_replace('/\s+/','',$request->vehicle_number));

        if (VehicleBlacklist::where('vehicle_number_norm',$normalized)->where('status','active')->exists()) {
            return response()->json(['message'=>'Vehicle is already blacklisted.'],422);
        }

        DB::transaction(function () use ($request, $normalized) {
            VehicleBlacklist::create([
                'vehicle_number'      => $request->vehicle_number,
                'vehicle_number_norm' => $normalized,
                'district_id'         => $request->user()->district_id,
                'reason'              => $request->reason,
                'blacklisted_by'      => $request->user()->id,
                'blacklisted_at'      => now(),
                'valid_from'          => $request->valid_from,
                'valid_to'            => $request->valid_to,
                'status'              => 'active',
            ]);
            Vehicle::where('vehicle_number_norm',$normalized)
                ->update(['is_blacklisted'=>true,'blacklisted_at'=>now()]);
        });

        return response()->json(['message'=>'Vehicle blacklisted successfully.'],201);
    }

    public function remove(Request $request, int $id): JsonResponse
    {
        $request->validate([
            'removal_reason'    => 'required|string|min:10|max:500',
            'removal_order_ref' => 'nullable|string|max:100',
        ]);

        $bl = VehicleBlacklist::where('status','active')->findOrFail($id);

        DB::transaction(function () use ($request, $bl) {
            $bl->update([
                'status'            => 'removed',
                'removed_by'        => $request->user()->id,
                'removed_at'        => now(),
                'removal_reason'    => $request->removal_reason,
                'removal_order_ref' => $request->removal_order_ref,
            ]);
            $stillBlacklisted = VehicleBlacklist::where('vehicle_number_norm',$bl->vehicle_number_norm)
                ->where('status','active')->exists();
            if (!$stillBlacklisted) {
                Vehicle::where('vehicle_number_norm',$bl->vehicle_number_norm)
                    ->update(['is_blacklisted'=>false,'blacklisted_at'=>null]);
            }
        });

        return response()->json(['message'=>'Vehicle removed from blacklist.']);
    }

    public function searchVehicle(Request $request): JsonResponse
    {
        $q = strtoupper(preg_replace('/\s+/','',($request->get('q',''))));
        if (strlen($q) < 4) return response()->json(['data'=>[]]);
        $results = Vehicle::where('vehicle_number_norm','ilike',"%{$q}%")
            ->select(['id','vehicle_number','vehicle_number_norm','owner_name','is_blacklisted','gross_weight'])
            ->limit(10)->get();
        return response()->json(['data'=>$results]);
    }
}
