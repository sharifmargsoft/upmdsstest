<?php

namespace App\Http\Controllers\API\v1\Notice;

use App\Http\Controllers\Controller;
use App\Http\Resources\ENoticeResource;
use App\Models\ENotice;
use App\Services\Notice\ENoticeService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ENoticeController extends Controller
{
    public function __construct(private readonly ENoticeService $service) {}

    public function index(Request $request): JsonResponse
    {
        $perPage = min((int)($request->per_page ?? 25), 100);
        $notices = ENotice::query()
            ->with(['district:id,name','issuedBy:id,name'])
            ->forDistrict($request->user()->districtScope())
            ->when($request->district_id,    fn($q,$d) => $q->where('district_id',$d))
            ->when($request->status,         fn($q,$s) => $q->where('status',$s))
            ->when($request->source_type,    fn($q,$s) => $q->where('source_type',$s))
            ->when($request->offense_type,   fn($q,$o) => $q->where('offense_type',$o))
            ->when($request->vehicle_number, fn($q,$v) => $q->where('vehicle_number_norm',strtoupper(preg_replace('/\s+/','',$v))))
            ->when($request->date_from && $request->date_to, fn($q) => $q->dateRange($request->date_from,$request->date_to))
            ->orderByDesc('issued_at')
            ->paginate($perPage);

        return response()->json([
            'data' => ENoticeResource::collection($notices),
            'meta' => ['total'=>$notices->total(),'current_page'=>$notices->currentPage(),'last_page'=>$notices->lastPage(),'per_page'=>$notices->perPage()],
        ]);
    }

    public function show(Request $request, int $id): JsonResponse
    {
        $notice = ENotice::with(['district','issuedBy','template','cancelledBy','auditLogs'])
            ->forDistrict($request->user()->districtScope())->findOrFail($id);
        return response()->json(['data' => new ENoticeResource($notice)]);
    }

    public function cancel(Request $request, int $id): JsonResponse
    {
        $request->validate(['reason'=>'required|string|min:10|max:500']);
        $notice = ENotice::forDistrict($request->user()->districtScope())->findOrFail($id);
        $notice = $this->service->cancel($notice,$request->input('reason'),$request->user());
        return response()->json(['data'=>new ENoticeResource($notice),'message'=>'Notice cancelled.']);
    }

    public function reactivate(Request $request, int $id): JsonResponse
    {
        $request->validate(['remarks'=>'required|string|min:10|max:500']);
        $notice = ENotice::forDistrict($request->user()->districtScope())->findOrFail($id);
        $notice = $this->service->reactivate($notice,$request->input('remarks'),$request->user());
        return response()->json(['data'=>new ENoticeResource($notice),'message'=>'Notice reactivated.']);
    }

    public function recordPayment(Request $request, int $id): JsonResponse
    {
        $request->validate(['amount'=>'required|numeric|min:1','challan_no'=>'required|string','gateway'=>'required|in:rajkosh,edistrict,csc']);
        $notice = ENotice::findOrFail($id);
        $notice = $this->service->recordPayment($notice,$request->float('amount'),$request->input('challan_no'),$request->input('gateway'),$request->input('gateway_response',[]));
        return response()->json(['data'=>new ENoticeResource($notice),'message'=>'Payment recorded.']);
    }

    public function downloadPdf(int $id): JsonResponse|\Illuminate\Http\RedirectResponse
    {
        $notice = ENotice::findOrFail($id);
        if (!$notice->notice_pdf_url) return response()->json(['message'=>'PDF not ready.'],404);
        return redirect($notice->notice_pdf_url);
    }

    public function resend(Request $request, int $id): JsonResponse
    {
        $notice = ENotice::findOrFail($id);
        if ($notice->vehicle_owner_mobile) {
            dispatch(new \App\Jobs\SendNoticeSmsJob($notice->id, $notice->vehicle_owner_mobile));
        }
        return response()->json(['message'=>'Notice resent.']);
    }

    public function payInfo(string $noticeNumber): JsonResponse
    {
        $notice = ENotice::where('notice_number',$noticeNumber)
            ->select(['id','notice_number','vehicle_number','vehicle_owner_name','penalty_amount','paid_amount','status','due_date'])
            ->firstOrFail();
        return response()->json(['data'=>$notice]);
    }

    public function offenseWiseReport(Request $request): JsonResponse
    {
        $data = DB::table('e_notices')
            ->select('offense_type',DB::raw('COUNT(*) as notice_count'),DB::raw('COALESCE(SUM(penalty_amount),0) as penalty_total'),DB::raw('COALESCE(SUM(paid_amount),0) as recovered'),DB::raw('COALESCE(SUM(penalty_amount-paid_amount),0) as pending'),DB::raw('ROUND(COALESCE(SUM(paid_amount),0)::numeric/NULLIF(COALESCE(SUM(penalty_amount),0),0)*100,1) as recovery_pct'))
            ->when($request->user()->districtScope(), fn($q,$d)=>$q->where('district_id',$d))
            ->when($request->date_from,fn($q,$d)=>$q->where('issued_at','>=',$d))
            ->when($request->date_to,  fn($q,$d)=>$q->where('issued_at','<=',$d))
            ->groupBy('offense_type')->orderByDesc('notice_count')->get();
        return response()->json(['data'=>$data]);
    }

    public function summaryReport(Request $request): JsonResponse
    {
        $data = DB::table('e_notices as n')->join('districts as d','n.district_id','=','d.id')
            ->select('d.id as district_id','d.name as district_name','n.source_type',DB::raw('COUNT(*) as notice_count'),DB::raw('COALESCE(SUM(n.penalty_amount),0) as penalty_total'),DB::raw('COALESCE(SUM(n.paid_amount),0) as recovered'),DB::raw('COALESCE(SUM(n.penalty_amount-n.paid_amount),0) as pending'),DB::raw('ROUND(COALESCE(SUM(n.paid_amount),0)::numeric/NULLIF(COALESCE(SUM(n.penalty_amount),0),0)*100,1) as recovery_pct'))
            ->when($request->user()->districtScope(),fn($q,$d)=>$q->where('n.district_id',$d))
            ->groupBy('d.id','d.name','n.source_type')->orderByDesc('penalty_total')->get();
        return response()->json(['data'=>$data]);
    }

    public function defaultersReport(Request $request): JsonResponse
    {
        $data = DB::table('e_notices as n')->join('districts as d','n.district_id','=','d.id')->leftJoin('vehicles as v','n.vehicle_number_norm','=','v.vehicle_number_norm')
            ->select('n.vehicle_number',DB::raw('MAX(v.owner_name) as owner_name'),'d.name as district_name',DB::raw('COUNT(*) as offense_count'),DB::raw('COALESCE(SUM(n.penalty_amount-n.paid_amount),0) as pending_amount'),DB::raw('BOOL_OR(COALESCE(v.is_blacklisted,false)) as is_blacklisted'),DB::raw('MAX(n.issued_at) as last_offense'))
            ->when($request->user()->districtScope(),fn($q,$d)=>$q->where('n.district_id',$d))
            ->groupBy('n.vehicle_number','d.name')->having(DB::raw('COUNT(*)'),'>', 1)->orderByDesc('pending_amount')->limit(200)->get();
        return response()->json(['data'=>$data]);
    }

    public function checkgateMcheckReport(Request $request): JsonResponse
    {
        $d = $request->user()->districtScope();
        $cg = DB::selectOne("SELECT 'checkgate' as source,COUNT(*) as total,COUNT(*) FILTER (WHERE flag_type!='valid') as violations,COUNT(notice_id) as notices FROM checkgate_activities".($d?" WHERE district_id=$d":""));
        $mc = DB::selectOne("SELECT 'mcheck' as source,COUNT(*) as total,COUNT(*) FILTER (WHERE offense_type IS NOT NULL) as offenses,COUNT(notice_id) as notices FROM mcheck_activities".($d?" WHERE district_id=$d":""));
        return response()->json(['data'=>[$cg,$mc]]);
    }

    public function gatewiseReport(Request $request): JsonResponse
    {
        $data = DB::table('e_notices as n')->join('checkgate_activities as ca',fn($j)=>$j->on('ca.id','=','n.source_id')->where('n.source_type','checkgate'))->join('checkgates as cg','ca.checkgate_id','=','cg.id')
            ->select('cg.id','cg.name as gate_name','cg.code',DB::raw('COUNT(n.id) as notice_count'),DB::raw('COALESCE(SUM(n.penalty_amount),0) as penalty_total'),DB::raw('COALESCE(SUM(n.paid_amount),0) as recovered'),DB::raw('COALESCE(SUM(n.penalty_amount-n.paid_amount),0) as pending'))
            ->when($request->user()->districtScope(),fn($q,$d)=>$q->where('n.district_id',$d))->groupBy('cg.id','cg.name','cg.code')->orderByDesc('notice_count')->get();
        return response()->json(['data'=>$data]);
    }
}
