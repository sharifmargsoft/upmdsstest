<?php

namespace App\Http\Controllers\API\v1\Dashboard;

use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;

class MapDashboardController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $user       = $request->user();
        $districtId = $user->districtScope() ?? ($request->integer('district_id') ?: null);
        $cacheKey   = "map_dashboard_{$districtId}";

        $checkgates = Cache::remember($cacheKey, 300, function () use ($districtId) {
            return DB::table('checkgates as cg')
                ->join('districts as d', 'cg.district_id', '=', 'd.id')
                ->select(
                    'cg.id', 'cg.name', 'cg.code', 'cg.status',
                    'cg.latitude', 'cg.longitude',
                    'd.name as district_name',
                    DB::raw("(
                        SELECT COUNT(*)
                        FROM checkgate_activities ca
                        WHERE ca.checkgate_id = cg.id
                        AND ca.crossing_at >= NOW() - INTERVAL '30 days'
                    ) as total_vehicles"),
                    DB::raw("(
                        SELECT COUNT(*)
                        FROM checkgate_activities ca
                        WHERE ca.checkgate_id = cg.id
                        AND ca.flag_type != 'valid'
                        AND ca.crossing_at >= NOW() - INTERVAL '30 days'
                    ) as violations"),
                    DB::raw("(
                        SELECT COUNT(*)
                        FROM e_notices en
                        JOIN checkgate_activities ca2 ON en.source_id = ca2.id AND en.source_type = 'checkgate'
                        WHERE ca2.checkgate_id = cg.id
                    ) as notices"),
                    DB::raw("(
                        SELECT COALESCE(SUM(en.penalty_amount), 0)
                        FROM e_notices en
                        JOIN checkgate_activities ca3 ON en.source_id = ca3.id AND en.source_type = 'checkgate'
                        WHERE ca3.checkgate_id = cg.id
                    ) as penalty_total")
                )
                ->when($districtId, fn($q, $d) => $q->where('cg.district_id', $d))
                ->whereNotNull('cg.latitude')
                ->whereNotNull('cg.longitude')
                ->orderBy('cg.name')
                ->get()
                ->map(fn($cg) => array_merge((array)$cg, [
                    'stats' => [
                        'total_vehicles' => $cg->total_vehicles,
                        'violations'     => $cg->violations,
                        'notices'        => $cg->notices,
                        'penalty_total'  => $cg->penalty_total,
                    ],
                ]));
        });

        return response()->json(['data' => ['checkgates' => $checkgates]]);
    }
}
