<?php

namespace App\Http\Controllers\API\v1\Dashboard;

use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AnalysisDashboardController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        return response()->json([
            'data' => [
                'pendency_vs_recovered' => $this->getDistrictPendency($request),
            ],
        ]);
    }

    public function districtPendency(Request $request): JsonResponse
    {
        return response()->json([
            'data' => $this->getDistrictPendency($request),
        ]);
    }

    private function getDistrictPendency(Request $request): \Illuminate\Support\Collection
    {
        $user   = $request->user();
        $source = $request->get('source', 'overall');

        return DB::table('e_notices as n')
            ->join('districts as d', 'n.district_id', '=', 'd.id')
            ->select(
                'd.id as district_id',
                'd.name as district_name',
                DB::raw('COUNT(n.id) as notice_count'),
                DB::raw('COALESCE(SUM(n.penalty_amount), 0) as penalty_total'),
                DB::raw('COALESCE(SUM(n.paid_amount), 0) as recovered'),
                DB::raw('COALESCE(SUM(n.penalty_amount - n.paid_amount), 0) as pending'),
                DB::raw('ROUND(COALESCE(SUM(n.paid_amount),0)::numeric / NULLIF(COALESCE(SUM(n.penalty_amount),0), 0) * 100, 1) as recovery_pct')
            )
            ->when($user->districtScope(),    fn($q, $d) => $q->where('n.district_id', $d))
            ->when($source !== 'overall',     fn($q)     => $q->where('n.source_type', $source))
            ->when($request->date_from,       fn($q, $d) => $q->where('n.issued_at', '>=', $d))
            ->when($request->date_to,         fn($q, $d) => $q->where('n.issued_at', '<=', $d))
            ->groupBy('d.id', 'd.name')
            ->orderByDesc('pending')
            ->get();
    }
}
