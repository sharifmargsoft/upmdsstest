<?php
// ─── Dashboard Controller ─────────────────────────────────────────────
namespace App\Http\Controllers\API\v1\Dashboard;

use App\Http\Controllers\Controller;
use App\Services\Dashboard\DashboardService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function __construct(private readonly DashboardService $dashboardService)
    {
    }

    /**
     * GET /api/v1/dashboard
     * Full dashboard data for authenticated user's scope
     */
    public function index(Request $request): JsonResponse
    {
        $user    = $request->user();
        $filters = $request->only(['date_from', 'date_to', 'district_id', 'checkgate_id']);

        // Enforce district scope for non-state users
        if (! $user->isStateLevel()) {
            $filters['district_id'] = $user->district_id;
        }

        $data = $this->dashboardService->getMainDashboard($filters);

        return response()->json(['data' => $data]);
    }

    /**
     * GET /api/v1/dashboard/kpi
     * Lightweight KPI-only endpoint for polling (React auto-refresh)
     */
    public function kpi(Request $request): JsonResponse
    {
        $user       = $request->user();
        $districtId = $user->isStateLevel() ? $request->integer('district_id') : $user->district_id;

        $kpi = $this->dashboardService->getKpis($districtId);

        return response()->json(['data' => $kpi]);
    }
}
