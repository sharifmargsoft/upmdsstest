<?php

namespace App\Http\Controllers\API\v1\Minetag;

use App\Http\Controllers\Controller;
use App\Models\MineTag;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class MinetagController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $perPage = min((int)($request->per_page ?? 25), 100);
        $tags = DB::table('mine_tags as mt')
            ->leftJoin('vehicles as v','mt.vehicle_id','=','v.id')
            ->leftJoin('districts as d','mt.issued_by_district_id','=','d.id')
            ->leftJoin('checkgates as cg','mt.last_seen_checkgate_id','=','cg.id')
            ->select('mt.id','mt.tag_id','mt.vehicle_number','mt.status','mt.issued_on',
                'd.name as district_name','mt.last_seen_at','cg.name as last_seen_checkgate',
                'v.owner_name','v.is_blacklisted')
            ->when($request->search, fn($q,$s) => $q->where(fn($q)=>$q->where('mt.tag_id','ilike',"%$s%")->orWhere('mt.vehicle_number','ilike',"%$s%")))
            ->when($request->status, fn($q,$s) => $q->where('mt.status',$s))
            ->when($request->district_id, fn($q,$d) => $q->where('mt.issued_by_district_id',$d))
            ->orderByDesc('mt.last_seen_at')
            ->paginate($perPage);

        return response()->json([
            'data' => $tags->items(),
            'meta' => ['total'=>$tags->total(),'current_page'=>$tags->currentPage(),'last_page'=>$tags->lastPage(),'per_page'=>$tags->perPage()],
        ]);
    }

    public function show(int $id): JsonResponse
    {
        return response()->json(['data' => MineTag::with(['vehicle','lastSeenCheckgate'])->findOrFail($id)]);
    }

    public function store(Request $request): JsonResponse
    {
        $request->validate([
            'tag_id'         => 'required|string|unique:mine_tags,tag_id',
            'vehicle_number' => 'required|string|min:6',
            'issued_on'      => 'required|date',
            'remarks'        => 'nullable|string|max:500',
        ]);

        $tag = MineTag::create([
            'tag_id'                => $request->tag_id,
            'vehicle_number'        => strtoupper($request->vehicle_number),
            'status'                => 'active',
            'issued_on'             => $request->issued_on,
            'issued_by_district_id' => $request->user()->district_id,
            'remarks'               => $request->remarks,
        ]);

        return response()->json(['data' => $tag, 'message' => 'MINETag registered.'], 201);
    }

    public function update(Request $request, int $id): JsonResponse
    {
        $tag = MineTag::findOrFail($id);
        $request->validate(['status'=>'required|in:active,inactive,damaged,replaced','remarks'=>'nullable|string']);
        $tag->update($request->only(['status','remarks']));
        return response()->json(['data' => $tag, 'message' => 'MINETag updated.']);
    }
}
