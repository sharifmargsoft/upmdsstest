<?php
namespace App\Http\Resources;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
class UserResource extends JsonResource {
    public function toArray(Request $request): array {
        return [
            'id'=>$this->id,'uuid'=>$this->uuid,'name'=>$this->name,'username'=>$this->username,
            'email'=>$this->email,'mobile'=>$this->mobile,'designation'=>$this->designation,
            'employee_id'=>$this->employee_id,'is_active'=>$this->is_active,'is_mcheck_user'=>$this->is_mcheck_user,
            'role'=>$this->whenLoaded('role',fn()=>['id'=>$this->role->id,'name'=>$this->role->name,'display_name'=>$this->role->display_name]),
            'district'=>$this->whenLoaded('district',fn()=>$this->district?['id'=>$this->district->id,'name'=>$this->district->name,'code'=>$this->district->code]:null),
            'last_login_at'=>$this->last_login_at?->toISOString(),'last_login_ip'=>$this->last_login_ip,
            'created_at'=>$this->created_at?->toISOString(),
        ];
    }
}
