<?php
namespace App\Http\Resources;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
class ENoticeResource extends JsonResource {
    public function toArray(Request $request): array {
        return [
            'id'=>$this->id,'uuid'=>$this->uuid,'notice_number'=>$this->notice_number,
            'source_type'=>$this->source_type,'source_id'=>$this->source_id,
            'district'=>$this->whenLoaded('district',fn()=>['id'=>$this->district->id,'name'=>$this->district->name]),
            'issued_by'=>$this->whenLoaded('issuedBy',fn()=>['id'=>$this->issuedBy->id,'name'=>$this->issuedBy->name]),
            'vehicle_number'=>$this->vehicle_number,'vehicle_owner_name'=>$this->vehicle_owner_name,'vehicle_owner_mobile'=>$this->vehicle_owner_mobile,
            'offense_type'=>$this->offense_type,'offense_description'=>$this->offense_description,
            'offense_date'=>$this->offense_date?->format('Y-m-d'),'offense_location'=>$this->offense_location,
            'mineral_name'=>$this->mineral_name,'etp_number'=>$this->etp_number,
            'penalty_amount'=>$this->penalty_amount,'paid_amount'=>$this->paid_amount,
            'pending_amount'=>$this->penalty_amount - $this->paid_amount,
            'status'=>$this->status,'is_overdue'=>$this->isOverdue(),
            'issued_at'=>$this->issued_at?->toISOString(),'due_date'=>$this->due_date?->format('Y-m-d'),
            'paid_at'=>$this->paid_at?->toISOString(),'cancelled_at'=>$this->cancelled_at?->toISOString(),
            'cancellation_reason'=>$this->cancellation_reason,
            'rajkosh_challan_no'=>$this->rajkosh_challan_no,'payment_gateway'=>$this->payment_gateway,
            'evidence_urls'=>$this->evidence_urls??[],'notice_pdf_url'=>$this->notice_pdf_url,
            'parent_notice_id'=>$this->parent_notice_id,
            'audit_logs'=>$this->whenLoaded('auditLogs',fn()=>$this->auditLogs->map(fn($l)=>['action'=>$l->action,'from_status'=>$l->from_status,'to_status'=>$l->to_status,'remarks'=>$l->remarks,'performed_at'=>$l->performed_at?->toISOString()])),
            'created_at'=>$this->created_at?->toISOString(),'updated_at'=>$this->updated_at?->toISOString(),
        ];
    }
}
