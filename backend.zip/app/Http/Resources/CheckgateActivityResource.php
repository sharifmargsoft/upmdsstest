<?php
namespace App\Http\Resources;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
class CheckgateActivityResource extends JsonResource {
    public function toArray(Request $request): array {
        return [
            'id'=>$this->id,'uuid'=>$this->uuid,
            'checkgate'=>$this->whenLoaded('checkgate',fn()=>['id'=>$this->checkgate->id,'name'=>$this->checkgate->name,'code'=>$this->checkgate->code]),
            'district'=>$this->whenLoaded('district',fn()=>['id'=>$this->district->id,'name'=>$this->district->name]),
            'crossing_at'=>$this->crossing_at?->toISOString(),'crossing_direction'=>$this->crossing_direction,'location_name'=>$this->location_name,
            'vehicle_number_anpr'=>$this->vehicle_number_anpr,'vehicle_number_minetag'=>$this->vehicle_number_minetag,
            'vehicle_number_reported'=>$this->vehicle_number_reported,'vehicle_number_final'=>$this->vehicle_number_norm,
            'mine_tag_id'=>$this->mine_tag_id,'minetag_installed'=>$this->minetag_installed,
            'etp_number'=>$this->etp_number,'etp_status'=>$this->etp_status,
            'etp_data'=>$this->when($request->routeIs('*.show'),$this->etp_data),
            'vahan_vehicle_class'=>$this->vahan_vehicle_class,'vahan_gross_weight'=>$this->vahan_gross_weight,
            'vahan_data'=>$this->when($request->routeIs('*.show'),$this->vahan_data),
            'mineral'=>$this->whenLoaded('mineral',fn()=>['id'=>$this->mineral->id,'name'=>$this->mineral->name]),
            'mineral_name'=>$this->mineral_name,'mineral_confidence'=>$this->mineral_confidence,
            'weight_vahan'=>$this->weight_vahan,'weight_etp_declared'=>$this->weight_etp_declared,
            'weight_actual'=>$this->weight_actual,'is_overloaded'=>$this->is_overloaded,'overload_pct'=>$this->overload_pct,
            'flag_type'=>$this->flag_type,'flag_label'=>$this->flag_label,'flag_details'=>$this->flag_details,
            'status'=>$this->status,'status_label'=>$this->status_label,
            'tse_reviewer'=>$this->whenLoaded('tseReviewer',fn()=>['id'=>$this->tseReviewer->id,'name'=>$this->tseReviewer->name,'designation'=>$this->tseReviewer->designation]),
            'tse_reviewed_at'=>$this->tse_reviewed_at?->toISOString(),'tse_remarks'=>$this->tse_remarks,
            'ignored_reason'=>$this->ignored_reason,'ignored_at'=>$this->ignored_at?->toISOString(),
            'anpr_image_url'=>$this->anpr_image_url,'vehicle_image_url'=>$this->vehicle_image_url,'video_url'=>$this->video_url,
            'notice_id'=>$this->notice_id,
            'notice'=>$this->whenLoaded('notice',fn()=>$this->notice?['id'=>$this->notice->id,'notice_number'=>$this->notice->notice_number,'status'=>$this->notice->status,'penalty'=>$this->notice->penalty_amount]:null),
            'can_generate_notice'=>$this->canGenerateNotice(),
            'created_at'=>$this->created_at?->toISOString(),'updated_at'=>$this->updated_at?->toISOString(),
        ];
    }
}
