<?php

namespace App\Console\Commands;

use App\Services\Dashboard\DashboardService;
use Illuminate\Console\Command;

class RefreshMaterializedView extends Command
{
    protected $signature   = 'upmdss:refresh-mv';
    protected $description = 'Refresh PostgreSQL materialized views for dashboard KPIs';

    public function handle(DashboardService $dashboardService): void
    {
        $this->info('Refreshing materialized view...');
        $dashboardService->refreshMaterializedView();
        $this->info('Done. (' . now()->toTimeString() . ')');
    }
}
