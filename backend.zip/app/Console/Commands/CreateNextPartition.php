<?php

namespace App\Console\Commands;

use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class CreateNextPartition extends Command
{
    protected $signature   = 'upmdss:create-partition';
    protected $description = 'Create next month PostgreSQL partition for checkgate_activities';

    public function handle(): void
    {
        $next   = Carbon::now()->addMonth()->startOfMonth();
        $start  = $next->format('Y-m-d');
        $end    = $next->copy()->addMonth()->format('Y-m-d');
        $suffix = $next->format('Y_m');
        $table  = "checkgate_activities_{$suffix}";

        try {
            DB::statement("
                CREATE TABLE IF NOT EXISTS {$table}
                PARTITION OF checkgate_activities
                FOR VALUES FROM ('{$start}') TO ('{$end}')
            ");
            $this->info("Created partition: {$table} ({$start} to {$end})");
        } catch (\Exception $e) {
            $this->error("Failed: " . $e->getMessage());
        }
    }
}
