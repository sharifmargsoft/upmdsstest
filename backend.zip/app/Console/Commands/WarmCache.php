<?php

namespace App\Console\Commands;

use App\Models\District;
use App\Services\Dashboard\DashboardService;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Cache;

class WarmCache extends Command
{
    protected $signature   = 'upmdss:warm-cache';
    protected $description = 'Pre-warm Redis cache for dashboard KPIs and master data';

    public function handle(DashboardService $dashboardService): void
    {
        $this->info('Warming Redis cache...');

        // State-level KPI
        $dashboardService->getKpis(null);
        $this->line('  ✓ State-level KPI cached');

        // Per-district KPI
        $districts = District::where('is_active', true)->get();
        foreach ($districts as $district) {
            $dashboardService->getKpis($district->id);
        }
        $this->line("  ✓ {$districts->count()} district KPIs cached");

        // Master data
        Cache::remember('master_districts', 3600, fn () =>
            District::where('is_active', true)->orderBy('name')->get(['id', 'name', 'code', 'state'])
        );
        $this->line('  ✓ Master district data cached');

        $this->info('Cache warming complete.');
    }
}
