<?php
// ─────────────────────────────────────────────────────────────────────────────
// FILE: app/Providers/AppServiceProvider.php
// ─────────────────────────────────────────────────────────────────────────────
namespace App\Providers;

use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        // Bind services (optional — can also use constructor injection)
        $this->app->bind(
            \App\Services\External\VahanApiService::class,
            \App\Services\External\VahanApiService::class,
        );
        $this->app->bind(
            \App\Services\External\UpMinesApiService::class,
            \App\Services\External\UpMinesApiService::class,
        );
    }

    public function boot(): void
    {
        $this->configureRateLimiting();
        $this->configureMacros();
    }

    private function configureRateLimiting(): void
    {
        // General authenticated API: 120 requests per minute per user
        RateLimiter::for('authenticated_api', function (Request $request) {
            return Limit::perMinute(120)->by(
                optional($request->user())->id ?: $request->ip()
            );
        });

        // Public/guest API: 20 requests per minute per IP
        RateLimiter::for('public_api', function (Request $request) {
            return Limit::perMinute(20)->by($request->ip());
        });

        // Login endpoint: 10 attempts per minute per IP (brute force protection)
        RateLimiter::for('login', function (Request $request) {
            return Limit::perMinute(10)->by($request->ip());
        });
    }

    private function configureMacros(): void
    {
        // Helper on Request to get float values safely
        Request::macro('float', function (string $key, float $default = 0.0): float {
            return (float) $this->input($key, $default);
        });
    }
}
