<?php

namespace App\Jobs;

use App\Models\ENotice;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Storage;

class GenerateNoticePdfJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries   = 3;
    public int $timeout = 120;

    public function __construct(public readonly int $noticeId)
    {
        $this->onQueue('pdf');
    }

    public function handle(): void
    {
        $notice = ENotice::with(['district', 'issuedBy', 'template'])->findOrFail($this->noticeId);

        // Generate PDF using DomPDF
        $pdf = Pdf::loadView('pdf.notice', ['notice' => $notice])
            ->setPaper('A4', 'portrait');

        $filename = "notices/pdf/{$notice->uuid}.pdf";

        // Store to configured disk (local for dev, S3 for production)
        Storage::put($filename, $pdf->output());

        $pdfUrl = Storage::url($filename);

        $notice->update([
            'notice_pdf_url' => $pdfUrl,
            'portal_sent_at' => now(),
        ]);
    }

    public function failed(\Throwable $exception): void
    {
        \Illuminate\Support\Facades\Log::error("PDF generation failed for notice {$this->noticeId}: " . $exception->getMessage());
    }
}
