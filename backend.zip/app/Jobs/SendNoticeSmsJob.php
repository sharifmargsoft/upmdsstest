<?php

namespace App\Jobs;

use App\Models\ENotice;
use App\Services\External\SmsService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class SendNoticeSmsJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries   = 5;
    public int $timeout = 30;

    public function __construct(
        public readonly int    $noticeId,
        public readonly string $mobile,
    ) {
        $this->onQueue('sms');
    }

    public function handle(SmsService $smsService): void
    {
        $notice = ENotice::find($this->noticeId);
        if (! $notice) {
            return;
        }

        $message = "UPMDSS NOTICE: e-Notice {$notice->notice_number} issued against vehicle "
            . "{$notice->vehicle_number}. Offense: {$notice->offense_type}. "
            . "Penalty: Rs." . number_format($notice->penalty_amount, 0) . ". "
            . "Pay at upmdss.in by {$notice->due_date}. "
            . "For queries contact your District Mining Office.";

        $sent = $smsService->send($this->mobile, $message);

        if ($sent) {
            $notice->update(['sms_sent_at' => now()]);
        }
    }

    public function failed(\Throwable $exception): void
    {
        \Illuminate\Support\Facades\Log::error(
            "SMS failed for notice {$this->noticeId} to {$this->mobile}: " . $exception->getMessage()
        );
    }
}
