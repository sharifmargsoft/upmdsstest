<?php

namespace App\Services\External;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

/**
 * VAHAN API Service
 * Fetches vehicle registration data from Parivahan/VAHAN national database.
 * Results cached per vehicle number for 24 hours.
 */
class VahanApiService
{
    private const CACHE_TTL = 86400; // 24 hours

    public function fetchCached(string $vehicleNumberNorm): array
    {
        $cacheKey = "vahan_{$vehicleNumberNorm}";

        return Cache::remember($cacheKey, self::CACHE_TTL, function () use ($vehicleNumberNorm) {
            return $this->fetch($vehicleNumberNorm);
        });
    }

    public function fetch(string $vehicleNumberNorm): array
    {
        // ── Stub mode for local development (no real API key) ─────────────
        if (app()->environment('local', 'testing') || empty(config('services.vahan.key'))) {
            return $this->mockVahanResponse($vehicleNumberNorm);
        }

        // ── Real VAHAN API call ───────────────────────────────────────────
        try {
            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . config('services.vahan.key'),
                'Accept'        => 'application/json',
            ])
            ->timeout(10)
            ->retry(2, 500)
            ->get(config('services.vahan.url') . '/vehicle-details', [
                'regNo'  => $vehicleNumberNorm,
                'state'  => 'UP',
            ]);

            if ($response->successful()) {
                $data = $response->json();
                return [
                    'success'        => true,
                    'vehicle_number' => $vehicleNumberNorm,
                    'owner_name'     => $data['ownerName']     ?? null,
                    'mobile'         => $data['mobile']        ?? null,
                    'vehicle_class'  => $data['vehicleClass']  ?? null,
                    'fuel_type'      => $data['fuelType']       ?? null,
                    'gross_weight'   => $data['grossWeight']   ?? null,
                    'registered_at'  => $data['regDate']       ?? null,
                    'registered_rto' => $data['rto']           ?? null,
                    'registered_state'=> $data['regState']     ?? null,
                    'fitness_upto'   => $data['fitnessUpto']   ?? null,
                    'insurance_upto' => $data['insuranceUpto'] ?? null,
                    'raw'            => $data,
                ];
            }

            Log::warning("VAHAN API failed for {$vehicleNumberNorm}", [
                'status' => $response->status(),
                'body'   => $response->body(),
            ]);

            return ['success' => false, 'vehicle_number' => $vehicleNumberNorm, 'error' => 'API_FAILED'];

        } catch (\Exception $e) {
            Log::error("VAHAN API exception for {$vehicleNumberNorm}: " . $e->getMessage());
            return ['success' => false, 'vehicle_number' => $vehicleNumberNorm, 'error' => $e->getMessage()];
        }
    }

    /** Mock data for development/testing */
    private function mockVahanResponse(string $vehicleNumber): array
    {
        $owners = ['Ram Prasad Yadav', 'Shyam Lal Gupta', 'Mahesh Kumar Singh', 'Rajesh Verma', 'Amit Tiwari'];
        $classes = ['LCV', 'HCV', 'MGV', 'HGV'];

        return [
            'success'         => true,
            'vehicle_number'  => $vehicleNumber,
            'owner_name'      => $owners[array_rand($owners)],
            'mobile'          => '9' . rand(100000000, 999999999),
            'vehicle_class'   => $classes[array_rand($classes)],
            'fuel_type'       => 'Diesel',
            'gross_weight'    => rand(10000, 49000),
            'registered_at'   => '2019-06-15',
            'registered_rto'  => 'UP32',
            'registered_state'=> 'Uttar Pradesh',
            'fitness_upto'    => '2027-06-14',
            'insurance_upto'  => '2025-11-30',
            'raw'             => [],
        ];
    }
}

/**
 * UP Mines API Service
 * Verifies eTP (eMM11 / Form-C / iSTP) against UP Mines portal.
 */
class UpMinesApiService
{
    private const CACHE_TTL = 1800; // 30 min — ETP status can change

    public function verifyEtp(string $etpNumber, ?string $vehicleNumber = null): array
    {
        $cacheKey = "etp_{$etpNumber}" . ($vehicleNumber ? "_{$vehicleNumber}" : '');

        return Cache::remember($cacheKey, self::CACHE_TTL, function () use ($etpNumber, $vehicleNumber) {
            return $this->fetchEtp($etpNumber, $vehicleNumber);
        });
    }

    private function fetchEtp(string $etpNumber, ?string $vehicleNumber): array
    {
        if (app()->environment('local', 'testing') || empty(config('services.up_mines.key'))) {
            return $this->mockEtpResponse($etpNumber, $vehicleNumber);
        }

        try {
            $response = Http::withHeaders([
                'x-api-key' => config('services.up_mines.key'),
                'Accept'    => 'application/json',
            ])
            ->timeout(10)
            ->retry(2, 500)
            ->post(config('services.up_mines.url') . '/etp/verify', [
                'etp_number'     => $etpNumber,
                'vehicle_number' => $vehicleNumber,
            ]);

            if ($response->successful()) {
                $data = $response->json();
                return [
                    'success'          => true,
                    'etp_number'       => $etpNumber,
                    'etp_status'       => $data['status']           ?? 'unknown',
                    'etp_type'         => $data['type']             ?? null,  // eMM11|FormC|iSTP
                    'vehicle_number'   => $data['vehicleNo']        ?? null,
                    'lessee_name'      => $data['lesseeName']       ?? null,
                    'mineral_name'     => $data['mineralName']      ?? null,
                    'quantity_mt'      => $data['quantityMT']       ?? null,
                    'source_district'  => $data['sourceDistrict']   ?? null,
                    'dest_district'    => $data['destDistrict']     ?? null,
                    'valid_from'       => $data['validFrom']        ?? null,
                    'valid_upto'       => $data['validUpto']        ?? null,
                    'issued_at'        => $data['issuedAt']         ?? null,
                    'trips_allowed'    => $data['tripsAllowed']     ?? 1,
                    'trips_used'       => $data['tripsUsed']        ?? 0,
                    'raw'              => $data,
                ];
            }

            return ['success' => false, 'etp_number' => $etpNumber, 'error' => 'ETP_NOT_FOUND'];

        } catch (\Exception $e) {
            Log::error("UP Mines API exception for ETP {$etpNumber}: " . $e->getMessage());
            return ['success' => false, 'etp_number' => $etpNumber, 'error' => $e->getMessage()];
        }
    }

    private function mockEtpResponse(string $etpNumber, ?string $vehicleNumber): array
    {
        $minerals = ['Sand', 'Gravel', 'Granite', 'Limestone', 'Moorum'];
        $statuses = ['valid', 'valid', 'valid', 'expired', 'bogus']; // weighted toward valid

        return [
            'success'         => true,
            'etp_number'      => $etpNumber,
            'etp_status'      => $statuses[array_rand($statuses)],
            'etp_type'        => 'eMM11',
            'vehicle_number'  => $vehicleNumber ?? 'UP32XX1234',
            'lessee_name'     => 'Ramesh Stone Quarry Pvt Ltd',
            'mineral_name'    => $minerals[array_rand($minerals)],
            'quantity_mt'     => rand(10, 35),
            'source_district' => 'Mirzapur',
            'dest_district'   => 'Lucknow',
            'valid_from'      => now()->subHours(2)->toDateTimeString(),
            'valid_upto'      => now()->addHours(22)->toDateTimeString(),
            'issued_at'       => now()->subHours(3)->toDateTimeString(),
            'trips_allowed'   => 1,
            'trips_used'      => 0,
            'raw'             => [],
        ];
    }
}

/**
 * SMS Service (MSG91 Gateway)
 */
class SmsService
{
    public function send(string $mobile, string $message, ?string $templateId = null): bool
    {
        if (app()->environment('local', 'testing')) {
            Log::info("SMS [MOCK] to {$mobile}: {$message}");
            return true;
        }

        try {
            $response = Http::withHeaders([
                'authkey'      => config('services.msg91.auth_key'),
                'Content-Type' => 'application/json',
            ])
            ->post('https://api.msg91.com/api/v5/flow/', [
                'template_id' => $templateId ?? config('services.msg91.template_id'),
                'sender'      => config('services.msg91.sender_id'),
                'short_url'   => '0',
                'mobiles'     => '91' . ltrim($mobile, '0'),
                'VAR1'        => $message,
            ]);

            return $response->successful();
        } catch (\Exception $e) {
            Log::error("SMS send failed to {$mobile}: " . $e->getMessage());
            return false;
        }
    }
}
