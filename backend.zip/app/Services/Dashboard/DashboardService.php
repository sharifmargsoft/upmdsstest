<?php

namespace App\Services\Dashboard;

use App\Models\CheckgateActivity;
use App\Models\ENotice;
use App\Models\McheckActivity;
use App\Models\Vehicle;
use App\Models\VehicleBlacklist;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;

class DashboardService
{
    private const CACHE_TTL = 300; // 5 minutes

    /**
     * Main dashboard aggregated data.
     * Uses materialized view for speed; falls back to live query.
     */
    public function getMainDashboard(array $filters): array
    {
        $cacheKey = 'dashboard_main_' . md5(serialize($filters));

        return Cache::remember($cacheKey, self::CACHE_TTL, function () use ($filters) {
            return [
                'kpi'            => $this->getKpis($filters['district_id'] ?? null),
                'today'          => $this->getTodayStats($filters),
                'offense_chart'  => $this->getOffenseDistribution($filters),
                'trend_chart'    => $this->getVehicleTrend($filters),
                'top_violators'  => $this->getTopViolatorCheckgates($filters),
                'recovery_stats' => $this->getRecoveryStats($filters),
            ];
        });
    }

    /**
     * Fast KPI cards — pulled from materialized view if available.
     */
    public function getKpis(?int $districtId): array
    {
        $cacheKey = "kpi_{$districtId}";

        return Cache::remember($cacheKey, self::CACHE_TTL, function () use ($districtId) {
            // Try materialized view first
            try {
                $query = DB::table('mv_dashboard_summary');
                if ($districtId) {
                    $query->where('district_id', $districtId);
                }
                $mv = $query->first();

                if ($mv) {
                    return [
                        'total_vehicles_today'   => $this->getTodayVehicleCount($districtId),
                        'total_checkgates'        => DB::table('checkgates')->where('status','active')->count(),
                        'total_mineral_vehicles'  => DB::table('checkgate_activities')
                            ->when($districtId, fn($q) => $q->where('district_id', $districtId))
                            ->where('minetag_installed', true)
                            ->whereDate('crossing_at', today())
                            ->count(),
                        'notices_total'           => $mv->notices_total ?? 0,
                        'notices_paid'            => $mv->notices_paid ?? 0,
                        'penalty_total'           => round($mv->penalty_total ?? 0, 2),
                        'penalty_recovered'       => round($mv->penalty_recovered ?? 0, 2),
                        'penalty_pending'         => round($mv->penalty_pending ?? 0, 2),
                        'blacklisted_vehicles'    => $mv->blacklisted_vehicles ?? 0,
                        'violations_30d'          => $mv->violations_30d ?? 0,
                        'mv_refreshed_at'         => $mv->refreshed_at ?? null,
                    ];
                }
            } catch (\Exception $e) {
                // Fall back to live aggregation
            }

            return $this->getLiveKpis($districtId);
        });
    }

    private function getTodayVehicleCount(?int $districtId): int
    {
        return CheckgateActivity::query()
            ->when($districtId, fn($q) => $q->where('district_id', $districtId))
            ->whereDate('crossing_at', today())
            ->count();
    }

    private function getLiveKpis(?int $districtId): array
    {
        $noticeQuery = ENotice::query()
            ->when($districtId, fn($q) => $q->where('district_id', $districtId));

        return [
            'total_vehicles_today'  => $this->getTodayVehicleCount($districtId),
            'total_checkgates'      => DB::table('checkgates')->where('status','active')->count(),
            'notices_total'         => (clone $noticeQuery)->count(),
            'notices_paid'          => (clone $noticeQuery)->paid()->count(),
            'penalty_total'         => (clone $noticeQuery)->sum('penalty_amount'),
            'penalty_recovered'     => (clone $noticeQuery)->sum('paid_amount'),
            'penalty_pending'       => (clone $noticeQuery)->pending()->sum('pending_amount'),
            'blacklisted_vehicles'  => VehicleBlacklist::query()
                ->when($districtId, fn($q) => $q->where('district_id', $districtId))
                ->where('status', 'active')
                ->count(),
            'violations_30d'        => CheckgateActivity::query()
                ->when($districtId, fn($q) => $q->where('district_id', $districtId))
                ->violations()
                ->where('crossing_at', '>=', now()->subDays(30))
                ->count(),
        ];
    }

    private function getTodayStats(array $filters): array
    {
        $districtId = $filters['district_id'] ?? null;

        return [
            'vehicle_count'     => $this->getTodayVehicleCount($districtId),
            'violations'        => CheckgateActivity::query()
                ->when($districtId, fn($q) => $q->where('district_id', $districtId))
                ->violations()
                ->whereDate('crossing_at', today())
                ->count(),
            'notices_issued'    => ENotice::query()
                ->when($districtId, fn($q) => $q->where('district_id', $districtId))
                ->whereDate('issued_at', today())
                ->count(),
            'mcheck_inspections'=> McheckActivity::query()
                ->when($districtId, fn($q) => $q->where('district_id', $districtId))
                ->whereDate('inspected_at', today())
                ->count(),
        ];
    }

    private function getOffenseDistribution(array $filters): array
    {
        return CheckgateActivity::query()
            ->select('flag_type', DB::raw('COUNT(*) as count'))
            ->when($filters['district_id'] ?? null, fn($q, $d) => $q->where('district_id', $d))
            ->when($filters['date_from'] ?? null, fn($q, $d) => $q->where('crossing_at', '>=', $d))
            ->when($filters['date_to'] ?? null, fn($q, $d) => $q->where('crossing_at', '<=', $d))
            ->where('flag_type', '!=', 'valid')
            ->groupBy('flag_type')
            ->orderByDesc('count')
            ->get()
            ->map(fn($row) => [
                'type'  => $row->flag_type,
                'label' => str_replace('_', ' ', ucfirst($row->flag_type)),
                'count' => (int) $row->count,
            ])
            ->toArray();
    }

    private function getVehicleTrend(array $filters): array
    {
        // Last 30 days trend
        return DB::select("
            SELECT
                DATE(crossing_at)::TEXT AS date,
                COUNT(*) AS total,
                COUNT(*) FILTER (WHERE flag_type != 'valid') AS violations
            FROM checkgate_activities
            WHERE crossing_at >= NOW() - INTERVAL '30 days'
            " . ($filters['district_id'] ?? null ? "AND district_id = " . (int)$filters['district_id'] : "") . "
            GROUP BY DATE(crossing_at)
            ORDER BY date
        ");
    }

    private function getTopViolatorCheckgates(array $filters): array
    {
        return DB::table('checkgate_activities as ca')
            ->join('checkgates as cg', 'ca.checkgate_id', '=', 'cg.id')
            ->select('cg.id', 'cg.name', 'cg.code', DB::raw('COUNT(*) as violations'))
            ->where('ca.flag_type', '!=', 'valid')
            ->when($filters['district_id'] ?? null, fn($q, $d) => $q->where('ca.district_id', $d))
            ->when($filters['date_from'] ?? null, fn($q, $d) => $q->where('ca.crossing_at', '>=', $d))
            ->groupBy('cg.id', 'cg.name', 'cg.code')
            ->orderByDesc('violations')
            ->limit(10)
            ->get()
            ->toArray();
    }

    private function getRecoveryStats(array $filters): array
    {
        return DB::table('e_notices')
            ->select(
                DB::raw("DATE_TRUNC('month', issued_at)::TEXT AS month"),
                DB::raw('SUM(penalty_amount) AS penalty'),
                DB::raw('SUM(paid_amount) AS recovered'),
                DB::raw('SUM(pending_amount) AS pending')
            )
            ->when($filters['district_id'] ?? null, fn($q, $d) => $q->where('district_id', $d))
            ->where('issued_at', '>=', now()->subMonths(12))
            ->groupBy(DB::raw("DATE_TRUNC('month', issued_at)"))
            ->orderBy(DB::raw("DATE_TRUNC('month', issued_at)"))
            ->get()
            ->toArray();
    }

    /**
     * Refresh materialized view — called by scheduled command every 5 minutes.
     */
    public function refreshMaterializedView(): void
    {
        DB::statement('REFRESH MATERIALIZED VIEW CONCURRENTLY mv_dashboard_summary');
        Cache::tags(['dashboard'])->flush();
    }
}
