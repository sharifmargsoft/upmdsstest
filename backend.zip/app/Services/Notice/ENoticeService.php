<?php

namespace App\Services\Notice;

use App\Models\District;
use App\Models\ENotice;
use App\Models\NoticeAuditLog;
use App\Models\NoticeTemplate;
use App\Models\User;
use App\Models\Vehicle;
use App\Services\External\VahanApiService;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class ENoticeService
{
    public function __construct(
        private readonly PdfGeneratorService $pdfService,
        private readonly SmsService          $smsService,
        private readonly VahanApiService     $vahanApi,
    ) {
    }

    /**
     * Create a new e-Notice from any source (checkgate / mcheck / weighbridge).
     */
    public function create(
        string $sourceType,
        int    $sourceId,
        int    $districtId,
        string $vehicleNumber,
        string $offenseType,
        string $offenseDate,
        string $offenseLocation,
        ?string $mineralName,
        ?string $etpNumber,
        int    $templateId,
        float  $penaltyAmount,
        int    $dueDays,
        User   $issuedBy,
        array  $evidenceUrls = [],
    ): ENotice {
        $normalized   = strtoupper(preg_replace('/\s+/', '', $vehicleNumber));
        $district     = District::findOrFail($districtId);
        $noticeNumber = ENotice::generateNoticeNumber($district->code, $sourceType);

        // Fetch owner info from Vahan if not cached
        $vahanData    = $this->vahanApi->fetchCached($normalized);
        $ownerName    = $vahanData['owner_name'] ?? null;
        $ownerMobile  = $vahanData['mobile']     ?? null;

        $notice = ENotice::create([
            'notice_number'       => $noticeNumber,
            'notice_template_id'  => $templateId,
            'source_type'         => $sourceType,
            'source_id'           => $sourceId,
            'district_id'         => $districtId,
            'issued_by'           => $issuedBy->id,
            'vehicle_number'      => $vehicleNumber,
            'vehicle_number_norm' => $normalized,
            'vehicle_owner_name'  => $ownerName,
            'vehicle_owner_mobile'=> $ownerMobile,
            'offense_type'        => $offenseType,
            'offense_description' => $this->buildOffenseDescription($offenseType, $etpNumber),
            'offense_date'        => $offenseDate,
            'offense_location'    => $offenseLocation,
            'mineral_name'        => $mineralName,
            'etp_number'          => $etpNumber,
            'penalty_amount'      => $penaltyAmount,
            'paid_amount'         => 0,
            'status'              => 'issued',
            'issued_at'           => now(),
            'due_date'            => now()->addDays($dueDays)->toDateString(),
            'evidence_urls'       => $evidenceUrls,
        ]);

        // Generate PDF asynchronously (dispatch job)
        dispatch(new \App\Jobs\GenerateNoticePdfJob($notice->id));

        // Send SMS to owner
        if ($ownerMobile) {
            dispatch(new \App\Jobs\SendNoticeSmsJob($notice->id, $ownerMobile));
        }

        // Audit log
        $this->audit($notice->id, 'issued', null, 'issued', "Notice issued by {$issuedBy->name}", $issuedBy->id);

        return $notice;
    }

    public function cancel(ENotice $notice, string $reason, User $cancelledBy): ENotice
    {
        if (in_array($notice->status, ['paid', 'cancelled'])) {
            throw new \DomainException("Cannot cancel a {$notice->status} notice.");
        }

        $oldStatus = $notice->status;

        $notice->update([
            'status'              => 'cancelled',
            'cancelled_at'        => now(),
            'cancellation_reason' => $reason,
            'cancelled_by'        => $cancelledBy->id,
        ]);

        $this->audit($notice->id, 'cancelled', $oldStatus, 'cancelled', $reason, $cancelledBy->id);

        return $notice->fresh();
    }

    public function reactivate(ENotice $notice, string $remarks, User $reactivatedBy): ENotice
    {
        if ($notice->status !== 'cancelled') {
            throw new \DomainException("Only cancelled notices can be reactivated.");
        }

        $notice->update([
            'status'           => 'issued',
            'reactivated_at'   => now(),
            'reactivated_by'   => $reactivatedBy->id,
            'cancelled_at'     => null,
            'cancellation_reason' => null,
        ]);

        $this->audit($notice->id, 'reactivated', 'cancelled', 'issued', $remarks, $reactivatedBy->id);

        return $notice->fresh();
    }

    public function recordPayment(ENotice $notice, float $amount, string $challanNo, string $gateway, array $gatewayResponse): ENotice
    {
        if ($notice->isPaid()) {
            throw new \DomainException("Notice is already fully paid.");
        }

        $newPaid = $notice->paid_amount + $amount;
        $status  = $newPaid >= $notice->penalty_amount ? 'paid' : 'partially_paid';

        $notice->update([
            'paid_amount'               => $newPaid,
            'status'                    => $status,
            'paid_at'                   => $status === 'paid' ? now() : null,
            'rajkosh_challan_no'        => $challanNo,
            'payment_gateway'           => $gateway,
            'payment_reference'         => $challanNo,
            'payment_gateway_response'  => $gatewayResponse,
        ]);

        $this->audit($notice->id, 'paid', null, $status, "Payment of ₹{$amount} recorded via {$gateway}", null, [
            'amount'     => $amount,
            'challan_no' => $challanNo,
        ]);

        return $notice->fresh();
    }

    private function buildOffenseDescription(string $offenseType, ?string $etpNumber): string
    {
        $descriptions = [
            'expired_etp'     => "Transportation of mineral with expired e-Transit Pass (eTP)" . ($etpNumber ? " No. {$etpNumber}" : ""),
            'without_etp'     => "Transportation of mineral without valid e-Transit Pass (eTP)",
            'bogus_etp'       => "Transportation with bogus/forged e-Transit Pass" . ($etpNumber ? " No. {$etpNumber}" : ""),
            'duplicate_etp'   => "Reuse of e-Transit Pass for multiple trips" . ($etpNumber ? " No. {$etpNumber}" : ""),
            'mismatch'        => "Vehicle number mismatch between ANPR reading and eTP/MINETag",
            'overload'        => "Vehicle found overloaded beyond permitted Gross Vehicle Weight (GVW)",
            'no_minetag'      => "Mineral transport vehicle found operating without mandatory MINETag RFID",
            'obscured_plate'  => "Vehicle found with deliberately obscured/smudged number plate",
            'bypass'          => "Vehicle found bypassing authorized checkgate route",
            'volume_mismatch' => "Volume/weight mismatch between eTP declaration and actual weighment",
        ];

        return $descriptions[$offenseType] ?? "Violation detected: " . str_replace('_', ' ', $offenseType);
    }

    private function audit(int $noticeId, string $action, ?string $fromStatus, string $toStatus, string $remarks, ?int $userId, array $metadata = []): void
    {
        NoticeAuditLog::create([
            'notice_id'    => $noticeId,
            'action'       => $action,
            'from_status'  => $fromStatus,
            'to_status'    => $toStatus,
            'remarks'      => $remarks,
            'performed_by' => $userId,
            'performed_at' => now(),
            'metadata'     => $metadata,
        ]);
    }
}
