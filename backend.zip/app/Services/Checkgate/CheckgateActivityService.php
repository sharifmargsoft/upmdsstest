<?php

namespace App\Services\Checkgate;

use App\Models\CheckgateActivity;
use App\Models\ENotice;
use App\Models\User;
use App\Services\External\VahanApiService;
use App\Services\External\UpMinesApiService;
use App\Services\Notice\ENoticeService;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\DB;

class CheckgateActivityService
{
    public function __construct(
        private readonly VahanApiService    $vahanApi,
        private readonly UpMinesApiService  $upMinesApi,
        private readonly ENoticeService     $noticeService,
    ) {
    }

    public function list(array $filters): LengthAwarePaginator
    {
        $perPage = min((int) ($filters['per_page'] ?? 25), 100);

        return CheckgateActivity::query()
            ->with(['checkgate:id,name,code', 'district:id,name', 'mineral:id,name', 'tseReviewer:id,name'])
            ->forDistrict($filters['_district_scope'] ?? null)
            ->when($filters['district_id'] ?? null, fn($q, $d) => $q->where('district_id', $d))
            ->when($filters['checkgate_id'] ?? null, fn($q, $c) => $q->forCheckgate($c))
            ->when($filters['status'] ?? null, fn($q, $s) => $q->where('status', $s))
            ->when($filters['flag_type'] ?? null, fn($q, $f) => $q->byFlagType($f))
            ->when($filters['vehicle_number'] ?? null, fn($q, $v) => $q->byVehicle($v))
            ->when($filters['mineral_id'] ?? null, fn($q, $m) => $q->where('mineral_id', $m))
            ->when(
                isset($filters['date_from'], $filters['date_to']),
                fn($q) => $q->dateRange($filters['date_from'], $filters['date_to'])
            )
            ->orderByDesc('crossing_at')
            ->paginate($perPage);
    }

    public function findOrFail(int $id, ?int $districtScope): CheckgateActivity
    {
        $query = CheckgateActivity::with([
            'checkgate', 'district', 'mineral',
            'tseReviewer:id,name,designation',
            'ignoredBy:id,name',
            'notice',
        ]);

        if ($districtScope) {
            $query->where('district_id', $districtScope);
        }

        return $query->findOrFail($id);
    }

    public function getStats(array $filters): array
    {
        $query = CheckgateActivity::query()
            ->forDistrict($filters['_district_scope'] ?? null)
            ->when($filters['district_id'] ?? null, fn($q, $d) => $q->where('district_id', $d))
            ->when($filters['checkgate_id'] ?? null, fn($q, $c) => $q->forCheckgate($c))
            ->when(
                isset($filters['date_from'], $filters['date_to']),
                fn($q) => $q->dateRange($filters['date_from'], $filters['date_to'])
            );

        return [
            'total'          => (clone $query)->count(),
            'violations'     => (clone $query)->violations()->count(),
            'pending_notice' => (clone $query)->pendingNotice()->count(),
            'notice_sent'    => (clone $query)->noticeSent()->count(),
            'ignored'        => (clone $query)->ignored()->count(),
        ];
    }

    public function review(int $id, string $status, string $remarks, User $reviewer): CheckgateActivity
    {
        $activity = CheckgateActivity::findOrFail($id);

        if (! in_array($activity->status, ['reported', 'under_review'])) {
            throw new \DomainException("Cannot review case in '{$activity->status}' status.");
        }

        $activity->update([
            'status'          => $status,
            'tse_reviewed_by' => $reviewer->id,
            'tse_reviewed_at' => now(),
            'tse_remarks'     => $remarks,
        ]);

        return $activity->fresh(['tseReviewer']);
    }

    /**
     * Correct vehicle number (ANPR misread) and re-fetch APIs.
     */
    public function correctVehicleNumber(int $id, string $vehicleNumber, string $remarks, User $reviewer): CheckgateActivity
    {
        $activity = CheckgateActivity::findOrFail($id);

        $normalized = strtoupper(preg_replace('/\s+/', '', $vehicleNumber));

        DB::transaction(function () use ($activity, $vehicleNumber, $normalized, $remarks, $reviewer) {
            // Re-fetch external APIs with corrected vehicle number
            $vahanData   = $this->vahanApi->fetch($normalized);
            $etpData     = $activity->etp_number
                ? $this->upMinesApi->verifyEtp($activity->etp_number, $normalized)
                : [];

            $activity->update([
                'vehicle_number_reported' => $vehicleNumber,
                'vehicle_number_norm'     => $normalized,
                'vahan_data'              => $vahanData,
                'etp_data'                => $etpData ?: $activity->etp_data,
                'tse_reviewed_by'         => $reviewer->id,
                'tse_reviewed_at'         => now(),
                'tse_remarks'             => "Vehicle corrected to {$vehicleNumber}. {$remarks}",
                'status'                  => 'under_review',
            ]);
        });

        return $activity->fresh();
    }

    public function ignore(int $id, string $reason, User $user): CheckgateActivity
    {
        $activity = CheckgateActivity::findOrFail($id);

        $activity->update([
            'status'         => 'ignored',
            'ignored_reason' => $reason,
            'ignored_by'     => $user->id,
            'ignored_at'     => now(),
        ]);

        return $activity->fresh();
    }

    public function generateNotice(
        int $activityId,
        int $templateId,
        float $penaltyAmount,
        int $dueDays,
        User $issuedBy,
    ): ENotice {
        $activity = CheckgateActivity::findOrFail($activityId);

        if (! $activity->canGenerateNotice()) {
            throw new \DomainException("Cannot generate notice for this case.");
        }

        return DB::transaction(function () use ($activity, $templateId, $penaltyAmount, $dueDays, $issuedBy) {
            $notice = $this->noticeService->create(
                sourceType:     'checkgate',
                sourceId:       $activity->id,
                districtId:     $activity->district_id,
                vehicleNumber:  $activity->vehicle_number_norm,
                offenseType:    $activity->flag_type,
                offenseDate:    $activity->crossing_at->toDateString(),
                offenseLocation:$activity->checkgate?->name . ', ' . $activity->location_name,
                mineralName:    $activity->mineral_name,
                etpNumber:      $activity->etp_number,
                templateId:     $templateId,
                penaltyAmount:  $penaltyAmount,
                dueDays:        $dueDays,
                issuedBy:       $issuedBy,
                evidenceUrls:   array_filter([
                    $activity->anpr_image_url,
                    $activity->vehicle_image_url,
                    $activity->video_url,
                ]),
            );

            // Update activity status
            $activity->update([
                'status'    => 'notice_sent',
                'notice_id' => $notice->id,
            ]);

            return $notice;
        });
    }
}
