<?php

namespace App\Services\Auth;

use App\Models\LoginLog;
use App\Models\User;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class AuthService
{
    private const TOKEN_EXPIRY_HOURS = 8;
    private const MAX_FAILED_ATTEMPTS = 5;
    private const LOCKOUT_MINUTES = 30;

    public function login(string $username, string $password, string $ip, ?string $userAgent): array
    {
        // Brute force protection
        $lockKey = "login_lock_{$username}_{$ip}";
        if (Cache::has($lockKey)) {
            $this->logAttempt(null, $username, $ip, $userAgent, 'blocked', 'Account locked due to repeated failures');
            return ['success' => false, 'message' => 'Account temporarily locked. Try again in ' . self::LOCKOUT_MINUTES . ' minutes.'];
        }

        $user = User::where('username', $username)
                    ->orWhere('email', $username)
                    ->first();

        if (! $user || ! Hash::check($password, $user->password)) {
            $this->incrementFailedAttempts($username, $ip, $lockKey);
            $this->logAttempt(null, $username, $ip, $userAgent, 'failed', 'Invalid credentials');
            return ['success' => false, 'message' => 'Invalid username or password.'];
        }

        if (! $user->is_active) {
            $this->logAttempt($user->id, $username, $ip, $userAgent, 'failed', 'Account inactive');
            return ['success' => false, 'message' => 'Your account has been deactivated. Contact administrator.'];
        }

        // Clear failed attempts on successful login
        Cache::forget("login_attempts_{$username}_{$ip}");
        Cache::forget($lockKey);

        // Create token
        $expiresAt = now()->addHours(self::TOKEN_EXPIRY_HOURS);
        $token = $user->createToken(
            name: "session_{$ip}",
            expiresAt: $expiresAt
        )->plainTextToken;

        // Update last login
        $user->recordLogin($ip);

        // Log successful login
        LoginLog::create([
            'user_id'       => $user->id,
            'username_attempt' => $username,
            'ip_address'    => $ip,
            'user_agent'    => $userAgent,
            'status'        => 'success',
            'logged_in_at'  => now(),
        ]);

        // Cache permissions
        $permissions = Cache::remember(
            "user_permissions_{$user->id}",
            900,
            fn() => $user->getAllPermissions()->pluck('name')->toArray()
        );

        return [
            'success'    => true,
            'user'       => $user->load(['role', 'district']),
            'token'      => $token,
            'expires_at' => $expiresAt->toISOString(),
            'permissions'=> $permissions,
        ];
    }

    public function sendPasswordResetOtp(string $username): void
    {
        $user = User::where('username', $username)->orWhere('mobile', $username)->first();
        if (! $user) {
            return; // Silent fail — don't reveal if user exists
        }

        $otp = str_pad(random_int(0, 999999), 6, '0', STR_PAD_LEFT);
        Cache::put("pwd_reset_otp_{$user->id}", Hash::make($otp), 600); // 10 minutes

        // TODO: Send OTP via SMS gateway (MSG91)
        // SmsService::send($user->mobile, "Your UPMDSS password reset OTP: {$otp}. Valid for 10 minutes.");
    }

    public function resetPassword(string $username, string $otp, string $password): array
    {
        $user = User::where('username', $username)->first();
        if (! $user) {
            return ['success' => false, 'message' => 'Invalid request.'];
        }

        $cachedOtp = Cache::get("pwd_reset_otp_{$user->id}");
        if (! $cachedOtp || ! Hash::check($otp, $cachedOtp)) {
            return ['success' => false, 'message' => 'Invalid or expired OTP.'];
        }

        $user->update(['password' => Hash::make($password)]);
        Cache::forget("pwd_reset_otp_{$user->id}");

        // Revoke all existing tokens (force re-login)
        $user->tokens()->delete();

        return ['success' => true];
    }

    private function incrementFailedAttempts(string $username, string $ip, string $lockKey): void
    {
        $attemptsKey = "login_attempts_{$username}_{$ip}";
        $attempts = Cache::increment($attemptsKey);
        Cache::put($attemptsKey, $attempts, 3600);

        if ($attempts >= self::MAX_FAILED_ATTEMPTS) {
            Cache::put($lockKey, true, self::LOCKOUT_MINUTES * 60);
        }
    }

    private function logAttempt(?int $userId, string $username, string $ip, ?string $userAgent, string $status, string $reason): void
    {
        LoginLog::create([
            'user_id'         => $userId,
            'username_attempt'=> $username,
            'ip_address'      => $ip,
            'user_agent'      => $userAgent,
            'status'          => $status,
            'failure_reason'  => $reason,
            'logged_in_at'    => now(),
        ]);
    }
}
