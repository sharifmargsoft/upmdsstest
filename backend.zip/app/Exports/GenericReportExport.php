<?php

namespace App\Exports;

use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithStyles;
use Maatwebsite\Excel\Concerns\WithTitle;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Color;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use Illuminate\Support\Facades\DB;

class GenericReportExport implements
    FromCollection,
    WithHeadings,
    WithMapping,
    WithStyles,
    WithTitle,
    ShouldAutoSize
{
    private Collection $data;
    private string     $reportType;
    private array      $filters;

    public function __construct(string $reportType, array $filters)
    {
        $this->reportType = $reportType;
        $this->filters    = $filters;
        $this->data       = $this->fetchData();
    }

    public function collection(): Collection
    {
        return $this->data;
    }

    public function headings(): array
    {
        return match ($this->reportType) {
            'offense_wise' => [
                'Offense Type', 'Notice Count', 'Penalty Amount (₹)',
                'Recovered (₹)', 'Pending (₹)', 'Recovery %',
            ],
            'notice_summary' => [
                'District', 'Source', 'Notice Count', 'Penalty (₹)',
                'Recovered (₹)', 'Pending (₹)', 'Recovery %',
            ],
            'defaulter_vehicles' => [
                'Vehicle Number', 'Owner Name', 'District',
                'Offense Count', 'Outstanding Penalty (₹)', 'Blacklisted', 'Last Offense',
            ],
            'mcheck_activity' => [
                'Inspector', 'District', 'Total Inspections',
                'Offenses Detected', 'Notices Issued', 'Notice Yield %',
            ],
            'weighment_mismatch' => [
                'District', 'Weighbridge', 'Vehicle', 'eTP Number',
                'Declared (MT)', 'Actual (MT)', 'Mismatch %', 'Notice Issued', 'Date',
            ],
            default => ['Data'],
        };
    }

    public function map($row): array
    {
        $r = (array) $row;

        return match ($this->reportType) {
            'offense_wise' => [
                ucwords(str_replace('_', ' ', $r['offense_type'] ?? '')),
                $r['notice_count']  ?? 0,
                number_format($r['penalty_total']  ?? 0, 2),
                number_format($r['recovered']      ?? 0, 2),
                number_format($r['pending']        ?? 0, 2),
                ($r['recovery_pct'] ?? 0) . '%',
            ],
            'notice_summary' => [
                $r['district_name'] ?? '',
                ucfirst($r['source_type'] ?? ''),
                $r['notice_count']  ?? 0,
                number_format($r['penalty_total']  ?? 0, 2),
                number_format($r['recovered']      ?? 0, 2),
                number_format($r['pending']        ?? 0, 2),
                ($r['recovery_pct'] ?? 0) . '%',
            ],
            'defaulter_vehicles' => [
                $r['vehicle_number'] ?? '',
                $r['owner_name']     ?? '',
                $r['district_name']  ?? '',
                $r['offense_count']  ?? 0,
                number_format($r['pending_amount'] ?? 0, 2),
                ($r['is_blacklisted'] ?? false) ? 'Yes' : 'No',
                $r['last_offense']   ?? '',
            ],
            'mcheck_activity' => [
                $r['inspector_name']    ?? '',
                $r['district_name']     ?? '',
                $r['total_inspections'] ?? 0,
                $r['offenses_detected'] ?? 0,
                $r['notices_issued']    ?? 0,
                ($r['notice_yield_pct'] ?? 0) . '%',
            ],
            'weighment_mismatch' => [
                $r['district_name']       ?? '',
                $r['weighbridge_name']    ?? '',
                $r['vehicle_number']      ?? '',
                $r['etp_number']          ?? '',
                $r['weight_declared']     ?? '',
                $r['weight_actual']       ?? '',
                ($r['volume_mismatch_pct'] ?? 0) . '%',
                ($r['notice_id'] ?? null) ? 'Yes' : 'No',
                $r['weighed_at']          ?? '',
            ],
            default => array_values($r),
        };
    }

    public function title(): string
    {
        return match ($this->reportType) {
            'offense_wise'       => 'Offense-wise Report',
            'notice_summary'     => 'Notice Summary',
            'defaulter_vehicles' => 'Defaulter Vehicles',
            'mcheck_activity'    => 'mCHECK Activity',
            'weighment_mismatch' => 'Weighment Mismatch',
            default              => 'Report',
        };
    }

    public function styles(Worksheet $sheet): array
    {
        return [
            // Header row: bold white on blue background
            1 => [
                'font'      => ['bold' => true, 'color' => ['argb' => 'FFFFFFFF']],
                'fill'      => [
                    'fillType'   => Fill::FILL_SOLID,
                    'startColor' => ['argb' => 'FF1D4ED8'],
                ],
            ],
        ];
    }

    private function fetchData(): Collection
    {
        $districtScope = request()->user()?->districtScope();
        $dateFrom      = $this->filters['date_from'] ?? null;
        $dateTo        = $this->filters['date_to']   ?? null;

        return match ($this->reportType) {
            'offense_wise' => DB::table('e_notices')
                ->select('offense_type',
                    DB::raw('COUNT(*) as notice_count'),
                    DB::raw('COALESCE(SUM(penalty_amount),0) as penalty_total'),
                    DB::raw('COALESCE(SUM(paid_amount),0) as recovered'),
                    DB::raw('COALESCE(SUM(penalty_amount-paid_amount),0) as pending'),
                    DB::raw('ROUND(COALESCE(SUM(paid_amount),0)::numeric/NULLIF(COALESCE(SUM(penalty_amount),0),0)*100,1) as recovery_pct'))
                ->when($districtScope, fn($q,$d) => $q->where('district_id',$d))
                ->when($dateFrom, fn($q,$d) => $q->where('issued_at','>=',$d))
                ->when($dateTo,   fn($q,$d) => $q->where('issued_at','<=',$d))
                ->groupBy('offense_type')->orderByDesc('notice_count')
                ->get(),

            'notice_summary' => DB::table('e_notices as n')
                ->join('districts as d','n.district_id','=','d.id')
                ->select('d.name as district_name','n.source_type',
                    DB::raw('COUNT(*) as notice_count'),
                    DB::raw('COALESCE(SUM(n.penalty_amount),0) as penalty_total'),
                    DB::raw('COALESCE(SUM(n.paid_amount),0) as recovered'),
                    DB::raw('COALESCE(SUM(n.penalty_amount-n.paid_amount),0) as pending'),
                    DB::raw('ROUND(COALESCE(SUM(n.paid_amount),0)::numeric/NULLIF(COALESCE(SUM(n.penalty_amount),0),0)*100,1) as recovery_pct'))
                ->when($districtScope, fn($q,$did) => $q->where('n.district_id',$did))
                ->when($dateFrom, fn($q,$d) => $q->where('n.issued_at','>=',$d))
                ->when($dateTo,   fn($q,$d) => $q->where('n.issued_at','<=',$d))
                ->groupBy('d.name','n.source_type')->orderByDesc('penalty_total')
                ->get(),

            'defaulter_vehicles' => DB::table('e_notices as n')
                ->join('districts as d','n.district_id','=','d.id')
                ->leftJoin('vehicles as v','n.vehicle_number_norm','=','v.vehicle_number_norm')
                ->select('n.vehicle_number',
                    DB::raw('MAX(v.owner_name) as owner_name'),
                    'd.name as district_name',
                    DB::raw('COUNT(*) as offense_count'),
                    DB::raw('COALESCE(SUM(n.penalty_amount-n.paid_amount),0) as pending_amount'),
                    DB::raw('BOOL_OR(COALESCE(v.is_blacklisted,false)) as is_blacklisted'),
                    DB::raw('MAX(n.issued_at) as last_offense'))
                ->when($districtScope, fn($q,$did) => $q->where('n.district_id',$did))
                ->groupBy('n.vehicle_number','d.name')
                ->having(DB::raw('COUNT(*)'),'>', 1)
                ->orderByDesc('pending_amount')
                ->limit(500)
                ->get(),

            default => collect([]),
        };
    }
}
