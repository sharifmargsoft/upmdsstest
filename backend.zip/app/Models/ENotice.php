<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class ENotice extends BaseModel
{
    protected $table = 'e_notices';

    protected $guarded = ['id'];

    protected function casts(): array
    {
        return [
            'evidence_urls'             => 'array',
            'payment_gateway_response'  => 'array',
            'penalty_amount'            => 'float',
            'paid_amount'               => 'float',
            'pending_amount'            => 'float',
            'issued_at'                 => 'datetime',
            'paid_at'                   => 'datetime',
            'cancelled_at'              => 'datetime',
            'reactivated_at'            => 'datetime',
            'sms_sent_at'               => 'datetime',
            'email_sent_at'             => 'datetime',
            'portal_sent_at'            => 'datetime',
            'due_date'                  => 'date',
            'offense_date'              => 'date',
            'created_at'                => 'datetime',
            'updated_at'                => 'datetime',
        ];
    }

    // ─── Relations ───────────────────────────────────────

    public function district(): BelongsTo
    {
        return $this->belongsTo(District::class);
    }

    public function issuedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'issued_by');
    }

    public function template(): BelongsTo
    {
        return $this->belongsTo(NoticeTemplate::class, 'notice_template_id');
    }

    public function cancelledBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'cancelled_by');
    }

    public function parentNotice(): BelongsTo
    {
        return $this->belongsTo(ENotice::class, 'parent_notice_id');
    }

    public function reGeneratedNotices(): HasMany
    {
        return $this->hasMany(ENotice::class, 'parent_notice_id');
    }

    public function auditLogs(): HasMany
    {
        return $this->hasMany(NoticeAuditLog::class, 'notice_id');
    }

    // ─── Scopes ──────────────────────────────────────────

    public function scopePending(Builder $query): Builder
    {
        return $query->whereIn('status', ['issued', 'partially_paid']);
    }

    public function scopePaid(Builder $query): Builder
    {
        return $query->where('status', 'paid');
    }

    public function scopeCancelled(Builder $query): Builder
    {
        return $query->where('status', 'cancelled');
    }

    public function scopeForDistrict(Builder $query, ?int $districtId): Builder
    {
        return $districtId ? $query->where('district_id', $districtId) : $query;
    }

    public function scopeBySource(Builder $query, string $sourceType): Builder
    {
        return $query->where('source_type', $sourceType);
    }

    public function scopeDateRange(Builder $query, string $from, string $to): Builder
    {
        return $query->whereBetween('issued_at', [
            \Carbon\Carbon::parse($from)->startOfDay(),
            \Carbon\Carbon::parse($to)->endOfDay(),
        ]);
    }

    // ─── Helpers ─────────────────────────────────────────

    public function isPaid(): bool
    {
        return $this->status === 'paid';
    }

    public function isCancelled(): bool
    {
        return $this->status === 'cancelled';
    }

    public function isOverdue(): bool
    {
        return !$this->isPaid()
            && !$this->isCancelled()
            && $this->due_date?->isPast();
    }

    /**
     * Generate unique notice number.
     * Format: UPMDSS/{YEAR}/{DISTRICT_CODE}/{SOURCE_PREFIX}/{SEQUENCE}
     */
    public static function generateNoticeNumber(string $districtCode, string $sourceType): string
    {
        $year   = now()->format('Y');
        $prefix = match($sourceType) {
            'checkgate'   => 'CG',
            'mcheck'      => 'MC',
            'weighbridge' => 'WB',
            default       => 'MN',
        };
        $seq = str_pad(
            self::whereYear('issued_at', $year)->count() + 1,
            6, '0', STR_PAD_LEFT
        );
        return "UPMDSS/{$year}/{$districtCode}/{$prefix}/{$seq}";
    }
}
