<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Checkgate extends BaseModel
{
    protected $fillable = [
        'district_id', 'name', 'code', 'location_name',
        'latitude', 'longitude', 'highway_name',
        'status', 'installed_on', 'hardware_config',
    ];

    protected function casts(): array
    {
        return [
            'hardware_config' => 'array',
            'latitude'        => 'float',
            'longitude'       => 'float',
            'installed_on'    => 'date',
            'created_at'      => 'datetime',
            'updated_at'      => 'datetime',
        ];
    }

    public function district(): BelongsTo
    {
        return $this->belongsTo(District::class);
    }

    public function activities(): HasMany
    {
        return $this->hasMany(CheckgateActivity::class);
    }

    public function assignedUsers(): BelongsToMany
    {
        return $this->belongsToMany(User::class, 'user_checkgates')
                    ->withPivot('assigned_at');
    }

    public function scopeActive(Builder $query): Builder
    {
        return $query->where('status', 'active');
    }

    public function scopeForDistrict(Builder $query, ?int $districtId): Builder
    {
        return $districtId ? $query->where('district_id', $districtId) : $query;
    }
}
