<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Spatie\Permission\Traits\HasRoles;

class User extends Authenticatable
{
    use HasFactory, Notifiable, HasApiTokens, HasRoles, SoftDeletes;

    protected $guarded = ['id'];

    protected $hidden = ['password', 'remember_token'];

    protected function casts(): array
    {
        return [
            'is_active'          => 'boolean',
            'is_mcheck_user'     => 'boolean',
            'last_login_at'      => 'datetime',
            'email_verified_at'  => 'datetime',
            'deleted_at'         => 'datetime',
            'created_at'         => 'datetime',
            'updated_at'         => 'datetime',
        ];
    }

    // ─── Relations ───────────────────────────────────────

    public function district(): BelongsTo
    {
        return $this->belongsTo(District::class);
    }

    public function role(): BelongsTo
    {
        return $this->belongsTo(Role::class);
    }

    public function assignedCheckgates(): BelongsToMany
    {
        return $this->belongsToMany(Checkgate::class, 'user_checkgates')
                    ->withPivot('assigned_at');
    }

    public function loginLogs(): HasMany
    {
        return $this->hasMany(LoginLog::class);
    }

    // ─── Scopes ──────────────────────────────────────────

    public function scopeActive($query)
    {
        return $query->where('is_active', true)->whereNull('deleted_at');
    }

    public function scopeInDistrict($query, int $districtId)
    {
        return $query->where('district_id', $districtId);
    }

    public function scopeByRole($query, string $roleName)
    {
        return $query->whereHas('role', fn($q) => $q->where('name', $roleName));
    }

    public function scopeMcheckUsers($query)
    {
        return $query->where('is_mcheck_user', true);
    }

    // ─── Helpers ─────────────────────────────────────────

    public function isStateLevel(): bool
    {
        return is_null($this->district_id);
    }

    public function canAccessDistrict(int $districtId): bool
    {
        if ($this->isStateLevel()) {
            return true;
        }
        return $this->district_id === $districtId;
    }

    /**
     * Scope data to user's district for non-state-level users.
     * Used across repositories for row-level security.
     */
    public function districtScope(): ?int
    {
        return $this->isStateLevel() ? null : $this->district_id;
    }

    public function recordLogin(string $ip): void
    {
        $this->update([
            'last_login_at' => now(),
            'last_login_ip' => $ip,
        ]);
    }

    public function getDisplayRoleAttribute(): string
    {
        return $this->role?->display_name ?? '-';
    }
}
