<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;

class MineTag extends BaseModel
{
    protected $table    = 'mine_tags';
    protected $fillable = [
        'tag_id','vehicle_id','vehicle_number','status',
        'issued_on','issued_by_district_id','remarks',
        'last_seen_at','last_seen_checkgate_id',
    ];

    protected function casts(): array
    {
        return [
            'issued_on'    => 'date',
            'last_seen_at' => 'datetime',
            'created_at'   => 'datetime',
            'updated_at'   => 'datetime',
        ];
    }

    public function vehicle(): BelongsTo
    {
        return $this->belongsTo(Vehicle::class);
    }

    public function lastSeenCheckgate(): BelongsTo
    {
        return $this->belongsTo(Checkgate::class, 'last_seen_checkgate_id');
    }

    public function scopeActive($q)
    {
        return $q->where('status', 'active');
    }
}
