<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;

class WeighbridgeActivity extends BaseModel
{
    protected $table   = 'weighbridge_activities';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return [
            'etp_data'            => 'array',
            'is_overloaded'       => 'boolean',
            'has_emm11'           => 'boolean',
            'overload_pct'        => 'float',
            'volume_mismatch_pct' => 'float',
            'weight_permitted'    => 'float',
            'weight_declared'     => 'float',
            'weight_actual'       => 'float',
            'weighed_at'          => 'datetime',
            'created_at'          => 'datetime',
            'updated_at'          => 'datetime',
        ];
    }

    public function weighbridge(): BelongsTo
    {
        return $this->belongsTo(Weighbridge::class);
    }

    public function district(): BelongsTo
    {
        return $this->belongsTo(District::class);
    }

    public function mineral(): BelongsTo
    {
        return $this->belongsTo(Mineral::class);
    }

    public function notice(): HasOne
    {
        return $this->hasOne(ENotice::class, 'source_id')
                    ->where('source_type', 'weighbridge');
    }

    public function scopeAnomalies(Builder $q): Builder
    {
        return $q->where('anomaly_type', '!=', 'none');
    }

    public function scopeForDistrict(Builder $q, ?int $d): Builder
    {
        return $d ? $q->where('district_id', $d) : $q;
    }
}
