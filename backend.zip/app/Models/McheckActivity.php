<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;

class McheckActivity extends BaseModel
{
    protected $table   = 'mcheck_activities';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return [
            'etp_data'       => 'array',
            'evidence_photos'=> 'array',
            'inspection_lat' => 'float',
            'inspection_lng' => 'float',
            'inspected_at'   => 'datetime',
            'created_at'     => 'datetime',
            'updated_at'     => 'datetime',
        ];
    }

    public function inspector(): BelongsTo
    {
        return $this->belongsTo(User::class, 'inspector_id');
    }

    public function district(): BelongsTo
    {
        return $this->belongsTo(District::class);
    }

    public function mineral(): BelongsTo
    {
        return $this->belongsTo(Mineral::class);
    }

    public function notice(): HasOne
    {
        return $this->hasOne(ENotice::class, 'source_id')
                    ->where('source_type', 'mcheck');
    }

    public function scopeForDistrict(Builder $q, ?int $d): Builder
    {
        return $d ? $q->where('district_id', $d) : $q;
    }

    public function scopeWithOffense(Builder $q): Builder
    {
        return $q->whereNotNull('offense_type');
    }

    // Append inspector_name via accessor for API responses
    protected $appends = ['inspector_name'];

    public function getInspectorNameAttribute(): ?string
    {
        return $this->inspector?->name;
    }
}
