<?php namespace App\Models;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class VehicleBlacklist extends BaseModel {
    protected $table   = 'vehicle_blacklists';
    protected $guarded = ['id'];
    protected function casts(): array {
        return ['reference_notice_ids'=>'array','blacklisted_at'=>'datetime','removed_at'=>'datetime','valid_from'=>'date','valid_to'=>'date','created_at'=>'datetime','updated_at'=>'datetime'];
    }
    public function vehicle(): BelongsTo     { return $this->belongsTo(Vehicle::class); }
    public function district(): BelongsTo    { return $this->belongsTo(District::class); }
    public function blacklistedBy(): BelongsTo { return $this->belongsTo(User::class,'blacklisted_by'); }
    public function removedBy(): BelongsTo   { return $this->belongsTo(User::class,'removed_by'); }
    public function scopeActive(Builder $q): Builder { return $q->where('status','active'); }
}
