<?php namespace App\Models;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class NoticeTemplate extends BaseModel {
    protected $fillable = ['name','template_type','subject','body_html','is_active','version','created_by'];
    protected function casts(): array { return ['is_active'=>'boolean','version'=>'integer']; }
    public function createdBy(): BelongsTo { return $this->belongsTo(User::class,'created_by'); }
    public function notices(): HasMany     { return $this->hasMany(ENotice::class,'notice_template_id'); }
    public function scopeActive($q)        { return $q->where('is_active',true); }
}
