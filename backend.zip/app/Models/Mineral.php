<?php namespace App\Models;
class Mineral extends BaseModel {
    protected $fillable = ['name','code','unit','is_active'];
    protected function casts(): array { return ['is_active'=>'boolean']; }
    public function scopeActive($q) { return $q->where('is_active',true); }
}
