<?php namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class NoticeAuditLog extends Model {
    public $timestamps = false;
    protected $fillable = ['notice_id','action','from_status','to_status','remarks','performed_by','performed_at','metadata'];
    protected function casts(): array { return ['metadata'=>'array','performed_at'=>'datetime']; }
    public function notice(): BelongsTo     { return $this->belongsTo(ENotice::class); }
    public function performedBy(): BelongsTo { return $this->belongsTo(User::class,'performed_by'); }
}
