<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class CaseAssignment extends BaseModel
{
    protected $table   = 'case_assignments';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return [
            'due_date'     => 'date',
            'completed_at' => 'datetime',
            'created_at'   => 'datetime',
            'updated_at'   => 'datetime',
        ];
    }

    public function assignedTo(): BelongsTo { return $this->belongsTo(User::class, 'assigned_to'); }
    public function assignedBy(): BelongsTo { return $this->belongsTo(User::class, 'assigned_by'); }
    public function district(): BelongsTo   { return $this->belongsTo(District::class); }

    public function scopeForDistrict(Builder $q, ?int $d): Builder { return $d ? $q->where('district_id',$d) : $q; }
    public function scopeOpen(Builder $q): Builder { return $q->whereIn('status',['open','in_progress']); }

    public function isOverdue(): bool
    {
        return $this->due_date && $this->due_date->isPast()
            && ! in_array($this->status, ['completed','cancelled']);
    }
}
