<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Weighbridge extends BaseModel
{
    protected $fillable = [
        'district_id','name','code','location_name',
        'latitude','longitude','operator_name','is_active',
    ];

    protected function casts(): array
    {
        return ['is_active'=>'boolean','latitude'=>'float','longitude'=>'float'];
    }

    public function district(): BelongsTo  { return $this->belongsTo(District::class); }
    public function activities(): HasMany  { return $this->hasMany(WeighbridgeActivity::class); }
    public function scopeActive($q)        { return $q->where('is_active', true); }
}
