<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Casts\AsArrayObject;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;

class CheckgateActivity extends BaseModel
{
    protected $table = 'checkgate_activities';

    protected $guarded = ['id'];

    protected function casts(): array
    {
        return [
            'etp_data'           => 'array',
            'vahan_data'         => 'array',
            'flag_details'       => 'array',
            'raw_evidence_data'  => 'array',
            'is_overloaded'      => 'boolean',
            'minetag_installed'  => 'boolean',
            'crossing_at'        => 'datetime',
            'tse_reviewed_at'    => 'datetime',
            'ignored_at'         => 'datetime',
            'created_at'         => 'datetime',
            'updated_at'         => 'datetime',
            'mineral_confidence' => 'float',
            'overload_pct'       => 'float',
            'weight_vahan'       => 'float',
            'weight_etp_declared'=> 'float',
            'weight_actual'      => 'float',
        ];
    }

    // ─── Relations ───────────────────────────────────────

    public function checkgate(): BelongsTo
    {
        return $this->belongsTo(Checkgate::class);
    }

    public function district(): BelongsTo
    {
        return $this->belongsTo(District::class);
    }

    public function mineral(): BelongsTo
    {
        return $this->belongsTo(Mineral::class);
    }

    public function tseReviewer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'tse_reviewed_by');
    }

    public function ignoredBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'ignored_by');
    }

    public function notice(): HasOne
    {
        return $this->hasOne(ENotice::class, 'source_id')
                    ->where('source_type', 'checkgate');
    }

    // ─── Scopes ──────────────────────────────────────────

    public function scopeReported(Builder $query): Builder
    {
        return $query->where('status', 'reported');
    }

    public function scopePendingNotice(Builder $query): Builder
    {
        return $query->where('status', 'pending_notice');
    }

    public function scopeNoticeSent(Builder $query): Builder
    {
        return $query->where('status', 'notice_sent');
    }

    public function scopeIgnored(Builder $query): Builder
    {
        return $query->where('status', 'ignored');
    }

    public function scopeViolations(Builder $query): Builder
    {
        return $query->where('flag_type', '!=', 'valid');
    }

    public function scopeForDistrict(Builder $query, ?int $districtId): Builder
    {
        if ($districtId === null) {
            return $query;
        }
        return $query->where('district_id', $districtId);
    }

    public function scopeForCheckgate(Builder $query, ?int $checkgateId): Builder
    {
        if ($checkgateId === null) {
            return $query;
        }
        return $query->where('checkgate_id', $checkgateId);
    }

    public function scopeDateRange(Builder $query, string $from, string $to): Builder
    {
        return $query->whereBetween('crossing_at', [
            \Carbon\Carbon::parse($from)->startOfDay(),
            \Carbon\Carbon::parse($to)->endOfDay(),
        ]);
    }

    public function scopeByFlagType(Builder $query, string $flagType): Builder
    {
        return $query->where('flag_type', $flagType);
    }

    public function scopeByVehicle(Builder $query, string $vehicleNumber): Builder
    {
        $normalized = strtoupper(preg_replace('/\s+/', '', $vehicleNumber));
        return $query->where('vehicle_number_norm', $normalized);
    }

    // ─── Computed Attributes ─────────────────────────────

    public function getStatusLabelAttribute(): string
    {
        return match($this->status) {
            'reported'       => 'Reported',
            'under_review'   => 'Under Review',
            'pending_notice' => 'Pending Notice',
            'notice_sent'    => 'Notice Sent',
            'ignored'        => 'Ignored',
            'closed'         => 'Closed',
            default          => ucfirst($this->status),
        };
    }

    public function getFlagLabelAttribute(): string
    {
        return match($this->flag_type) {
            'valid'           => 'Valid',
            'expired_etp'     => 'Expired eTP',
            'without_etp'     => 'Without eTP',
            'bogus_etp'       => 'Bogus eTP',
            'duplicate_etp'   => 'Duplicate eTP',
            'mismatch'        => 'Vehicle Mismatch',
            'overload'        => 'Overloaded',
            'no_minetag'      => 'No MINETag',
            'obscured_plate'  => 'Obscured Plate',
            'bypass'          => 'Bypass',
            'volume_mismatch' => 'Volume Mismatch',
            default           => ucfirst(str_replace('_', ' ', $this->flag_type)),
        };
    }

    public function isViolation(): bool
    {
        return $this->flag_type !== 'valid';
    }

    public function canGenerateNotice(): bool
    {
        return $this->isViolation()
            && in_array($this->status, ['reported', 'pending_notice'])
            && is_null($this->notice_id);
    }
}
