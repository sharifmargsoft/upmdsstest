<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Relations\HasMany;

class District extends BaseModel
{
    protected $fillable = ['name', 'code', 'state', 'is_active'];

    protected function casts(): array
    {
        return [
            'is_active'  => 'boolean',
            'created_at' => 'datetime',
            'updated_at' => 'datetime',
        ];
    }

    public function checkgates(): HasMany
    {
        return $this->hasMany(Checkgate::class);
    }

    public function users(): HasMany
    {
        return $this->hasMany(User::class);
    }

    public function weighbridges(): HasMany
    {
        return $this->hasMany(Weighbridge::class);
    }

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }
}
