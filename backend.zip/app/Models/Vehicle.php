<?php namespace App\Models;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Vehicle extends BaseModel {
    protected $fillable = ['vehicle_number','vehicle_number_norm','vahan_data','owner_name','vehicle_class','gross_weight','registered_state','is_blacklisted','blacklisted_at','vahan_fetched_at'];
    protected function casts(): array {
        return ['vahan_data'=>'array','is_blacklisted'=>'boolean','gross_weight'=>'float','blacklisted_at'=>'datetime','vahan_fetched_at'=>'datetime','created_at'=>'datetime','updated_at'=>'datetime'];
    }
    public function mineTag(): HasOne     { return $this->hasOne(MineTag::class)->latestOfMany(); }
    public function blacklists(): HasMany { return $this->hasMany(VehicleBlacklist::class); }
    public static function normalize(string $v): string { return strtoupper(preg_replace('/\s+/','',$v)); }
}
