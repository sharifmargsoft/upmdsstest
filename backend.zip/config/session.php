<?php

use Illuminate\Support\Str;

return [

    'driver'   => env('SESSION_DRIVER', 'redis'),
    'lifetime' => env('SESSION_LIFETIME', 480),
    'expire_on_close' => env('SESSION_EXPIRE_ON_CLOSE', false),
    'encrypt'  => env('SESSION_ENCRYPT', false),
    'files'    => storage_path('framework/sessions'),
    'connection'=> env('SESSION_CONNECTION'),
    'table'    => env('SESSION_TABLE', 'sessions'),
    'store'    => env('SESSION_STORE'),
    'lottery'  => [2, 100],
    'cookie'   => env('SESSION_COOKIE', Str::slug(env('APP_NAME', 'upmdss'), '_').'_session'),
    'path'     => '/',
    'domain'   => env('SESSION_DOMAIN'),
    'secure'   => env('SESSION_SECURE_COOKIE', false),
    'http_only'=> true,
    'same_site'=> env('SESSION_SAME_SITE', 'lax'),
    'partitioned' => false,

];
