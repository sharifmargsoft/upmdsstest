<?php
// ============================================================
// config/queue.php
// ============================================================
return [

    'default' => env('QUEUE_CONNECTION', 'redis'),

    'connections' => [

        'sync' => ['driver' => 'sync'],

        'database' => [
            'driver'      => 'database',
            'connection'  => null,
            'table'       => 'jobs',
            'queue'       => 'default',
            'retry_after' => 90,
            'after_commit'=> false,
        ],

        'redis' => [
            'driver'      => 'redis',
            'connection'  => 'queue',
            'queue'       => env('REDIS_QUEUE', 'default'),
            'retry_after' => 90,
            'block_for'   => null,
            'after_commit'=> false,
        ],

    ],

    'batching' => [
        'database'   => env('DB_CONNECTION', 'pgsql'),
        'table'      => 'job_batches',
    ],

    'failed' => [
        'driver'   => env('QUEUE_FAILED_DRIVER', 'database-uuids'),
        'database' => env('DB_CONNECTION', 'pgsql'),
        'table'    => 'failed_jobs',
    ],

];
