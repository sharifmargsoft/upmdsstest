<?php
// ─────────────────────────────────────────────────────────────────────────────
// FILE: config/cors.php
// ─────────────────────────────────────────────────────────────────────────────
return [
    'paths'                    => ['api/*', 'sanctum/csrf-cookie'],
    'allowed_methods'          => ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    'allowed_origins'          => array_filter([
        env('FRONTEND_URL', 'http://localhost:3000'),
        env('APP_URL'),
    ]),
    'allowed_origins_patterns' => [],
    'allowed_headers'          => ['Authorization', 'Content-Type', 'Accept', 'X-Requested-With', 'X-CSRF-TOKEN'],
    'exposed_headers'          => ['X-Total-Count', 'X-Page-Count'],
    'max_age'                  => 86400,
    'supports_credentials'     => true,
];
