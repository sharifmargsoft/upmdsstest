<?php
// ─────────────────────────────────────────────────────────────────────────────
// FILE: config/services.php
// ─────────────────────────────────────────────────────────────────────────────
return [
    // ── External APIs ─────────────────────────────────────────────────────────
    'vahan' => [
        'url' => env('VAHAN_API_URL', 'https://vahan.parivahan.gov.in/api'),
        'key' => env('VAHAN_API_KEY'),
    ],
    'up_mines' => [
        'url' => env('UP_MINES_API_URL', 'https://upmine.up.gov.in/api'),
        'key' => env('UP_MINES_API_KEY'),
    ],
    'rajkosh' => [
        'url' => env('RAJKOSH_API_URL'),
        'key' => env('RAJKOSH_API_KEY'),
    ],
    // ── SMS Gateway ───────────────────────────────────────────────────────────
    'msg91' => [
        'auth_key'    => env('MSG91_AUTH_KEY'),
        'sender_id'   => env('MSG91_SENDER_ID', 'UPMDSS'),
        'template_id' => env('MSG91_TEMPLATE_ID'),
    ],
    // ── AWS S3 / MinIO ────────────────────────────────────────────────────────
    'aws' => [
        'key'    => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION', 'ap-south-1'),
        'bucket' => env('AWS_BUCKET'),
    ],
];
