<?php
// ─────────────────────────────────────────────────────────────────────────────
// FILE: bootstrap/app.php  (Laravel 11 style)
// ─────────────────────────────────────────────────────────────────────────────
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Http\Request;
use Illuminate\Auth\AuthenticationException;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        api: __DIR__.'/../routes/api.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
        apiPrefix: 'api',
    )
    ->withMiddleware(function (Middleware $middleware) {
        // Global API middleware
        $middleware->api(prepend: [
            \Illuminate\Http\Middleware\HandleCors::class,
        ]);

        // Register named middleware
        $middleware->alias([
            'active.user'   => \App\Http\Middleware\EnsureUserIsActive::class,
            'district.scope'=> \App\Http\Middleware\EnforceDistrictScope::class,
            'permission'    => \Spatie\Permission\Middleware\PermissionMiddleware::class,
            'role'          => \Spatie\Permission\Middleware\RoleMiddleware::class,
        ]);

        // Throttle rates
        $middleware->throttleApi();
    })
    ->withExceptions(function (Exceptions $exceptions) {
        // Handle auth exceptions as JSON
        $exceptions->render(function (AuthenticationException $e, Request $request) {
            return response()->json(['message' => 'Unauthenticated.', 'code' => 'UNAUTHENTICATED'], 401);
        });

        // Handle 404 as JSON for API routes
        $exceptions->render(function (\Illuminate\Database\Eloquent\ModelNotFoundException $e, Request $request) {
            if ($request->is('api/*')) {
                return response()->json(['message' => 'Resource not found.'], 404);
            }
        });

        // Handle validation errors
        $exceptions->render(function (\Illuminate\Validation\ValidationException $e, Request $request) {
            if ($request->is('api/*')) {
                return response()->json([
                    'message' => 'Validation failed.',
                    'errors'  => $e->errors(),
                ], 422);
            }
        });

        // Handle domain exceptions
        $exceptions->render(function (\DomainException $e, Request $request) {
            if ($request->is('api/*')) {
                return response()->json(['message' => $e->getMessage()], 422);
            }
        });

        // Handle authorization
        $exceptions->render(function (\Illuminate\Auth\Access\AuthorizationException $e, Request $request) {
            if ($request->is('api/*')) {
                return response()->json(['message' => 'Forbidden. Insufficient permissions.'], 403);
            }
        });
    })->create();
