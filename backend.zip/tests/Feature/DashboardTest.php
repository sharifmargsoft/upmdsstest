<?php
// =============================================================================
// FILE: tests/Feature/DashboardTest.php
// =============================================================================
use App\Models\User;
use App\Models\Role;
use Illuminate\Foundation\Testing\RefreshDatabase;

uses(RefreshDatabase::class);

beforeEach(function () {
    $this->artisan('migrate');
    $this->artisan('db:seed', ['--class' => 'RolePermissionSeeder']);
    $this->artisan('db:seed', ['--class' => 'DistrictSeeder']);

    $role       = Role::where('name', 'state_admin')->first();
    $this->user = User::factory()->create(['role_id' => $role->id, 'district_id' => null]);
    $this->user->assignRole('state_admin');
});

test('state admin can access dashboard kpi', function () {
    $response = $this->actingAs($this->user, 'sanctum')
        ->getJson('/api/v1/dashboard/kpi');

    $response
        ->assertStatus(200)
        ->assertJsonStructure([
            'data' => [
                'total_vehicles_today',
                'notices_total',
                'penalty_total',
                'penalty_recovered',
                'penalty_pending',
                'blacklisted_vehicles',
            ],
        ]);
});

test('state admin can access map dashboard', function () {
    $response = $this->actingAs($this->user, 'sanctum')
        ->getJson('/api/v1/dashboard/map');

    $response
        ->assertStatus(200)
        ->assertJsonStructure(['data' => ['checkgates']]);
});

test('state admin can access analysis dashboard', function () {
    $response = $this->actingAs($this->user, 'sanctum')
        ->getJson('/api/v1/dashboard/analysis/district-pendency');

    $response->assertStatus(200)->assertJsonStructure(['data']);
});

test('unauthenticated user cannot access dashboard', function () {
    $this->getJson('/api/v1/dashboard/kpi')
        ->assertStatus(401);
});


// =============================================================================
// FILE: tests/Feature/CheckgateActivityTest.php
// =============================================================================
use App\Models\Checkgate;
use App\Models\District;

test('tse can list checkgate activities', function () {
    $this->artisan('migrate');
    $this->artisan('db:seed', ['--class' => 'RolePermissionSeeder']);
    $this->artisan('db:seed', ['--class' => 'DistrictSeeder']);
    $this->artisan('db:seed', ['--class' => 'CheckgateSeeder']);

    $role = Role::where('name', 'tse')->first();
    $user = User::factory()->create(['role_id' => $role->id, 'district_id' => null]);
    $user->assignRole('tse');

    $response = $this->actingAs($user, 'sanctum')
        ->getJson('/api/v1/checkgate/activities?per_page=10');

    $response
        ->assertStatus(200)
        ->assertJsonStructure([
            'data',
            'meta' => ['total', 'current_page', 'last_page', 'per_page'],
        ]);
});

test('checkgate activity stats are returned correctly', function () {
    $this->artisan('migrate');
    $this->artisan('db:seed', ['--class' => 'RolePermissionSeeder']);
    $this->artisan('db:seed', ['--class' => 'DistrictSeeder']);

    $role = Role::where('name', 'tse')->first();
    $user = User::factory()->create(['role_id' => $role->id]);
    $user->assignRole('tse');

    $response = $this->actingAs($user, 'sanctum')
        ->getJson('/api/v1/checkgate/activities/stats/summary');

    $response
        ->assertStatus(200)
        ->assertJsonStructure([
            'data' => ['total', 'violations', 'pending_notice', 'notice_sent', 'ignored'],
        ]);
});

test('inspector cannot access checkgate activities', function () {
    $this->artisan('migrate');
    $this->artisan('db:seed', ['--class' => 'RolePermissionSeeder']);
    $this->artisan('db:seed', ['--class' => 'DistrictSeeder']);

    $role = Role::where('name', 'inspector')->first();
    $user = User::factory()->create(['role_id' => $role->id]);
    $user->assignRole('inspector');

    // Inspector has no checkgate.activity.view permission
    $this->actingAs($user, 'sanctum')
        ->getJson('/api/v1/checkgate/activities')
        ->assertStatus(403);
});


// =============================================================================
// FILE: tests/Feature/ENoticeTest.php
// =============================================================================
use App\Models\ENotice;
use App\Models\NoticeTemplate;

test('dmo can list e-notices', function () {
    $this->artisan('migrate');
    $this->artisan('db:seed', ['--class' => 'RolePermissionSeeder']);
    $this->artisan('db:seed', ['--class' => 'DistrictSeeder']);

    $role     = Role::where('name', 'dmo')->first();
    $district = District::first();
    $user     = User::factory()->create(['role_id' => $role->id, 'district_id' => $district->id]);
    $user->assignRole('dmo');

    $response = $this->actingAs($user, 'sanctum')
        ->getJson('/api/v1/notices?per_page=10');

    $response
        ->assertStatus(200)
        ->assertJsonStructure(['data', 'meta']);
});

test('dmo can cancel a notice', function () {
    $this->artisan('migrate');
    $this->artisan('db:seed', ['--class' => 'RolePermissionSeeder']);
    $this->artisan('db:seed', ['--class' => 'DistrictSeeder']);
    $this->artisan('db:seed', ['--class' => 'NoticeTemplateSeeder']);

    $role     = Role::where('name', 'dmo')->first();
    $district = District::first();
    $user     = User::factory()->create(['role_id' => $role->id, 'district_id' => $district->id]);
    $user->assignRole('dmo');

    $template = NoticeTemplate::first();

    $notice = ENotice::create([
        'notice_number'       => 'UPMDSS/2026/TST/CG/000001',
        'source_type'         => 'checkgate',
        'source_id'           => 1,
        'district_id'         => $district->id,
        'issued_by'           => $user->id,
        'vehicle_number'      => 'UP32XX1234',
        'vehicle_number_norm' => 'UP32XX1234',
        'offense_type'        => 'without_etp',
        'offense_date'        => now()->toDateString(),
        'penalty_amount'      => 50000,
        'paid_amount'         => 0,
        'status'              => 'issued',
        'issued_at'           => now(),
        'due_date'            => now()->addDays(30)->toDateString(),
        'notice_template_id'  => $template->id,
    ]);

    $response = $this->actingAs($user, 'sanctum')
        ->putJson("/api/v1/notices/{$notice->id}/cancel", [
            'reason' => 'Test cancellation reason — minimum ten characters',
        ]);

    $response->assertStatus(200);

    $this->assertDatabaseHas('e_notices', [
        'id'     => $notice->id,
        'status' => 'cancelled',
    ]);
});

test('notice cannot be cancelled if already paid', function () {
    $this->artisan('migrate');
    $this->artisan('db:seed', ['--class' => 'RolePermissionSeeder']);
    $this->artisan('db:seed', ['--class' => 'DistrictSeeder']);
    $this->artisan('db:seed', ['--class' => 'NoticeTemplateSeeder']);

    $role     = Role::where('name', 'dmo')->first();
    $district = District::first();
    $user     = User::factory()->create(['role_id' => $role->id, 'district_id' => $district->id]);
    $user->assignRole('dmo');

    $notice = ENotice::create([
        'notice_number'       => 'UPMDSS/2026/TST/CG/000002',
        'source_type'         => 'checkgate',
        'source_id'           => 1,
        'district_id'         => $district->id,
        'issued_by'           => $user->id,
        'vehicle_number'      => 'UP32XX9999',
        'vehicle_number_norm' => 'UP32XX9999',
        'offense_type'        => 'overload',
        'offense_date'        => now()->toDateString(),
        'penalty_amount'      => 25000,
        'paid_amount'         => 25000,
        'status'              => 'paid',
        'issued_at'           => now(),
    ]);

    $this->actingAs($user, 'sanctum')
        ->putJson("/api/v1/notices/{$notice->id}/cancel", [
            'reason' => 'Attempting to cancel paid notice',
        ])
        ->assertStatus(422);
});
