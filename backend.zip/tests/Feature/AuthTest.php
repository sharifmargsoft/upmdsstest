<?php
// =============================================================================
// FILE: tests/Feature/AuthTest.php
// =============================================================================
use App\Models\User;
use App\Models\Role;
use App\Models\District;
use Illuminate\Foundation\Testing\RefreshDatabase;

uses(RefreshDatabase::class);

beforeEach(function () {
    // Run migrations and seed roles
    $this->artisan('migrate');
    $this->artisan('db:seed', ['--class' => 'RolePermissionSeeder']);
    $this->artisan('db:seed', ['--class' => 'DistrictSeeder']);
});

test('user can login with valid credentials', function () {
    $role = Role::where('name', 'state_admin')->first();
    $user = User::factory()->create([
        'username'  => 'testuser',
        'password'  => bcrypt('Password@123'),
        'role_id'   => $role->id,
        'is_active' => true,
    ]);

    $response = $this->postJson('/api/v1/auth/login', [
        'username' => 'testuser',
        'password' => 'Password@123',
    ]);

    $response
        ->assertStatus(200)
        ->assertJsonStructure([
            'data' => [
                'user' => ['id', 'name', 'username', 'role'],
                'token',
                'permissions',
                'expires_at',
            ],
        ]);
});

test('login fails with wrong password', function () {
    $role = Role::where('name', 'state_admin')->first();
    User::factory()->create([
        'username'  => 'testuser2',
        'password'  => bcrypt('RealPassword@123'),
        'role_id'   => $role->id,
        'is_active' => true,
    ]);

    $response = $this->postJson('/api/v1/auth/login', [
        'username' => 'testuser2',
        'password' => 'WrongPassword',
    ]);

    $response->assertStatus(401);
});

test('inactive user cannot login', function () {
    $role = Role::where('name', 'dmo')->first();
    User::factory()->create([
        'username'  => 'inactiveuser',
        'password'  => bcrypt('Password@123'),
        'role_id'   => $role->id,
        'is_active' => false,
    ]);

    $response = $this->postJson('/api/v1/auth/login', [
        'username' => 'inactiveuser',
        'password' => 'Password@123',
    ]);

    $response->assertStatus(401);
});

test('authenticated user can get their profile', function () {
    $role = Role::where('name', 'state_admin')->first();
    $user = User::factory()->create(['role_id' => $role->id]);
    $user->assignRole('state_admin');

    $response = $this->actingAs($user, 'sanctum')
        ->getJson('/api/v1/auth/me');

    $response
        ->assertStatus(200)
        ->assertJsonPath('data.username', $user->username);
});

test('authenticated user can logout', function () {
    $role = Role::where('name', 'state_admin')->first();
    $user = User::factory()->create(['role_id' => $role->id]);
    $user->assignRole('state_admin');

    $token = $user->createToken('test')->plainTextToken;

    $response = $this->withHeader('Authorization', "Bearer {$token}")
        ->postJson('/api/v1/auth/logout');

    $response->assertStatus(200);

    // Token should now be revoked
    $this->withHeader('Authorization', "Bearer {$token}")
        ->getJson('/api/v1/auth/me')
        ->assertStatus(401);
});

test('brute force lockout after 5 failed attempts', function () {
    for ($i = 0; $i < 5; $i++) {
        $this->postJson('/api/v1/auth/login', [
            'username' => 'nonexistent',
            'password' => 'wrongpassword',
        ]);
    }

    // 6th attempt should be blocked
    $response = $this->postJson('/api/v1/auth/login', [
        'username' => 'nonexistent',
        'password' => 'wrongpassword',
    ]);

    $response->assertStatus(401)
        ->assertJsonFragment(['code' => 'INVALID_CREDENTIALS']);
});
