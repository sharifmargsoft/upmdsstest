<?php

use Illuminate\Support\Facades\Schedule;

/*
|--------------------------------------------------------------------------
| Console Routes — UPMDSS Scheduled Commands
|--------------------------------------------------------------------------
*/

// Refresh PostgreSQL materialized view for dashboard KPIs every 5 minutes
Schedule::command('upmdss:refresh-mv')
    ->everyFiveMinutes()
    ->withoutOverlapping()
    ->runInBackground()
    ->appendOutputTo(storage_path('logs/refresh-mv.log'));

// Auto-create next month's checkgate_activities partition on 25th of each month at 00:05
Schedule::command('upmdss:create-partition')
    ->monthlyOn(25, '00:05')
    ->withoutOverlapping()
    ->appendOutputTo(storage_path('logs/partition.log'));

// Prune expired Sanctum tokens daily
Schedule::command('sanctum:prune-expired', ['--hours' => 24])
    ->daily()
    ->withoutOverlapping();

// Prune failed queue jobs older than 7 days
Schedule::command('queue:prune-failed', ['--hours' => 168])
    ->daily();

// Warm Redis caches every morning at 5:30 AM (before business hours)
Schedule::command('upmdss:warm-cache')
    ->dailyAt('05:30')
    ->withoutOverlapping();

// Update overdue assignment statuses at midnight
Schedule::call(function () {
    \App\Models\CaseAssignment::query()
        ->where('status', 'open')
        ->whereDate('due_date', '<', now()->toDateString())
        ->update(['status' => 'overdue']);
})->daily()->name('mark-overdue-assignments')->withoutOverlapping();
