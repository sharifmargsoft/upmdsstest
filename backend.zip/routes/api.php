<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\API\v1\Auth\AuthController;
use App\Http\Controllers\API\v1\Auth\ProfileController;
use App\Http\Controllers\API\v1\Dashboard\DashboardController;
use App\Http\Controllers\API\v1\Dashboard\MapDashboardController;
use App\Http\Controllers\API\v1\Dashboard\AnalysisDashboardController;
use App\Http\Controllers\API\v1\Checkgate\CheckgateActivityController;
use App\Http\Controllers\API\v1\Checkgate\CheckgateReportController;
use App\Http\Controllers\API\v1\Checkgate\NoticeSummaryCheckgateController;
use App\Http\Controllers\API\v1\Mcheck\McheckActivityController;
use App\Http\Controllers\API\v1\Mcheck\McheckLoginLogController;
use App\Http\Controllers\API\v1\Weighbridge\WeighbridgeActivityController;
use App\Http\Controllers\API\v1\Notice\ENoticeController;
use App\Http\Controllers\API\v1\Notice\NoticeTemplateController;
use App\Http\Controllers\API\v1\Master\DistrictController;
use App\Http\Controllers\API\v1\Master\CheckgateController;
use App\Http\Controllers\API\v1\Master\MineralController;
use App\Http\Controllers\API\v1\User\UserController;
use App\Http\Controllers\API\v1\Minetag\MinetagController;
use App\Http\Controllers\API\v1\Blacklist\BlacklistController;
use App\Http\Controllers\API\v1\Assign\CaseAssignmentController;
use App\Http\Controllers\API\v1\Report\ReportController;
use App\Http\Controllers\API\v1\Utility\UtilityController;
use App\Http\Controllers\API\v1\Utility\EtpVerificationController;

/*
|--------------------------------------------------------------------------
| API Routes — UPMDSS v1
|--------------------------------------------------------------------------
| Prefix: /api/v1
| Auth: Laravel Sanctum token-based
| Rate Limiting: configured in RouteServiceProvider
|--------------------------------------------------------------------------
*/

Route::prefix('v1')->name('api.v1.')->group(function () {

    // ═══════════════════════════════════════════════════
    // AUTH — Public (no token required)
    // ═══════════════════════════════════════════════════
    Route::prefix('auth')->name('auth.')->group(function () {
        Route::post('login',            [AuthController::class, 'login'])->name('login');
        Route::post('forgot-password',  [AuthController::class, 'forgotPassword'])->name('forgot-password');
        Route::post('reset-password',   [AuthController::class, 'resetPassword'])->name('reset-password');
    });

    // ═══════════════════════════════════════════════════
    // PUBLIC UTILITIES (no auth — limited)
    // ═══════════════════════════════════════════════════
    Route::prefix('public')->name('public.')->middleware(['throttle:public_api'])->group(function () {
        Route::get('etp/verify/{etp_number}',   [EtpVerificationController::class, 'verify'])->name('etp.verify');
        Route::get('notice/{notice_number}/pay', [ENoticeController::class, 'payInfo'])->name('notice.pay');
    });

    // ═══════════════════════════════════════════════════
    // AUTHENTICATED ROUTES
    // ═══════════════════════════════════════════════════
    Route::middleware(['auth:sanctum', 'throttle:authenticated_api', 'active.user'])->group(function () {

        // Auth
        Route::prefix('auth')->name('auth.')->group(function () {
            Route::post('logout',   [AuthController::class, 'logout'])->name('logout');
            Route::get('me',        [ProfileController::class, 'show'])->name('me');
            Route::put('me',        [ProfileController::class, 'update'])->name('me.update');
            Route::post('me/password', [ProfileController::class, 'changePassword'])->name('me.password');
            Route::get('permissions', [AuthController::class, 'permissions'])->name('permissions');
        });

        // ─── DASHBOARD ──────────────────────────────────
        Route::prefix('dashboard')->name('dashboard.')->group(function () {
            Route::get('/',         [DashboardController::class, 'index'])->name('index')
                ->middleware('permission:dashboard.view');
            Route::get('kpi',       [DashboardController::class, 'kpi'])->name('kpi')
                ->middleware('permission:dashboard.view');
            Route::get('map',       [MapDashboardController::class, 'index'])->name('map')
                ->middleware('permission:dashboard.map.view');
            Route::get('analysis',  [AnalysisDashboardController::class, 'index'])->name('analysis')
                ->middleware('permission:dashboard.analysis.view');
            Route::get('analysis/district-pendency', [AnalysisDashboardController::class, 'districtPendency'])
                ->middleware('permission:dashboard.analysis.view');
        });

        // ─── CHECKGATE ACTIVITIES ───────────────────────
        Route::prefix('checkgate')->name('checkgate.')->group(function () {

            Route::prefix('activities')->name('activities.')->middleware('permission:checkgate.activity.view')->group(function () {
                Route::get('/',             [CheckgateActivityController::class, 'index'])->name('index');
                Route::get('{id}',          [CheckgateActivityController::class, 'show'])->name('show');
                Route::get('stats/summary', [CheckgateActivityController::class, 'stats'])->name('stats');
            });

            Route::middleware('permission:checkgate.activity.review')->group(function () {
                Route::put('activities/{id}/review', [CheckgateActivityController::class, 'review'])->name('activities.review');
                Route::put('activities/{id}/correct-vehicle', [CheckgateActivityController::class, 'correctVehicle'])->name('activities.correct-vehicle');
            });

            Route::middleware('permission:checkgate.activity.ignore')->group(function () {
                Route::put('activities/{id}/ignore', [CheckgateActivityController::class, 'ignore'])->name('activities.ignore');
                Route::get('ignored',               [CheckgateActivityController::class, 'ignored'])->name('activities.ignored');
            });

            Route::middleware('permission:checkgate.notice.generate')->group(function () {
                Route::post('activities/{id}/notice', [CheckgateActivityController::class, 'generateNotice'])->name('activities.notice');
            });

            Route::middleware('permission:checkgate.report.view')->group(function () {
                Route::get('reports/progress',      [CheckgateReportController::class, 'progress'])->name('reports.progress');
                Route::get('reports/smudge',        [CheckgateReportController::class, 'smudge'])->name('reports.smudge');
                Route::get('reports/ignore-stats',  [CheckgateReportController::class, 'ignoreStats'])->name('reports.ignore-stats');
                Route::get('notice-summary',        [NoticeSummaryCheckgateController::class, 'index'])->name('notice-summary');
            });
        });

        // ─── mCHECK ACTIVITIES ──────────────────────────
        Route::prefix('mcheck')->name('mcheck.')->group(function () {
            Route::get('activities',        [McheckActivityController::class, 'index'])
                ->middleware('permission:mcheck.activity.view');
            Route::get('activities/{id}',   [McheckActivityController::class, 'show'])
                ->middleware('permission:mcheck.activity.view');
            Route::put('activities/{id}/notice', [McheckActivityController::class, 'generateNotice'])
                ->middleware('permission:mcheck.notice.generate');
            Route::get('notice-summary',    [McheckActivityController::class, 'noticeSummary'])
                ->middleware('permission:mcheck.report.view');
            Route::get('login-logs',        [McheckLoginLogController::class, 'index'])
                ->middleware('permission:mcheck.activity.view');
            Route::get('activity-log',      [McheckActivityController::class, 'activityLog'])
                ->middleware('permission:mcheck.report.view');
        });

        // ─── WEIGHBRIDGE ────────────────────────────────
        Route::prefix('weighbridge')->name('weighbridge.')->middleware('permission:weighbridge.view')->group(function () {
            Route::get('valid',             [WeighbridgeActivityController::class, 'valid'])->name('valid');
            Route::get('overloaded',        [WeighbridgeActivityController::class, 'overloaded'])->name('overloaded');
            Route::get('volume-mismatch',   [WeighbridgeActivityController::class, 'volumeMismatch'])->name('volume-mismatch');
            Route::get('no-emm11',          [WeighbridgeActivityController::class, 'noEmm11'])->name('no-emm11');
            Route::get('anomaly-notices',   [WeighbridgeActivityController::class, 'anomalyNotices'])->name('anomaly-notices');
            Route::post('{id}/notice',      [WeighbridgeActivityController::class, 'generateNotice'])
                ->middleware('permission:weighbridge.notice.generate');
        });

        // ─── E-NOTICES ──────────────────────────────────
        Route::prefix('notices')->name('notices.')->middleware('permission:notice.view')->group(function () {
            Route::get('/',             [ENoticeController::class, 'index'])->name('index');
            Route::get('{id}',          [ENoticeController::class, 'show'])->name('show');
            Route::get('{id}/pdf',      [ENoticeController::class, 'downloadPdf'])->name('pdf');
            Route::post('{id}/resend',  [ENoticeController::class, 'resend'])->name('resend');

            Route::put('{id}/cancel',   [ENoticeController::class, 'cancel'])
                ->middleware('permission:notice.cancel');
            Route::post('{id}/reactivate', [ENoticeController::class, 'reactivate'])
                ->middleware('permission:notice.reactivate');
            Route::post('{id}/payment', [ENoticeController::class, 'recordPayment'])
                ->middleware('permission:notice.pay');

            // Reports
            Route::get('reports/offense-wise',      [ENoticeController::class, 'offenseWiseReport']);
            Route::get('reports/summary',           [ENoticeController::class, 'summaryReport']);
            Route::get('reports/checkgate-mcheck',  [ENoticeController::class, 'checkgateMcheckReport']);
            Route::get('reports/gatewise',          [ENoticeController::class, 'gatewiseReport']);
            Route::get('reports/defaulters',        [ENoticeController::class, 'defaultersReport']);
        });

        // ─── MASTER DATA ────────────────────────────────
        Route::prefix('master')->name('master.')->group(function () {
            // Notice templates — managed by admin only
            Route::apiResource('notice-templates', NoticeTemplateController::class)
                ->middleware('permission:master.template.manage');

            // Reference data — all authenticated users can read
            Route::get('districts',     [DistrictController::class, 'index'])->name('districts');
            Route::get('checkgates',    [CheckgateController::class, 'index'])->name('checkgates');
            Route::get('minerals',      [MineralController::class, 'index'])->name('minerals');
        });

        // ─── USER MANAGEMENT ────────────────────────────
        Route::prefix('users')->name('users.')->middleware('permission:user.view')->group(function () {
            Route::get('/',             [UserController::class, 'index'])->name('index');
            Route::get('{id}',          [UserController::class, 'show'])->name('show');
            Route::post('/',            [UserController::class, 'store'])
                ->middleware('permission:user.create');
            Route::put('{id}',          [UserController::class, 'update'])
                ->middleware('permission:user.edit');
            Route::put('{id}/toggle-status', [UserController::class, 'toggleStatus'])
                ->middleware('permission:user.deactivate');
            Route::post('{id}/reset-password', [UserController::class, 'resetPassword'])
                ->middleware('permission:user.edit');
        });

        // ─── MINETAG ────────────────────────────────────
        Route::prefix('minetags')->name('minetags.')->middleware('permission:minetag.view')->group(function () {
            Route::get('/',         [MinetagController::class, 'index'])->name('index');
            Route::get('{id}',      [MinetagController::class, 'show'])->name('show');
            Route::post('/',        [MinetagController::class, 'store'])->middleware('permission:minetag.manage');
            Route::put('{id}',      [MinetagController::class, 'update'])->middleware('permission:minetag.manage');
        });

        // ─── BLACKLIST ──────────────────────────────────
        Route::prefix('blacklist')->name('blacklist.')->middleware('permission:blacklist.view')->group(function () {
            Route::get('/',             [BlacklistController::class, 'index'])->name('index');
            Route::get('history',       [BlacklistController::class, 'history'])->name('history');
            Route::get('{id}',          [BlacklistController::class, 'show'])->name('show');
            Route::post('/',            [BlacklistController::class, 'store'])
                ->middleware('permission:blacklist.add');
            Route::put('{id}/remove',   [BlacklistController::class, 'remove'])
                ->middleware('permission:blacklist.remove');
            Route::get('vehicles/search', [BlacklistController::class, 'searchVehicle'])->name('search');
        });

        // ─── ASSIGNMENTS ────────────────────────────────
        Route::prefix('assignments')->name('assignments.')->group(function () {
            Route::get('/',         [CaseAssignmentController::class, 'index'])
                ->middleware('permission:assign.view');
            Route::get('summary',   [CaseAssignmentController::class, 'summary'])
                ->middleware('permission:assign.view');
            Route::get('{id}',      [CaseAssignmentController::class, 'show'])
                ->middleware('permission:assign.view');
            Route::post('/',        [CaseAssignmentController::class, 'store'])
                ->middleware('permission:assign.create');
            Route::put('{id}/complete', [CaseAssignmentController::class, 'complete'])
                ->middleware('permission:assign.create');
        });

        // ─── REPORTS ────────────────────────────────────
        Route::prefix('reports')->name('reports.')->middleware('permission:report.view')->group(function () {
            Route::get('mcheck-activity',       [ReportController::class, 'mcheckActivity']);
            Route::get('checkgate-mcheck-analysis', [ReportController::class, 'checkgateMcheckAnalysis']);
            Route::get('weighment-volume-mismatch', [ReportController::class, 'weighmentVolumeMismatch']);
            Route::get('weighment-emm11',       [ReportController::class, 'weighmentEmm11']);
            Route::get('defaulter-vehicles',    [ReportController::class, 'defaulterVehicles']);
            Route::post('export',               [ReportController::class, 'export'])
                ->middleware('permission:report.export');
        });

        // ─── UTILITY ────────────────────────────────────
        Route::prefix('utility')->name('utility.')->group(function () {
            Route::get('login-logs',    [UtilityController::class, 'loginLogs'])
                ->middleware('permission:utility.login_log.view');
            Route::get('search-transporter', [UtilityController::class, 'searchTransporter'])
                ->middleware('permission:notice.view');
            Route::get('geo-inspection', [UtilityController::class, 'geoInspection'])
                ->middleware('permission:utility.geo.view');
        });

    }); // end authenticated group

}); // end v1 prefix
