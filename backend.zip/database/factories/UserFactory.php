<?php

namespace Database\Factories;

use App\Models\Role;
use App\Models\District;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class UserFactory extends Factory
{
    public function definition(): array
    {
        return [
            'name'              => $this->faker->name(),
            'username'          => $this->faker->unique()->userName() . rand(1, 999),
            'email'             => $this->faker->unique()->safeEmail(),
            'mobile'            => '9' . $this->faker->numerify('#########'),
            'password'          => Hash::make('Password@123'),
            'designation'       => $this->faker->jobTitle(),
            'employee_id'       => 'EMP/' . $this->faker->numerify('####'),
            'role_id'           => Role::first()?->id ?? 1,
            'district_id'       => null,
            'is_active'         => true,
            'is_mcheck_user'    => false,
            'remember_token'    => Str::random(10),
        ];
    }

    public function inactive(): static
    {
        return $this->state(fn () => ['is_active' => false]);
    }

    public function mcheckUser(): static
    {
        return $this->state(fn () => ['is_mcheck_user' => true]);
    }

    public function forDistrict(int $districtId): static
    {
        return $this->state(fn () => ['district_id' => $districtId]);
    }

    public function withRole(string $roleName): static
    {
        return $this->state(function () use ($roleName) {
            $role = Role::where('name', $roleName)->first();
            return $role ? ['role_id' => $role->id] : [];
        });
    }
}
