<?php

namespace Database\Seeders;

use App\Models\Mineral;
use Illuminate\Database\Seeder;

class MineralSeeder extends Seeder
{
    public function run(): void
    {
        $minerals = [
            ['name'=>'Sand',       'code'=>'SND','unit'=>'MT'],
            ['name'=>'Gravel',     'code'=>'GRV','unit'=>'MT'],
            ['name'=>'Granite',    'code'=>'GNT','unit'=>'MT'],
            ['name'=>'Limestone',  'code'=>'LST','unit'=>'MT'],
            ['name'=>'Moorum',     'code'=>'MRM','unit'=>'MT'],
            ['name'=>'Marble',     'code'=>'MRB','unit'=>'MT'],
            ['name'=>'Clay',       'code'=>'CLY','unit'=>'MT'],
            ['name'=>'Silica Sand','code'=>'SLS','unit'=>'MT'],
            ['name'=>'Bajri',      'code'=>'BJR','unit'=>'CFT'],
        ];
        foreach ($minerals as $m) {
            Mineral::updateOrCreate(['code'=>$m['code']], array_merge($m,['is_active'=>true]));
        }
        $this->command->info('Minerals seeded: ' . count($minerals));
    }
}
