<?php

namespace Database\Seeders;

use App\Models\District;
use Illuminate\Database\Seeder;

class DistrictSeeder extends Seeder
{
    private array $districts = [
        ['name'=>'Agra','code'=>'AGR'],['name'=>'Aligarh','code'=>'ALG'],
        ['name'=>'Allahabad','code'=>'ALD'],['name'=>'Ambedkar Nagar','code'=>'ABN'],
        ['name'=>'Amethi','code'=>'AMT'],['name'=>'Auraiya','code'=>'AUR'],
        ['name'=>'Azamgarh','code'=>'AZM'],['name'=>'Banda','code'=>'BND'],
        ['name'=>'Barabanki','code'=>'BBK'],['name'=>'Bareilly','code'=>'BRL'],
        ['name'=>'Basti','code'=>'BST'],['name'=>'Bijnor','code'=>'BJN'],
        ['name'=>'Bulandshahr','code'=>'BLD'],['name'=>'Chandauli','code'=>'CHA'],
        ['name'=>'Chitrakoot','code'=>'CTK'],['name'=>'Deoria','code'=>'DOR'],
        ['name'=>'Etah','code'=>'ETA'],['name'=>'Etawah','code'=>'ETW'],
        ['name'=>'Farrukhabad','code'=>'FRK'],['name'=>'Fatehpur','code'=>'FTP'],
        ['name'=>'Firozabad','code'=>'FRZ'],['name'=>'Gautam Buddha Nagar','code'=>'GBN'],
        ['name'=>'Ghaziabad','code'=>'GZB'],['name'=>'Ghazipur','code'=>'GZP'],
        ['name'=>'Gonda','code'=>'GND'],['name'=>'Gorakhpur','code'=>'GKP'],
        ['name'=>'Hamirpur','code'=>'HMP'],['name'=>'Hapur','code'=>'HPR'],
        ['name'=>'Hardoi','code'=>'HRD'],['name'=>'Hathras','code'=>'HTH'],
        ['name'=>'Jalaun','code'=>'JLN'],['name'=>'Jaunpur','code'=>'JNP'],
        ['name'=>'Jhansi','code'=>'JHS'],['name'=>'Kannauj','code'=>'KNJ'],
        ['name'=>'Kanpur Dehat','code'=>'KPD'],['name'=>'Kanpur Nagar','code'=>'KPN'],
        ['name'=>'Kasganj','code'=>'KSJ'],['name'=>'Kaushambi','code'=>'KSB'],
        ['name'=>'Kheri','code'=>'KHR'],['name'=>'Kushinagar','code'=>'KSN'],
        ['name'=>'Lalitpur','code'=>'LPR'],['name'=>'Lucknow','code'=>'LKO'],
        ['name'=>'Maharajganj','code'=>'MHJ'],['name'=>'Mahoba','code'=>'MHB'],
        ['name'=>'Mainpuri','code'=>'MNP'],['name'=>'Mathura','code'=>'MTH'],
        ['name'=>'Mau','code'=>'MAU'],['name'=>'Meerut','code'=>'MRT'],
        ['name'=>'Mirzapur','code'=>'MZP'],['name'=>'Moradabad','code'=>'MRD'],
        ['name'=>'Muzaffarnagar','code'=>'MZN'],['name'=>'Pilibhit','code'=>'PLB'],
        ['name'=>'Pratapgarh','code'=>'PTG'],['name'=>'Raebareli','code'=>'RBL'],
        ['name'=>'Rampur','code'=>'RMP'],['name'=>'Saharanpur','code'=>'SHR'],
        ['name'=>'Sambhal','code'=>'SMB'],['name'=>'Sant Kabir Nagar','code'=>'SKN'],
        ['name'=>'Shahjahanpur','code'=>'SJP'],['name'=>'Shamli','code'=>'SML'],
        ['name'=>'Shravasti','code'=>'SRV'],['name'=>'Siddharthnagar','code'=>'SDN'],
        ['name'=>'Sitapur','code'=>'STP'],['name'=>'Sonbhadra','code'=>'SBD'],
        ['name'=>'Sultanpur','code'=>'SLT'],['name'=>'Unnao','code'=>'UNO'],
        ['name'=>'Varanasi','code'=>'VNS'],['name'=>'Sant Ravidas Nagar','code'=>'SRN'],
        ['name'=>'Amroha','code'=>'AMR'],['name'=>'Baghpat','code'=>'BGP'],
        ['name'=>'Bahraich','code'=>'BHR'],['name'=>'Ballia','code'=>'BLL'],
        ['name'=>'Balrampur','code'=>'BLP'],
    ];

    public function run(): void
    {
        foreach ($this->districts as $d) {
            District::updateOrCreate(['code' => $d['code']], array_merge($d, ['state' => 'Uttar Pradesh', 'is_active' => true]));
        }
        $this->command->info('Districts seeded: ' . count($this->districts));
    }
}
