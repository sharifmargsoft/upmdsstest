<?php

namespace Database\Seeders;

use App\Models\Role;
use App\Models\District;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

/**
 * Standalone seeder — seeds roles and permissions only.
 * Called by DatabaseSeeder and directly in tests.
 */
class RolePermissionSeeder extends Seeder
{
    private array $permissions = [
        // Dashboard
        ['name' => 'dashboard.view',              'module' => 'dashboard'],
        ['name' => 'dashboard.map.view',           'module' => 'dashboard'],
        ['name' => 'dashboard.analysis.view',      'module' => 'dashboard'],
        // Checkgate
        ['name' => 'checkgate.activity.view',      'module' => 'checkgate'],
        ['name' => 'checkgate.activity.review',    'module' => 'checkgate'],
        ['name' => 'checkgate.activity.ignore',    'module' => 'checkgate'],
        ['name' => 'checkgate.notice.generate',    'module' => 'checkgate'],
        ['name' => 'checkgate.report.view',        'module' => 'checkgate'],
        // mCHECK
        ['name' => 'mcheck.activity.view',         'module' => 'mcheck'],
        ['name' => 'mcheck.notice.generate',       'module' => 'mcheck'],
        ['name' => 'mcheck.report.view',           'module' => 'mcheck'],
        // Weighbridge
        ['name' => 'weighbridge.view',             'module' => 'weighbridge'],
        ['name' => 'weighbridge.notice.generate',  'module' => 'weighbridge'],
        // Notice
        ['name' => 'notice.view',                  'module' => 'notice'],
        ['name' => 'notice.cancel',                'module' => 'notice'],
        ['name' => 'notice.reactivate',            'module' => 'notice'],
        ['name' => 'notice.pay',                   'module' => 'notice'],
        // Master
        ['name' => 'master.template.manage',       'module' => 'master'],
        // Users
        ['name' => 'user.view',                    'module' => 'user'],
        ['name' => 'user.create',                  'module' => 'user'],
        ['name' => 'user.edit',                    'module' => 'user'],
        ['name' => 'user.deactivate',              'module' => 'user'],
        // MINETag
        ['name' => 'minetag.view',                 'module' => 'minetag'],
        ['name' => 'minetag.manage',               'module' => 'minetag'],
        // Blacklist
        ['name' => 'blacklist.view',               'module' => 'blacklist'],
        ['name' => 'blacklist.add',                'module' => 'blacklist'],
        ['name' => 'blacklist.remove',             'module' => 'blacklist'],
        // Assign
        ['name' => 'assign.create',                'module' => 'assign'],
        ['name' => 'assign.view',                  'module' => 'assign'],
        // Reports
        ['name' => 'report.view',                  'module' => 'report'],
        ['name' => 'report.export',                'module' => 'report'],
        // Utility
        ['name' => 'utility.login_log.view',       'module' => 'utility'],
        ['name' => 'utility.etp.verify',           'module' => 'utility'],
        ['name' => 'utility.geo.view',             'module' => 'utility'],
    ];

    private array $roles = [
        ['name' => 'super_admin',       'display_name' => 'Super Administrator',        'is_system' => true],
        ['name' => 'state_admin',       'display_name' => 'State Admin',                'is_system' => true],
        ['name' => 'dmo',               'display_name' => 'District Mining Officer',    'is_system' => false],
        ['name' => 'inspector',         'display_name' => 'Mining Inspector',           'is_system' => false],
        ['name' => 'tse',               'display_name' => 'Technical Support Engineer', 'is_system' => false],
        ['name' => 'checkgate_incharge','display_name' => 'Checkgate Incharge',         'is_system' => false],
        ['name' => 'report_viewer',     'display_name' => 'Report Viewer',              'is_system' => false],
    ];

    public function run(): void
    {
        // Seed permissions
        foreach ($this->permissions as $perm) {
            \Spatie\Permission\Models\Permission::updateOrCreate(
                ['name' => $perm['name'], 'guard_name' => 'sanctum'],
                ['module' => $perm['module']]
            );
        }

        // Seed roles
        foreach ($this->roles as $roleData) {
            $role = \Spatie\Permission\Models\Role::updateOrCreate(
                ['name' => $roleData['name'], 'guard_name' => 'sanctum'],
                ['display_name' => $roleData['display_name'], 'is_system' => $roleData['is_system']]
            );
        }

        // Assign permissions to roles
        $this->assignPermissions();

        // Clear permission cache
        app()[\Spatie\Permission\PermissionRegistrar::class]->forgetCachedPermissions();
    }

    private function assignPermissions(): void
    {
        $allPerms = \Spatie\Permission\Models\Permission::where('guard_name', 'sanctum')
            ->pluck('name')->toArray();

        // Super admin gets everything
        \Spatie\Permission\Models\Role::where('name', 'super_admin')
            ->first()
            ?->syncPermissions($allPerms);

        // State admin: all except user.deactivate
        \Spatie\Permission\Models\Role::where('name', 'state_admin')
            ->first()
            ?->syncPermissions(array_filter($allPerms, fn($p) => $p !== 'user.deactivate'));

        // DMO: district-level operations
        \Spatie\Permission\Models\Role::where('name', 'dmo')
            ->first()
            ?->syncPermissions([
                'dashboard.view','dashboard.map.view','dashboard.analysis.view',
                'checkgate.activity.view','checkgate.activity.review',
                'checkgate.notice.generate','checkgate.report.view',
                'mcheck.activity.view','mcheck.notice.generate','mcheck.report.view',
                'weighbridge.view','weighbridge.notice.generate',
                'notice.view','notice.cancel','notice.reactivate','notice.pay',
                'blacklist.view','blacklist.add','blacklist.remove',
                'assign.create','assign.view',
                'report.view','report.export',
                'utility.etp.verify','utility.geo.view',
                'minetag.view','user.view',
            ]);

        // TSE: review cases
        \Spatie\Permission\Models\Role::where('name', 'tse')
            ->first()
            ?->syncPermissions([
                'dashboard.view',
                'checkgate.activity.view','checkgate.activity.review','checkgate.activity.ignore',
                'notice.view',
                'utility.etp.verify',
            ]);

        // Inspector: mCHECK operations
        \Spatie\Permission\Models\Role::where('name', 'inspector')
            ->first()
            ?->syncPermissions([
                'dashboard.view',
                'mcheck.activity.view','mcheck.notice.generate',
                'notice.view',
                'utility.etp.verify',
            ]);

        // Checkgate incharge: view only
        \Spatie\Permission\Models\Role::where('name', 'checkgate_incharge')
            ->first()
            ?->syncPermissions([
                'dashboard.view',
                'checkgate.activity.view','checkgate.report.view',
                'notice.view',
            ]);

        // Report viewer: reports only
        \Spatie\Permission\Models\Role::where('name', 'report_viewer')
            ->first()
            ?->syncPermissions([
                'dashboard.view','dashboard.analysis.view',
                'report.view',
            ]);
    }
}
