<?php

namespace Database\Seeders;

use App\Models\District;
use App\Models\Role;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([
            RolePermissionSeeder::class,
            DistrictSeeder::class,
            MineralSeeder::class,
            CheckgateSeeder::class,
            UserSeeder::class,
            NoticeTemplateSeeder::class,
        ]);
    }
}
