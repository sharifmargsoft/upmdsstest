<?php

namespace Database\Seeders;

use App\Models\NoticeTemplate;
use Illuminate\Database\Seeder;

class NoticeTemplateSeeder extends Seeder
{
    public function run(): void
    {
        NoticeTemplate::updateOrCreate(['name' => 'Standard eTP Violation Notice'], [
            'template_type' => 'general',
            'subject'       => 'e-Notice for Illegal Mineral Transportation — {{notice_number}}',
            'body_html'     => '<p>Vehicle <strong>{{vehicle_number}}</strong> was found transporting mineral without valid eTP.</p><p>Penalty: Rs. {{penalty_amount}}</p>',
            'is_active'     => true,
        ]);

        NoticeTemplate::updateOrCreate(['name' => 'Weighbridge Overload Notice'], [
            'template_type' => 'weighment',
            'subject'       => 'e-Notice for Vehicle Overloading — {{notice_number}}',
            'body_html'     => '<p>Vehicle <strong>{{vehicle_number}}</strong> was found overloaded at weighbridge.</p><p>Overload: {{overload_pct}}%</p><p>Penalty: Rs. {{penalty_amount}}</p>',
            'is_active'     => true,
        ]);

        NoticeTemplate::updateOrCreate(['name' => 'mCHECK Inspection Notice'], [
            'template_type' => 'mcheck',
            'subject'       => 'e-Notice from Field Inspection — {{notice_number}}',
            'body_html'     => '<p>Vehicle <strong>{{vehicle_number}}</strong> was found in violation during field inspection.</p><p>Penalty: Rs. {{penalty_amount}}</p>',
            'is_active'     => true,
        ]);

        $this->command->info('Notice templates seeded: 3');
    }
}
