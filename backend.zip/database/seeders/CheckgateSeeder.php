<?php

namespace Database\Seeders;

use App\Models\Checkgate;
use App\Models\District;
use Illuminate\Database\Seeder;

class CheckgateSeeder extends Seeder
{
    public function run(): void
    {
        $gates = [
            ['dc'=>'MZP','name'=>'Mirzapur Highway Gate','code'=>'MZP-CG-01','lat'=>25.1447,'lng'=>82.5687],
            ['dc'=>'VNS','name'=>'Varanasi NH-31 Gate','code'=>'VNS-CG-01','lat'=>25.3176,'lng'=>82.9739],
            ['dc'=>'SBD','name'=>'Sonbhadra Checkgate','code'=>'SBD-CG-01','lat'=>24.6871,'lng'=>83.0715],
            ['dc'=>'AGR','name'=>'Agra Bypass Gate','code'=>'AGR-CG-01','lat'=>27.1767,'lng'=>78.0081],
            ['dc'=>'GKP','name'=>'Gorakhpur Entry Gate','code'=>'GKP-CG-01','lat'=>26.7606,'lng'=>83.3732],
            ['dc'=>'ALD','name'=>'Prayagraj NH Gate','code'=>'ALD-CG-01','lat'=>25.4358,'lng'=>81.8463],
            ['dc'=>'LKO','name'=>'Lucknow Outer Ring Gate','code'=>'LKO-CG-01','lat'=>26.8467,'lng'=>80.9462],
            ['dc'=>'KPN','name'=>'Kanpur NH-91 Gate','code'=>'KPN-CG-01','lat'=>26.4499,'lng'=>80.3319],
            ['dc'=>'MRT','name'=>'Meerut Highway Gate','code'=>'MRT-CG-01','lat'=>28.9845,'lng'=>77.7064],
            ['dc'=>'GZB','name'=>'Ghaziabad Entry Gate','code'=>'GZB-CG-01','lat'=>28.6692,'lng'=>77.4538],
        ];

        foreach ($gates as $g) {
            $district = District::where('code', $g['dc'])->first();
            if ($district) {
                Checkgate::updateOrCreate(['code' => $g['code']], [
                    'district_id'  => $district->id,
                    'name'         => $g['name'],
                    'code'         => $g['code'],
                    'latitude'     => $g['lat'],
                    'longitude'    => $g['lng'],
                    'status'       => 'active',
                    'installed_on' => '2021-09-01',
                ]);
            }
        }
        $this->command->info('Checkgates seeded: ' . count($gates));
    }
}
