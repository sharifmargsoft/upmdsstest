<?php

namespace Database\Seeders;

use App\Models\District;
use App\Models\Role;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    public function run(): void
    {
        $superAdminRole = Role::where('name','super_admin')->first();
        $stateAdminRole = Role::where('name','state_admin')->first();
        $dmoRole        = Role::where('name','dmo')->first();
        $tseRole        = Role::where('name','tse')->first();
        $inspectorRole  = Role::where('name','inspector')->first();

        $lucknow  = District::where('code','LKO')->first();
        $mirzapur = District::where('code','MZP')->first();

        $users = [
            ['username'=>'superadmin','name'=>'System Administrator','email'=>'admin@upmdss.in','mobile'=>'9000000001','designation'=>'System Administrator','role'=>$superAdminRole,'district'=>null],
            ['username'=>'stateadmin','name'=>'State Admin User','email'=>'stateadmin@upmdss.in','mobile'=>'9000000002','designation'=>'State Level Administrator','role'=>$stateAdminRole,'district'=>null],
            ['username'=>'dmo_lko','name'=>'Rajesh Kumar Singh','email'=>'dmo.lko@upmdss.in','mobile'=>'9000000003','designation'=>'District Mining Officer','role'=>$dmoRole,'district'=>$lucknow],
            ['username'=>'tse_01','name'=>'Amit Sharma','email'=>'tse01@upmdss.in','mobile'=>'9000000004','designation'=>'Technical Support Engineer','role'=>$tseRole,'district'=>null],
            ['username'=>'insp_mzp','name'=>'Suresh Yadav','email'=>'inspector.mzp@upmdss.in','mobile'=>'9000000005','designation'=>'Mining Inspector','role'=>$inspectorRole,'district'=>$mirzapur],
        ];

        foreach ($users as $u) {
            if (!$u['role']) continue;
            $user = User::updateOrCreate(['username'=>$u['username']], [
                'name'           => $u['name'],
                'username'       => $u['username'],
                'email'          => $u['email'],
                'mobile'         => $u['mobile'],
                'password'       => Hash::make('Admin@123'),
                'designation'    => $u['designation'],
                'role_id'        => $u['role']->id,
                'district_id'    => $u['district']?->id,
                'is_active'      => true,
                'is_mcheck_user' => $u['username'] === 'insp_mzp',
            ]);
            $user->syncRoles([$u['role']->name]);
        }
        $this->command->info('Users seeded: ' . count($users));
    }
}
