<?php
// =============================================================================
// FILE: database/migrations/2024_01_01_000004_create_vehicles_and_activities.php
// =============================================================================
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

return new class extends Migration
{
    public function up(): void
    {
        // ── Vehicles cache table ──────────────────────────────────────────────
        Schema::create('vehicles', function (Blueprint $table) {
            $table->id();
            $table->string('vehicle_number', 20);
            $table->string('vehicle_number_norm', 20)->unique();  // uppercase, no spaces
            $table->jsonb('vahan_data')->default('{}');
            $table->string('owner_name', 200)->nullable();
            $table->string('vehicle_class', 80)->nullable();
            $table->decimal('gross_weight', 10, 2)->nullable();
            $table->string('registered_state', 80)->nullable();
            $table->boolean('is_blacklisted')->default(false);
            $table->timestampTz('blacklisted_at')->nullable();
            $table->timestampTz('vahan_fetched_at')->nullable();
            $table->timestampsTz();
        });

        DB::statement('CREATE INDEX idx_vehicles_trgm ON vehicles USING GIN (vehicle_number_norm gin_trgm_ops)');
        DB::statement('CREATE INDEX idx_vehicles_blacklisted ON vehicles(is_blacklisted) WHERE is_blacklisted = TRUE');

        // ── MINETag table ─────────────────────────────────────────────────────
        Schema::create('mine_tags', function (Blueprint $table) {
            $table->id();
            $table->string('tag_id', 50)->unique();
            $table->foreignId('vehicle_id')->nullable()->constrained('vehicles')->nullOnDelete();
            $table->string('vehicle_number', 20)->nullable();
            $table->string('status', 20)->default('active');
            $table->date('issued_on')->nullable();
            $table->unsignedInteger('issued_by_district_id')->nullable();
            $table->text('remarks')->nullable();
            $table->timestampTz('last_seen_at')->nullable();
            $table->unsignedBigInteger('last_seen_checkgate_id')->nullable();
            $table->timestampsTz();

            $table->index(['vehicle_id']);
            $table->index(['status']);
        });

        // ── Checkgate activities — PARTITIONED BY MONTH ───────────────────────
        DB::statement("
            CREATE TABLE checkgate_activities (
                id                      BIGSERIAL,
                uuid                    UUID DEFAULT uuid_generate_v4(),
                checkgate_id            INTEGER NOT NULL REFERENCES checkgates(id),
                district_id             INTEGER NOT NULL REFERENCES districts(id),

                vehicle_number_anpr     VARCHAR(20),
                vehicle_number_minetag  VARCHAR(20),
                vehicle_number_reported VARCHAR(20),
                vehicle_number_norm     VARCHAR(20),

                mine_tag_id             VARCHAR(50),
                minetag_installed       BOOLEAN DEFAULT FALSE,

                etp_number              VARCHAR(80),
                etp_status              VARCHAR(30) CHECK (etp_status IN ('valid','expired','without_etp','bogus','duplicate','mismatch','bypass')),
                etp_data                JSONB DEFAULT '{}',

                vahan_vehicle_class     VARCHAR(80),
                vahan_gross_weight      NUMERIC(10,2),
                vahan_data              JSONB DEFAULT '{}',

                mineral_id              INTEGER REFERENCES minerals(id),
                mineral_name            VARCHAR(100),
                mineral_confidence      NUMERIC(5,2),

                weight_vahan            NUMERIC(10,2),
                weight_etp_declared     NUMERIC(10,2),
                weight_actual           NUMERIC(10,2),
                weight_tolerance_pct    NUMERIC(5,2) DEFAULT 10.0,
                is_overloaded           BOOLEAN DEFAULT FALSE,
                overload_pct            NUMERIC(6,2),

                crossing_at             TIMESTAMPTZ NOT NULL,
                crossing_direction      VARCHAR(10) DEFAULT 'outbound',
                location_name           VARCHAR(200),

                anpr_image_url          TEXT,
                vehicle_image_url       TEXT,
                video_url               TEXT,
                raw_evidence_data       JSONB DEFAULT '{}',

                flag_type               VARCHAR(30) DEFAULT 'valid' CHECK (
                    flag_type IN ('valid','expired_etp','without_etp','bogus_etp','duplicate_etp',
                        'mismatch','overload','no_minetag','obscured_plate','bypass','volume_mismatch')
                ),
                flag_details            JSONB DEFAULT '{}',

                status                  VARCHAR(30) DEFAULT 'reported' CHECK (
                    status IN ('reported','under_review','pending_notice','notice_sent','ignored','closed')
                ),
                tse_reviewed_by         BIGINT REFERENCES users(id),
                tse_reviewed_at         TIMESTAMPTZ,
                tse_remarks             TEXT,
                ignored_reason          TEXT,
                ignored_by              BIGINT REFERENCES users(id),
                ignored_at              TIMESTAMPTZ,
                notice_id               BIGINT,

                created_at              TIMESTAMPTZ DEFAULT NOW(),
                updated_at              TIMESTAMPTZ DEFAULT NOW(),

                PRIMARY KEY (id, crossing_at)
            ) PARTITION BY RANGE (crossing_at)
        ");

        // Create monthly partitions for 3 years
        $start = Carbon::create(2024, 1, 1);
        $end   = Carbon::create(2027, 1, 1);
        $cur   = $start->copy();

        while ($cur->lt($end)) {
            $next   = $cur->copy()->addMonth();
            $suffix = $cur->format('Y_m');
            DB::statement("
                CREATE TABLE checkgate_activities_{$suffix}
                PARTITION OF checkgate_activities
                FOR VALUES FROM ('{$cur->toDateString()}') TO ('{$next->toDateString()}')
            ");
            $cur->addMonth();
        }

        // Indexes on parent (automatically propagate to partitions in PG11+)
        DB::statement("CREATE INDEX idx_ca_checkgate   ON checkgate_activities(checkgate_id, crossing_at)");
        DB::statement("CREATE INDEX idx_ca_district    ON checkgate_activities(district_id, crossing_at)");
        DB::statement("CREATE INDEX idx_ca_status      ON checkgate_activities(status, crossing_at)");
        DB::statement("CREATE INDEX idx_ca_flag        ON checkgate_activities(flag_type, crossing_at)");
        DB::statement("CREATE INDEX idx_ca_vehicle     ON checkgate_activities(vehicle_number_norm, crossing_at)");
        DB::statement("CREATE INDEX idx_ca_notice      ON checkgate_activities(notice_id) WHERE notice_id IS NOT NULL");
    }

    public function down(): void
    {
        DB::statement("DROP TABLE IF EXISTS checkgate_activities CASCADE");
        Schema::dropIfExists('mine_tags');
        Schema::dropIfExists('vehicles');
    }
};
