<?php
// =============================================================================
// FILE: database/migrations/2024_01_01_000003_create_users_tables.php
// =============================================================================
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique()->default(\DB::raw('uuid_generate_v4()'));
            $table->string('name', 150);
            $table->string('username', 80)->unique();
            $table->string('email', 180)->unique()->nullable();
            $table->string('mobile', 15)->nullable();
            $table->string('password', 255);
            $table->string('designation', 150)->nullable();
            $table->string('employee_id', 50)->nullable();
            $table->foreignId('role_id')->constrained('roles');
            $table->foreignId('district_id')->nullable()->constrained('districts')->nullOnDelete();
            $table->boolean('is_active')->default(true);
            $table->boolean('is_mcheck_user')->default(false);
            $table->timestampTz('last_login_at')->nullable();
            $table->ipAddress('last_login_ip')->nullable();
            $table->timestampTz('email_verified_at')->nullable();
            $table->rememberToken();
            $table->unsignedBigInteger('created_by')->nullable();
            $table->softDeletesTz();
            $table->timestampsTz();

            $table->index(['role_id']);
            $table->index(['district_id']);
            $table->index(['is_active']);
        });

        Schema::create('user_checkgates', function (Blueprint $table) {
            $table->foreignId('user_id')->constrained('users')->onDelete('cascade');
            $table->foreignId('checkgate_id')->constrained('checkgates')->onDelete('cascade');
            $table->timestampTz('assigned_at')->default(\DB::raw('NOW()'));
            $table->primary(['user_id', 'checkgate_id']);
        });

        Schema::create('personal_access_tokens', function (Blueprint $table) {
            $table->id();
            $table->morphs('tokenable');
            $table->string('name');
            $table->string('token', 64)->unique();
            $table->text('abilities')->nullable();
            $table->timestampTz('last_used_at')->nullable();
            $table->timestampTz('expires_at')->nullable();
            $table->timestampsTz();
        });

        // Partitioned login_logs — create parent + initial partitions
        \DB::statement("
            CREATE TABLE IF NOT EXISTS login_logs (
                id          BIGSERIAL,
                user_id     BIGINT REFERENCES users(id) ON DELETE SET NULL,
                username_attempt VARCHAR(100),
                ip_address  INET,
                user_agent  TEXT,
                status      VARCHAR(20) DEFAULT 'success' CHECK (status IN ('success','failed','blocked')),
                failure_reason VARCHAR(200),
                session_id  VARCHAR(100),
                logged_in_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
                logged_out_at TIMESTAMPTZ,
                PRIMARY KEY (id, logged_in_at)
            ) PARTITION BY RANGE (logged_in_at)
        ");

        $currentYear = date('Y');
        for ($y = $currentYear; $y <= $currentYear + 2; $y++) {
            \DB::statement("
                CREATE TABLE IF NOT EXISTS login_logs_{$y}
                PARTITION OF login_logs
                FOR VALUES FROM ('{$y}-01-01') TO ('" . ($y + 1) . "-01-01')
            ");
        }

        \DB::statement("CREATE INDEX IF NOT EXISTS idx_login_logs_user ON login_logs(user_id, logged_in_at)");
        \DB::statement("CREATE INDEX IF NOT EXISTS idx_login_logs_status ON login_logs(status, logged_in_at)");
    }

    public function down(): void
    {
        \DB::statement("DROP TABLE IF EXISTS login_logs CASCADE");
        Schema::dropIfExists('personal_access_tokens');
        Schema::dropIfExists('user_checkgates');
        Schema::dropIfExists('users');
    }
};
