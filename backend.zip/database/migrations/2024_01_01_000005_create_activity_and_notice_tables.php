<?php
// =============================================================================
// FILE: database/migrations/2024_01_01_000005_create_activity_and_notice_tables.php
// =============================================================================
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        // ── mCHECK Activities ─────────────────────────────────────────────────
        Schema::create('mcheck_activities', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique()->default(DB::raw('uuid_generate_v4()'));
            $table->foreignId('inspector_id')->constrained('users');
            $table->foreignId('district_id')->constrained('districts');
            $table->string('vehicle_number', 20)->nullable();
            $table->string('vehicle_number_norm', 20)->nullable();
            $table->string('mine_tag_id', 50)->nullable();
            $table->string('etp_number', 80)->nullable();
            $table->string('etp_status', 30)->nullable();
            $table->jsonb('etp_data')->default('{}');
            $table->foreignId('mineral_id')->nullable()->constrained('minerals')->nullOnDelete();
            $table->string('mineral_name', 100)->nullable();
            $table->decimal('inspection_lat', 10, 7)->nullable();
            $table->decimal('inspection_lng', 10, 7)->nullable();
            $table->text('inspection_address')->nullable();
            $table->string('offense_type', 50)->nullable();
            $table->text('offense_details')->nullable();
            $table->jsonb('evidence_photos')->default('[]');
            $table->text('remarks')->nullable();
            $table->string('status', 30)->default('reported');
            $table->unsignedBigInteger('notice_id')->nullable();
            $table->string('device_id', 100)->nullable();
            $table->string('app_version', 20)->nullable();
            $table->timestampTz('inspected_at');
            $table->timestampsTz();

            $table->index(['inspector_id', 'inspected_at']);
            $table->index(['district_id', 'inspected_at']);
            $table->index(['vehicle_number_norm']);
            $table->index(['status']);
        });

        Schema::create('mcheck_login_logs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users');
            $table->string('device_id', 100)->nullable();
            $table->string('app_version', 20)->nullable();
            $table->timestampTz('login_at')->default(DB::raw('NOW()'));
            $table->timestampTz('logout_at')->nullable();
            $table->unsignedInteger('session_duration')->nullable();
            $table->ipAddress('ip_address')->nullable();

            $table->index(['user_id', 'login_at']);
        });

        // ── Weighbridge Activities ────────────────────────────────────────────
        Schema::create('weighbridge_activities', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique()->default(DB::raw('uuid_generate_v4()'));
            $table->foreignId('weighbridge_id')->constrained('weighbridges');
            $table->foreignId('district_id')->constrained('districts');
            $table->string('vehicle_number', 20)->nullable();
            $table->string('vehicle_number_norm', 20)->nullable();
            $table->string('etp_number', 80)->nullable();
            $table->string('emm11_number', 80)->nullable();
            $table->jsonb('etp_data')->default('{}');
            $table->foreignId('mineral_id')->nullable()->constrained('minerals')->nullOnDelete();
            $table->string('mineral_name', 100)->nullable();
            $table->decimal('weight_permitted', 10, 2)->nullable();
            $table->decimal('weight_declared', 10, 2)->nullable();
            $table->decimal('weight_actual', 10, 2)->nullable();
            $table->decimal('weight_tolerance_pct', 5, 2)->default(10.0);
            $table->boolean('is_overloaded')->default(false);
            $table->decimal('overload_pct', 6, 2)->nullable();
            $table->decimal('volume_mismatch_pct', 6, 2)->nullable();
            $table->string('anomaly_type', 50)->default('none');
            $table->boolean('has_emm11')->default(true);
            $table->string('status', 30)->default('valid');
            $table->unsignedBigInteger('notice_id')->nullable();
            $table->timestampTz('weighed_at');
            $table->timestampsTz();

            $table->index(['weighbridge_id', 'weighed_at']);
            $table->index(['district_id', 'weighed_at']);
            $table->index(['anomaly_type']);
            $table->index(['is_overloaded']);
        });

        // ── Notice Templates ──────────────────────────────────────────────────
        Schema::create('notice_templates', function (Blueprint $table) {
            $table->id();
            $table->string('name', 150);
            $table->string('template_type', 30);
            $table->string('subject', 300)->nullable();
            $table->longText('body_html');
            $table->boolean('is_active')->default(true);
            $table->unsignedInteger('version')->default(1);
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestampsTz();
        });

        // ── E-Notices ─────────────────────────────────────────────────────────
        Schema::create('e_notices', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique()->default(DB::raw('uuid_generate_v4()'));
            $table->string('notice_number', 50)->unique();
            $table->foreignId('notice_template_id')->nullable()->constrained('notice_templates')->nullOnDelete();

            $table->string('source_type', 20);
            $table->unsignedBigInteger('source_id');
            $table->foreignId('district_id')->constrained('districts');
            $table->foreignId('issued_by')->constrained('users');

            $table->string('vehicle_number', 20);
            $table->string('vehicle_number_norm', 20);
            $table->string('vehicle_owner_name', 200)->nullable();
            $table->string('vehicle_owner_mobile', 15)->nullable();

            $table->string('offense_type', 60);
            $table->text('offense_description')->nullable();
            $table->date('offense_date');
            $table->string('offense_location', 300)->nullable();
            $table->string('mineral_name', 100)->nullable();
            $table->string('etp_number', 80)->nullable();

            $table->decimal('penalty_amount', 12, 2)->default(0);
            $table->decimal('paid_amount', 12, 2)->default(0);
            // pending_amount computed: penalty - paid (use DB view or accessor)

            $table->string('status', 30)->default('issued');
            $table->timestampTz('issued_at')->default(DB::raw('NOW()'));
            $table->date('due_date')->nullable();
            $table->timestampTz('paid_at')->nullable();
            $table->timestampTz('cancelled_at')->nullable();
            $table->text('cancellation_reason')->nullable();
            $table->foreignId('cancelled_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestampTz('reactivated_at')->nullable();
            $table->foreignId('reactivated_by')->nullable()->constrained('users')->nullOnDelete();

            $table->string('rajkosh_challan_no', 100)->nullable();
            $table->string('payment_gateway', 50)->nullable();
            $table->string('payment_reference', 100)->nullable();
            $table->jsonb('payment_gateway_response')->default('{}');

            $table->jsonb('evidence_urls')->default('[]');
            $table->text('notice_pdf_url')->nullable();
            $table->timestampTz('sms_sent_at')->nullable();
            $table->timestampTz('email_sent_at')->nullable();
            $table->timestampTz('portal_sent_at')->nullable();

            $table->unsignedBigInteger('parent_notice_id')->nullable();
            $table->timestampsTz();

            $table->index(['district_id', 'issued_at']);
            $table->index(['vehicle_number_norm']);
            $table->index(['status', 'issued_at']);
            $table->index(['source_type', 'source_id']);
        });

        // Add FK for notice_id back-references in activities
        DB::statement("
            ALTER TABLE checkgate_activities
            ADD CONSTRAINT fk_ca_notice
            FOREIGN KEY (notice_id) REFERENCES e_notices(id)
            ON DELETE SET NULL
            NOT VALID
        ");

        // Notice audit log
        Schema::create('notice_audit_logs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('notice_id')->constrained('e_notices')->onDelete('cascade');
            $table->string('action', 50);
            $table->string('from_status', 30)->nullable();
            $table->string('to_status', 30)->nullable();
            $table->text('remarks')->nullable();
            $table->foreignId('performed_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestampTz('performed_at')->default(DB::raw('NOW()'));
            $table->jsonb('metadata')->default('{}');

            $table->index(['notice_id', 'performed_at']);
        });

        // ── Vehicle Blacklist ─────────────────────────────────────────────────
        Schema::create('vehicle_blacklists', function (Blueprint $table) {
            $table->id();
            $table->foreignId('vehicle_id')->nullable()->constrained('vehicles')->nullOnDelete();
            $table->string('vehicle_number', 20);
            $table->string('vehicle_number_norm', 20);
            $table->foreignId('district_id')->nullable()->constrained('districts')->nullOnDelete();
            $table->text('reason');
            $table->foreignId('blacklisted_by')->constrained('users');
            $table->timestampTz('blacklisted_at')->default(DB::raw('NOW()'));
            $table->date('valid_from');
            $table->date('valid_to')->nullable();
            $table->jsonb('reference_notice_ids')->default('[]');
            $table->string('status', 20)->default('active');
            $table->foreignId('removed_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestampTz('removed_at')->nullable();
            $table->text('removal_reason')->nullable();
            $table->string('removal_order_ref', 100)->nullable();
            $table->timestampsTz();

            $table->index(['vehicle_number_norm', 'status']);
            $table->index(['district_id', 'status']);
        });

        // ── Case Assignments ──────────────────────────────────────────────────
        Schema::create('case_assignments', function (Blueprint $table) {
            $table->id();
            $table->string('source_type', 20);
            $table->unsignedBigInteger('source_id');
            $table->foreignId('assigned_to')->constrained('users');
            $table->foreignId('assigned_by')->constrained('users');
            $table->foreignId('district_id')->nullable()->constrained('districts')->nullOnDelete();
            $table->date('due_date')->nullable();
            $table->string('priority', 20)->default('normal');
            $table->string('status', 20)->default('open');
            $table->text('remarks')->nullable();
            $table->text('completion_note')->nullable();
            $table->timestampTz('completed_at')->nullable();
            $table->timestampsTz();

            $table->index(['assigned_to', 'status']);
            $table->index(['district_id', 'status']);
            $table->index(['source_type', 'source_id']);
        });

        // ── Materialized View for Dashboard ──────────────────────────────────
        DB::statement("
            CREATE MATERIALIZED VIEW IF NOT EXISTS mv_dashboard_summary AS
            SELECT
                d.id                                        AS district_id,
                d.name                                      AS district_name,
                COUNT(DISTINCT ca.id)                       AS violations_30d,
                COUNT(DISTINCT en.id)                       AS notices_total,
                COUNT(DISTINCT en.id) FILTER (WHERE en.status = 'paid') AS notices_paid,
                COALESCE(SUM(en.penalty_amount), 0)         AS penalty_total,
                COALESCE(SUM(en.paid_amount), 0)            AS penalty_recovered,
                COALESCE(SUM(en.penalty_amount - en.paid_amount), 0) AS penalty_pending,
                COUNT(DISTINCT vb.id) FILTER (WHERE vb.status = 'active') AS blacklisted_vehicles,
                NOW()                                       AS refreshed_at
            FROM districts d
            LEFT JOIN checkgate_activities ca ON ca.district_id = d.id
                AND ca.crossing_at >= NOW() - INTERVAL '30 days'
                AND ca.flag_type != 'valid'
            LEFT JOIN e_notices en ON en.district_id = d.id
            LEFT JOIN vehicle_blacklists vb ON vb.district_id = d.id
            GROUP BY d.id, d.name
        ");

        DB::statement("CREATE UNIQUE INDEX IF NOT EXISTS idx_mv_dashboard ON mv_dashboard_summary(district_id)");
    }

    public function down(): void
    {
        DB::statement("DROP MATERIALIZED VIEW IF EXISTS mv_dashboard_summary");
        Schema::dropIfExists('case_assignments');
        Schema::dropIfExists('vehicle_blacklists');
        Schema::dropIfExists('notice_audit_logs');
        Schema::dropIfExists('e_notices');
        Schema::dropIfExists('notice_templates');
        Schema::dropIfExists('weighbridge_activities');
        Schema::dropIfExists('mcheck_login_logs');
        Schema::dropIfExists('mcheck_activities');
    }
};
