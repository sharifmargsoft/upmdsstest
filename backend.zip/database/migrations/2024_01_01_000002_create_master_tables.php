<?php
// =============================================================================
// FILE: database/migrations/2024_01_01_000002_create_master_tables.php
// =============================================================================
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('districts', function (Blueprint $table) {
            $table->id();
            $table->string('name', 100);
            $table->string('code', 20)->unique();
            $table->string('state', 50)->default('Uttar Pradesh');
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        Schema::create('minerals', function (Blueprint $table) {
            $table->id();
            $table->string('name', 100);
            $table->string('code', 20)->unique();
            $table->string('unit', 20)->default('MT');
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        Schema::create('checkgates', function (Blueprint $table) {
            $table->id();
            $table->foreignId('district_id')->constrained('districts');
            $table->string('name', 150);
            $table->string('code', 30)->unique();
            $table->string('location_name', 200)->nullable();
            $table->decimal('latitude', 10, 7)->nullable();
            $table->decimal('longitude', 10, 7)->nullable();
            $table->string('highway_name', 100)->nullable();
            $table->string('status', 20)->default('active');
            $table->date('installed_on')->nullable();
            $table->jsonb('hardware_config')->default('{}');
            $table->timestamps();

            $table->index(['district_id']);
            $table->index(['status']);
        });

        Schema::create('weighbridges', function (Blueprint $table) {
            $table->id();
            $table->foreignId('district_id')->constrained('districts');
            $table->string('name', 150);
            $table->string('code', 30)->unique();
            $table->string('location_name', 200)->nullable();
            $table->decimal('latitude', 10, 7)->nullable();
            $table->decimal('longitude', 10, 7)->nullable();
            $table->string('operator_name', 100)->nullable();
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('weighbridges');
        Schema::dropIfExists('checkgates');
        Schema::dropIfExists('minerals');
        Schema::dropIfExists('districts');
    }
};
