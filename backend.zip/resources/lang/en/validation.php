<?php
return [
    'required' => 'The :attribute field is required.',
    'min'      => ['string' => 'The :attribute must be at least :min characters.'],
    'max'      => ['string' => 'The :attribute must not exceed :max characters.'],
    'unique'   => 'The :attribute has already been taken.',
    'email'    => 'The :attribute must be a valid email address.',
    'exists'   => 'The selected :attribute is invalid.',
    'in'       => 'The selected :attribute is invalid.',
    'numeric'  => 'The :attribute must be a number.',
    'attributes' => [],
];
