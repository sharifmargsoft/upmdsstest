<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>UPMDSS API</title>
    <style>body{font-family:sans-serif;text-align:center;padding:60px;background:#f8fafc;color:#334155}</style>
</head>
<body>
    <h1>UPMDSS API Server</h1>
    <p>Version 2.0 — Laravel 11</p>
    <p>API Base URL: <code>/api/v1/</code></p>
    <p>Frontend: <a href="http://localhost:3000">http://localhost:3000</a></p>
</body>
</html>
