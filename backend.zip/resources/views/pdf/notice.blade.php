{{-- resources/views/pdf/notice.blade.php --}}
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>e-Notice {{ $notice->notice_number }}</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: DejaVu Sans, Arial, sans-serif; font-size: 12px; color: #1a1a2e; line-height: 1.5; }
        .page { padding: 25mm 20mm; }

        /* Header */
        .header { text-align: center; border-bottom: 3px solid #1a3a6b; padding-bottom: 12px; margin-bottom: 20px; }
        .header .emblem { font-size: 36px; }
        .header h1 { font-size: 16px; font-weight: bold; color: #1a3a6b; margin: 6px 0 2px; text-transform: uppercase; letter-spacing: 1px; }
        .header h2 { font-size: 12px; font-weight: normal; color: #555; }
        .header .notice-title { margin-top: 10px; font-size: 14px; font-weight: bold; color: #8b0000; text-transform: uppercase; letter-spacing: 2px; }

        /* Notice meta */
        .notice-meta { display: flex; justify-content: space-between; margin-bottom: 16px; font-size: 11px; }
        .notice-meta span { color: #555; }
        .notice-meta strong { color: #1a1a2e; }

        /* Sections */
        .section { margin-bottom: 16px; }
        .section-title { font-size: 11px; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; color: #1a3a6b; border-bottom: 1px solid #dde4f0; padding-bottom: 4px; margin-bottom: 10px; }
        .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px 20px; }
        .info-item label { font-size: 10px; color: #888; display: block; margin-bottom: 2px; }
        .info-item .value { font-size: 12px; font-weight: 600; color: #1a1a2e; }
        .info-item .value.highlight { color: #8b0000; }
        .info-item .value.mono { font-family: 'Courier New', monospace; font-size: 11px; }

        /* Offense box */
        .offense-box { background: #fef3f2; border: 1px solid #f5c6c6; border-left: 4px solid #8b0000; padding: 12px 16px; border-radius: 4px; margin-bottom: 16px; }
        .offense-box .offense-title { font-weight: bold; color: #8b0000; font-size: 12px; margin-bottom: 6px; }
        .offense-box .offense-text { color: #555; font-size: 11px; line-height: 1.6; }

        /* Penalty */
        .penalty-box { background: #f0f7ff; border: 1px solid #bee3f8; border-radius: 6px; padding: 14px 18px; margin-bottom: 16px; display: flex; justify-content: space-between; align-items: center; }
        .penalty-box .amount { font-size: 22px; font-weight: bold; color: #1a3a6b; }
        .penalty-box .amount-label { font-size: 10px; color: #888; margin-bottom: 2px; }
        .penalty-box .due { text-align: right; }
        .penalty-box .due-date { font-size: 13px; font-weight: bold; color: #8b0000; }

        /* Payment options */
        .payment-box { background: #f8f9fa; border: 1px solid #e0e0e0; border-radius: 4px; padding: 12px 16px; margin-bottom: 16px; }
        .payment-box p { font-size: 11px; margin-bottom: 4px; color: #444; }
        .payment-box .url { color: #1a3a6b; font-weight: bold; }

        /* Legal */
        .legal { font-size: 10px; color: #666; background: #f5f5f5; padding: 10px; border-radius: 4px; line-height: 1.6; }

        /* Evidence */
        .evidence-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 16px; }
        .evidence-img { width: 100%; height: 100px; object-fit: cover; border-radius: 4px; border: 1px solid #ddd; }
        .evidence-label { font-size: 9px; color: #888; text-align: center; margin-top: 3px; }

        /* Signature */
        .signature { margin-top: 30px; text-align: right; }
        .signature .officer { font-weight: bold; font-size: 12px; color: #1a1a2e; }
        .signature .designation { font-size: 10px; color: #555; }
        .signature .seal { font-size: 10px; color: #888; margin-top: 4px; }

        /* Footer */
        .footer { margin-top: 20px; border-top: 1px solid #e0e0e0; padding-top: 8px; text-align: center; font-size: 9px; color: #888; }

        /* QR area */
        .qr-section { display: flex; gap: 16px; align-items: flex-start; }
        .qr-placeholder { width: 80px; height: 80px; background: #f0f0f0; border: 1px solid #ddd; border-radius: 4px; display: flex; align-items: center; justify-content: center; font-size: 9px; color: #888; text-align: center; flex-shrink: 0; }
    </style>
</head>
<body>
<div class="page">

    {{-- HEADER --}}
    <div class="header">
        <div class="emblem">⚖️</div>
        <h1>Directorate of Geology & Mining</h1>
        <h2>Government of Uttar Pradesh, India</h2>
        <div class="notice-title">Electronic Notice (e-Notice)</div>
        <div style="font-size:10px; color:#888; margin-top:4px;">Under Mines & Minerals (Development & Regulation) Act, 1957</div>
    </div>

    {{-- NOTICE META --}}
    <div class="notice-meta">
        <div>
            <span>Notice No: </span>
            <strong style="font-family:monospace;">{{ $notice->notice_number }}</strong>
        </div>
        <div>
            <span>Date of Issue: </span>
            <strong>{{ $notice->issued_at?->format('d M Y') }}</strong>
        </div>
        <div>
            <span>District: </span>
            <strong>{{ $notice->district?->name }}</strong>
        </div>
    </div>

    {{-- VEHICLE & OWNER --}}
    <div class="section">
        <div class="section-title">Vehicle & Owner Details</div>
        <div class="info-grid">
            <div class="info-item">
                <label>Vehicle Registration Number</label>
                <div class="value mono highlight">{{ $notice->vehicle_number }}</div>
            </div>
            <div class="info-item">
                <label>Vehicle Owner Name</label>
                <div class="value">{{ $notice->vehicle_owner_name ?? 'As per Vahan Records' }}</div>
            </div>
            @if($notice->vehicle_owner_mobile)
            <div class="info-item">
                <label>Owner Mobile</label>
                <div class="value mono">{{ $notice->vehicle_owner_mobile }}</div>
            </div>
            @endif
            @if($notice->etp_number)
            <div class="info-item">
                <label>eTP Number</label>
                <div class="value mono">{{ $notice->etp_number }}</div>
            </div>
            @endif
        </div>
    </div>

    {{-- OFFENSE --}}
    <div class="offense-box">
        <div class="offense-title">
            Violation: {{ strtoupper(str_replace('_', ' ', $notice->offense_type)) }}
        </div>
        <div class="offense-text">
            {{ $notice->offense_description }}
        </div>
        <div style="margin-top: 8px; font-size: 11px; color: #555;">
            <strong>Date of Offense:</strong> {{ \Carbon\Carbon::parse($notice->offense_date)->format('d M Y') }}
            &nbsp;&nbsp;|&nbsp;&nbsp;
            <strong>Location:</strong> {{ $notice->offense_location ?? '—' }}
            @if($notice->mineral_name)
            &nbsp;&nbsp;|&nbsp;&nbsp;
            <strong>Mineral:</strong> {{ $notice->mineral_name }}
            @endif
        </div>
    </div>

    {{-- PENALTY --}}
    <div class="penalty-box">
        <div>
            <div class="amount-label">PENALTY AMOUNT</div>
            <div class="amount">₹ {{ number_format($notice->penalty_amount, 2) }}</div>
        </div>
        <div class="due">
            <div class="amount-label">PAYMENT DUE BY</div>
            <div class="due-date">{{ $notice->due_date?->format('d M Y') ?? '30 Days from issue' }}</div>
            <div style="font-size:10px; color:#8b0000; margin-top:2px;">Non-payment may result in legal action</div>
        </div>
    </div>

    {{-- PAYMENT INSTRUCTIONS --}}
    <div class="payment-box">
        <p><strong>Pay Online:</strong> <span class="url">https://upmdss.in/pay</span> (Enter Notice Number: <strong>{{ $notice->notice_number }}</strong>)</p>
        <p><strong>via UP Rajkosh:</strong> <span class="url">https://rajkosh.up.nic.in</span> — State Treasury Online Payment</p>
        <p><strong>via e-District / CSC:</strong> Visit nearest Common Service Centre for offline payment assistance</p>
    </div>

    {{-- LEGAL TEXT --}}
    <div class="legal">
        <strong>Notice under Section 21(5) of Mines & Minerals (Development and Regulation) Act, 1957 and relevant Rules.</strong>
        Failure to pay the specified penalty within the due date may result in further legal proceedings including seizure of vehicle,
        forfeiture of mining lease, blacklisting of vehicle from receiving transit passes (eTPs) through MineMitra portal,
        and/or prosecution under applicable law. This is a computer-generated notice and does not require a physical signature.
        For grievances, contact your District Mining Office or email: grievance@upmdss.in
    </div>

    {{-- SIGNATURE --}}
    <div class="signature">
        <div style="height: 30px;"></div>
        <div class="officer">{{ $notice->issuedBy?->name ?? 'Mining Officer' }}</div>
        <div class="designation">{{ $notice->issuedBy?->designation ?? 'District Mining Officer' }}</div>
        <div class="seal">{{ $notice->district?->name }} District — Directorate of Geology & Mining, UP</div>
    </div>

    {{-- FOOTER --}}
    <div class="footer">
        <div>UPMDSS — Uttar Pradesh Mining Decision Support System &nbsp;|&nbsp; www.upmdss.in &nbsp;|&nbsp; © {{ date('Y') }} DGM, UP</div>
        <div style="margin-top:3px;">Generated on: {{ now()->format('d M Y H:i:s T') }} &nbsp;|&nbsp; Notice UUID: {{ $notice->uuid }}</div>
    </div>

</div>
</body>
</html>
